--
-- PostgreSQL database dump
--

\restrict uF5zOKy1WPO1bprMptmbF5QIJeFzhhFqkvxw2hQsNjJyhhcGh9h7H9IzNiRCzSM

-- Dumped from database version 18.4 (Homebrew)
-- Dumped by pg_dump version 18.4 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: demo_baseline; Type: SCHEMA; Schema: -; Owner: hsuyi
--

CREATE SCHEMA demo_baseline;


ALTER SCHEMA demo_baseline OWNER TO hsuyi;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: hsuyi
--

-- *not* creating schema, since initdb creates it


ALTER SCHEMA public OWNER TO hsuyi;

--
-- Name: action_type_t; Type: TYPE; Schema: public; Owner: hsuyi
--

CREATE TYPE public.action_type_t AS ENUM (
    'case_synced',
    'code_assigned',
    'code_changed',
    'approved_single',
    'approved_group',
    'approved_all',
    'reopened',
    'exported'
);


ALTER TYPE public.action_type_t OWNER TO hsuyi;

--
-- Name: case_status_t; Type: TYPE; Schema: public; Owner: hsuyi
--

CREATE TYPE public.case_status_t AS ENUM (
    'open',
    'in_review',
    'approved',
    'reopened'
);


ALTER TYPE public.case_status_t OWNER TO hsuyi;

--
-- Name: code_role_t; Type: TYPE; Schema: public; Owner: hsuyi
--

CREATE TYPE public.code_role_t AS ENUM (
    'principal_diagnosis',
    'secondary_diagnosis',
    'procedure',
    'other',
    'external_cause'
);


ALTER TYPE public.code_role_t OWNER TO hsuyi;

--
-- Name: code_source_t; Type: TYPE; Schema: public; Owner: hsuyi
--

CREATE TYPE public.code_source_t AS ENUM (
    'imported_from_imed',
    'coder_assigned'
);


ALTER TYPE public.code_source_t OWNER TO hsuyi;

--
-- Name: code_system_t; Type: TYPE; Schema: public; Owner: hsuyi
--

CREATE TYPE public.code_system_t AS ENUM (
    'ICD-10',
    'ICD-9'
);


ALTER TYPE public.code_system_t OWNER TO hsuyi;

--
-- Name: completeness_t; Type: TYPE; Schema: public; Owner: hsuyi
--

CREATE TYPE public.completeness_t AS ENUM (
    'complete',
    'incomplete'
);


ALTER TYPE public.completeness_t OWNER TO hsuyi;

--
-- Name: kb_status_t; Type: TYPE; Schema: public; Owner: hsuyi
--

CREATE TYPE public.kb_status_t AS ENUM (
    'active',
    'archived'
);


ALTER TYPE public.kb_status_t OWNER TO hsuyi;

--
-- Name: order_cat_t; Type: TYPE; Schema: public; Owner: hsuyi
--

CREATE TYPE public.order_cat_t AS ENUM (
    'medicine',
    'lab',
    'ROIP',
    'CT',
    'X-ray',
    'surgery',
    'other'
);


ALTER TYPE public.order_cat_t OWNER TO hsuyi;

--
-- Name: source_type_t; Type: TYPE; Schema: public; Owner: hsuyi
--

CREATE TYPE public.source_type_t AS ENUM (
    'core_verified',
    'coder_taught'
);


ALTER TYPE public.source_type_t OWNER TO hsuyi;

--
-- Name: user_role; Type: TYPE; Schema: public; Owner: hsuyi
--

CREATE TYPE public.user_role AS ENUM (
    'coder',
    'admin'
);


ALTER TYPE public.user_role OWNER TO hsuyi;

--
-- Name: user_status; Type: TYPE; Schema: public; Owner: hsuyi
--

CREATE TYPE public.user_status AS ENUM (
    'active',
    'inactive',
    'suspended'
);


ALTER TYPE public.user_status OWNER TO hsuyi;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: case_code_edits; Type: TABLE; Schema: demo_baseline; Owner: hsuyi
--

CREATE TABLE demo_baseline.case_code_edits (
    case_id character varying(50),
    payload jsonb,
    updated_at timestamp without time zone
);


ALTER TABLE demo_baseline.case_code_edits OWNER TO hsuyi;

--
-- Name: case_codes; Type: TABLE; Schema: demo_baseline; Owner: hsuyi
--

CREATE TABLE demo_baseline.case_codes (
    case_code_id integer,
    case_id character varying(50),
    code_role public.code_role_t,
    source public.code_source_t,
    imed_ref_id character varying(50),
    assigned_by integer,
    assigned_at timestamp without time zone,
    icd_10_id integer,
    icd_9_id integer,
    operation_start text,
    operation_end text,
    operation_type text
);


ALTER TABLE demo_baseline.case_codes OWNER TO hsuyi;

--
-- Name: case_orders; Type: TABLE; Schema: demo_baseline; Owner: hsuyi
--

CREATE TABLE demo_baseline.case_orders (
    order_id integer,
    case_id character varying(50),
    order_category public.order_cat_t,
    imed_source character varying(40),
    imed_ref_id character varying(50),
    order_name text,
    order_detail jsonb,
    ordered_at text
);


ALTER TABLE demo_baseline.case_orders OWNER TO hsuyi;

--
-- Name: case_report_sections; Type: TABLE; Schema: demo_baseline; Owner: hsuyi
--

CREATE TABLE demo_baseline.case_report_sections (
    section_id integer,
    case_id character varying(50),
    documenttype character varying(50),
    fieldname character varying(100),
    value text,
    recorddatetime text
);


ALTER TABLE demo_baseline.case_report_sections OWNER TO hsuyi;

--
-- Name: case_stars; Type: TABLE; Schema: demo_baseline; Owner: hsuyi
--

CREATE TABLE demo_baseline.case_stars (
    case_id character varying(50),
    starred_by text,
    starred_at text
);


ALTER TABLE demo_baseline.case_stars OWNER TO hsuyi;

--
-- Name: case_vitals; Type: TABLE; Schema: demo_baseline; Owner: hsuyi
--

CREATE TABLE demo_baseline.case_vitals (
    vital_id integer,
    case_id character varying(50),
    measured_at text,
    temperature text,
    systolic text,
    diastolic text,
    heart_rate text,
    oxygen_saturation text,
    weight text,
    height text
);


ALTER TABLE demo_baseline.case_vitals OWNER TO hsuyi;

--
-- Name: cases; Type: TABLE; Schema: demo_baseline; Owner: hsuyi
--

CREATE TABLE demo_baseline.cases (
    case_id character varying(50),
    patient_ref character varying(50),
    encountertype character varying(10),
    sex character varying(10),
    birthdate date,
    ageyear character varying(20),
    admissiondatetime timestamp without time zone,
    dischargedatetime timestamp without time zone,
    dischargetype character varying(50),
    dischargestatus character varying(50),
    ispregnant character varying(10),
    ward character varying(100),
    department character varying(100),
    coverage_type character varying(50),
    completeness_status public.completeness_t,
    missing_detail text,
    disease_group character varying(100),
    severity_level character varying(50),
    case_status public.case_status_t,
    fetched_at timestamp without time zone
);


ALTER TABLE demo_baseline.cases OWNER TO hsuyi;

--
-- Name: coding_history; Type: TABLE; Schema: demo_baseline; Owner: hsuyi
--

CREATE TABLE demo_baseline.coding_history (
    history_id integer,
    case_id character varying(50),
    user_id integer,
    action_type public.action_type_t,
    action_detail jsonb,
    created_at timestamp without time zone
);


ALTER TABLE demo_baseline.coding_history OWNER TO hsuyi;

--
-- Name: coverage_types; Type: TABLE; Schema: demo_baseline; Owner: hsuyi
--

CREATE TABLE demo_baseline.coverage_types (
    coverage_code character varying(50),
    scheme_family character varying(20),
    label_th text,
    label_en text,
    payer character varying(20)
);


ALTER TABLE demo_baseline.coverage_types OWNER TO hsuyi;

--
-- Name: document_chunks; Type: TABLE; Schema: demo_baseline; Owner: hsuyi
--

CREATE TABLE demo_baseline.document_chunks (
    chunk_id integer,
    case_id character varying(50),
    chunk_text text,
    chunk_index integer,
    embedding_ref character varying(100)
);


ALTER TABLE demo_baseline.document_chunks OWNER TO hsuyi;

--
-- Name: icd_10; Type: TABLE; Schema: demo_baseline; Owner: hsuyi
--

CREATE TABLE demo_baseline.icd_10 (
    icd_10_id integer,
    code character varying(20),
    description text
);


ALTER TABLE demo_baseline.icd_10 OWNER TO hsuyi;

--
-- Name: icd_9; Type: TABLE; Schema: demo_baseline; Owner: hsuyi
--

CREATE TABLE demo_baseline.icd_9 (
    icd_9_id integer,
    code character varying(20),
    description text
);


ALTER TABLE demo_baseline.icd_9 OWNER TO hsuyi;

--
-- Name: imed_write_ops; Type: TABLE; Schema: demo_baseline; Owner: hsuyi
--

CREATE TABLE demo_baseline.imed_write_ops (
    op_id integer,
    case_id character varying(50),
    op text,
    code_kind text,
    object_id character varying(100),
    before_json text,
    created_at text
);


ALTER TABLE demo_baseline.imed_write_ops OWNER TO hsuyi;

--
-- Name: knowledge_base; Type: TABLE; Schema: demo_baseline; Owner: hsuyi
--

CREATE TABLE demo_baseline.knowledge_base (
    knowledge_id integer,
    source_type public.source_type_t,
    content text,
    taught_by integer,
    status public.kb_status_t,
    created_at timestamp without time zone
);


ALTER TABLE demo_baseline.knowledge_base OWNER TO hsuyi;

--
-- Name: users; Type: TABLE; Schema: demo_baseline; Owner: hsuyi
--

CREATE TABLE demo_baseline.users (
    user_id integer,
    email character varying(100),
    oauth_provider character varying(50),
    oauth_subject character varying(255),
    full_name character varying(100),
    role public.user_role,
    status public.user_status,
    created_at timestamp without time zone,
    last_login_at timestamp without time zone,
    password_hash text
);


ALTER TABLE demo_baseline.users OWNER TO hsuyi;

--
-- Name: agent_conversations; Type: TABLE; Schema: public; Owner: hsuyi
--

CREATE TABLE public.agent_conversations (
    conversation_id integer NOT NULL,
    user_id integer NOT NULL,
    mode text NOT NULL,
    title text NOT NULL,
    created_at text,
    updated_at text
);


ALTER TABLE public.agent_conversations OWNER TO hsuyi;

--
-- Name: agent_conversations_conversation_id_seq; Type: SEQUENCE; Schema: public; Owner: hsuyi
--

CREATE SEQUENCE public.agent_conversations_conversation_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agent_conversations_conversation_id_seq OWNER TO hsuyi;

--
-- Name: agent_conversations_conversation_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hsuyi
--

ALTER SEQUENCE public.agent_conversations_conversation_id_seq OWNED BY public.agent_conversations.conversation_id;


--
-- Name: agent_messages; Type: TABLE; Schema: public; Owner: hsuyi
--

CREATE TABLE public.agent_messages (
    message_id integer NOT NULL,
    conversation_id integer NOT NULL,
    role text NOT NULL,
    content text NOT NULL,
    sources text,
    unverified_codes text,
    created_at text
);


ALTER TABLE public.agent_messages OWNER TO hsuyi;

--
-- Name: agent_messages_message_id_seq; Type: SEQUENCE; Schema: public; Owner: hsuyi
--

CREATE SEQUENCE public.agent_messages_message_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.agent_messages_message_id_seq OWNER TO hsuyi;

--
-- Name: agent_messages_message_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hsuyi
--

ALTER SEQUENCE public.agent_messages_message_id_seq OWNED BY public.agent_messages.message_id;


--
-- Name: app_settings; Type: TABLE; Schema: public; Owner: hsuyi
--

CREATE TABLE public.app_settings (
    key text NOT NULL,
    value text NOT NULL,
    updated_at text,
    updated_by text
);


ALTER TABLE public.app_settings OWNER TO hsuyi;

--
-- Name: auth_sessions; Type: TABLE; Schema: public; Owner: hsuyi
--

CREATE TABLE public.auth_sessions (
    session_id character varying(255) NOT NULL,
    user_id integer,
    refresh_token_enc text,
    expires_at timestamp without time zone,
    created_at timestamp without time zone DEFAULT now(),
    revoked boolean DEFAULT false
);


ALTER TABLE public.auth_sessions OWNER TO hsuyi;

--
-- Name: case_code_edits; Type: TABLE; Schema: public; Owner: hsuyi
--

CREATE TABLE public.case_code_edits (
    case_id character varying(50) NOT NULL,
    payload jsonb NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.case_code_edits OWNER TO hsuyi;

--
-- Name: case_codes; Type: TABLE; Schema: public; Owner: hsuyi
--

CREATE TABLE public.case_codes (
    case_code_id integer NOT NULL,
    case_id character varying(50),
    code_role public.code_role_t,
    source public.code_source_t NOT NULL,
    imed_ref_id character varying(50),
    assigned_by integer,
    assigned_at timestamp without time zone DEFAULT now(),
    icd_10_id integer,
    icd_9_id integer,
    operation_start text,
    operation_end text,
    operation_type text,
    CONSTRAINT case_codes_one_catalog_ck CHECK ((num_nonnulls(icd_10_id, icd_9_id) = 1))
);


ALTER TABLE public.case_codes OWNER TO hsuyi;

--
-- Name: case_codes_case_code_id_seq; Type: SEQUENCE; Schema: public; Owner: hsuyi
--

CREATE SEQUENCE public.case_codes_case_code_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.case_codes_case_code_id_seq OWNER TO hsuyi;

--
-- Name: case_codes_case_code_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hsuyi
--

ALTER SEQUENCE public.case_codes_case_code_id_seq OWNED BY public.case_codes.case_code_id;


--
-- Name: case_orders; Type: TABLE; Schema: public; Owner: hsuyi
--

CREATE TABLE public.case_orders (
    order_id integer NOT NULL,
    case_id character varying(50),
    order_category public.order_cat_t,
    imed_source character varying(40),
    imed_ref_id character varying(50),
    order_name text,
    order_detail jsonb,
    ordered_at text
);


ALTER TABLE public.case_orders OWNER TO hsuyi;

--
-- Name: case_orders_order_id_seq; Type: SEQUENCE; Schema: public; Owner: hsuyi
--

CREATE SEQUENCE public.case_orders_order_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.case_orders_order_id_seq OWNER TO hsuyi;

--
-- Name: case_orders_order_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hsuyi
--

ALTER SEQUENCE public.case_orders_order_id_seq OWNED BY public.case_orders.order_id;


--
-- Name: case_report_sections; Type: TABLE; Schema: public; Owner: hsuyi
--

CREATE TABLE public.case_report_sections (
    section_id integer NOT NULL,
    case_id character varying(50),
    documenttype character varying(50),
    fieldname character varying(100),
    value text,
    recorddatetime text
);


ALTER TABLE public.case_report_sections OWNER TO hsuyi;

--
-- Name: case_report_sections_section_id_seq; Type: SEQUENCE; Schema: public; Owner: hsuyi
--

CREATE SEQUENCE public.case_report_sections_section_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.case_report_sections_section_id_seq OWNER TO hsuyi;

--
-- Name: case_report_sections_section_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hsuyi
--

ALTER SEQUENCE public.case_report_sections_section_id_seq OWNED BY public.case_report_sections.section_id;


--
-- Name: case_stars; Type: TABLE; Schema: public; Owner: hsuyi
--

CREATE TABLE public.case_stars (
    case_id character varying(50) NOT NULL,
    starred_by text NOT NULL,
    starred_at text NOT NULL
);


ALTER TABLE public.case_stars OWNER TO hsuyi;

--
-- Name: case_vitals; Type: TABLE; Schema: public; Owner: hsuyi
--

CREATE TABLE public.case_vitals (
    vital_id integer NOT NULL,
    case_id character varying(50) NOT NULL,
    measured_at text,
    temperature text,
    systolic text,
    diastolic text,
    heart_rate text,
    oxygen_saturation text,
    weight text,
    height text
);


ALTER TABLE public.case_vitals OWNER TO hsuyi;

--
-- Name: case_vitals_vital_id_seq; Type: SEQUENCE; Schema: public; Owner: hsuyi
--

CREATE SEQUENCE public.case_vitals_vital_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.case_vitals_vital_id_seq OWNER TO hsuyi;

--
-- Name: case_vitals_vital_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hsuyi
--

ALTER SEQUENCE public.case_vitals_vital_id_seq OWNED BY public.case_vitals.vital_id;


--
-- Name: cases; Type: TABLE; Schema: public; Owner: hsuyi
--

CREATE TABLE public.cases (
    case_id character varying(50) NOT NULL,
    patient_ref character varying(50),
    encountertype character varying(10),
    sex character varying(10),
    birthdate date,
    ageyear character varying(20),
    admissiondatetime timestamp without time zone,
    dischargedatetime timestamp without time zone,
    dischargetype character varying(50),
    dischargestatus character varying(50),
    ispregnant character varying(10),
    ward character varying(100),
    department character varying(100),
    coverage_type character varying(50),
    completeness_status public.completeness_t,
    missing_detail text,
    disease_group character varying(100),
    severity_level character varying(50),
    case_status public.case_status_t DEFAULT 'open'::public.case_status_t,
    fetched_at timestamp without time zone
);


ALTER TABLE public.cases OWNER TO hsuyi;

--
-- Name: coding_history; Type: TABLE; Schema: public; Owner: hsuyi
--

CREATE TABLE public.coding_history (
    history_id integer NOT NULL,
    case_id character varying(50),
    user_id integer,
    action_type public.action_type_t,
    action_detail jsonb,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.coding_history OWNER TO hsuyi;

--
-- Name: coding_history_history_id_seq; Type: SEQUENCE; Schema: public; Owner: hsuyi
--

CREATE SEQUENCE public.coding_history_history_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.coding_history_history_id_seq OWNER TO hsuyi;

--
-- Name: coding_history_history_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hsuyi
--

ALTER SEQUENCE public.coding_history_history_id_seq OWNED BY public.coding_history.history_id;


--
-- Name: coverage_types; Type: TABLE; Schema: public; Owner: hsuyi
--

CREATE TABLE public.coverage_types (
    coverage_code character varying(50) NOT NULL,
    scheme_family character varying(20),
    label_th text,
    label_en text,
    payer character varying(20)
);


ALTER TABLE public.coverage_types OWNER TO hsuyi;

--
-- Name: document_chunks; Type: TABLE; Schema: public; Owner: hsuyi
--

CREATE TABLE public.document_chunks (
    chunk_id integer NOT NULL,
    case_id character varying(50),
    chunk_text text,
    chunk_index integer,
    embedding_ref character varying(100)
);


ALTER TABLE public.document_chunks OWNER TO hsuyi;

--
-- Name: document_chunks_chunk_id_seq; Type: SEQUENCE; Schema: public; Owner: hsuyi
--

CREATE SEQUENCE public.document_chunks_chunk_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.document_chunks_chunk_id_seq OWNER TO hsuyi;

--
-- Name: document_chunks_chunk_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hsuyi
--

ALTER SEQUENCE public.document_chunks_chunk_id_seq OWNED BY public.document_chunks.chunk_id;


--
-- Name: icd_10; Type: TABLE; Schema: public; Owner: hsuyi
--

CREATE TABLE public.icd_10 (
    icd_10_id integer NOT NULL,
    code character varying(20) NOT NULL,
    description text
);


ALTER TABLE public.icd_10 OWNER TO hsuyi;

--
-- Name: icd_10_icd_10_id_seq; Type: SEQUENCE; Schema: public; Owner: hsuyi
--

CREATE SEQUENCE public.icd_10_icd_10_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.icd_10_icd_10_id_seq OWNER TO hsuyi;

--
-- Name: icd_10_icd_10_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hsuyi
--

ALTER SEQUENCE public.icd_10_icd_10_id_seq OWNED BY public.icd_10.icd_10_id;


--
-- Name: icd_9; Type: TABLE; Schema: public; Owner: hsuyi
--

CREATE TABLE public.icd_9 (
    icd_9_id integer NOT NULL,
    code character varying(20) NOT NULL,
    description text
);


ALTER TABLE public.icd_9 OWNER TO hsuyi;

--
-- Name: icd_9_icd_9_id_seq; Type: SEQUENCE; Schema: public; Owner: hsuyi
--

CREATE SEQUENCE public.icd_9_icd_9_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.icd_9_icd_9_id_seq OWNER TO hsuyi;

--
-- Name: icd_9_icd_9_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hsuyi
--

ALTER SEQUENCE public.icd_9_icd_9_id_seq OWNED BY public.icd_9.icd_9_id;


--
-- Name: imed_write_ops; Type: TABLE; Schema: public; Owner: hsuyi
--

CREATE TABLE public.imed_write_ops (
    op_id integer NOT NULL,
    case_id character varying(50) NOT NULL,
    op text NOT NULL,
    code_kind text NOT NULL,
    object_id character varying(100) NOT NULL,
    before_json text,
    created_at text
);


ALTER TABLE public.imed_write_ops OWNER TO hsuyi;

--
-- Name: imed_write_ops_op_id_seq; Type: SEQUENCE; Schema: public; Owner: hsuyi
--

CREATE SEQUENCE public.imed_write_ops_op_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.imed_write_ops_op_id_seq OWNER TO hsuyi;

--
-- Name: imed_write_ops_op_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hsuyi
--

ALTER SEQUENCE public.imed_write_ops_op_id_seq OWNED BY public.imed_write_ops.op_id;


--
-- Name: knowledge_base; Type: TABLE; Schema: public; Owner: hsuyi
--

CREATE TABLE public.knowledge_base (
    knowledge_id integer NOT NULL,
    source_type public.source_type_t,
    content text,
    taught_by integer,
    status public.kb_status_t DEFAULT 'active'::public.kb_status_t,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.knowledge_base OWNER TO hsuyi;

--
-- Name: knowledge_base_knowledge_id_seq; Type: SEQUENCE; Schema: public; Owner: hsuyi
--

CREATE SEQUENCE public.knowledge_base_knowledge_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.knowledge_base_knowledge_id_seq OWNER TO hsuyi;

--
-- Name: knowledge_base_knowledge_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hsuyi
--

ALTER SEQUENCE public.knowledge_base_knowledge_id_seq OWNED BY public.knowledge_base.knowledge_id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: hsuyi
--

CREATE TABLE public.users (
    user_id integer NOT NULL,
    email character varying(100) NOT NULL,
    oauth_provider character varying(50),
    oauth_subject character varying(255),
    full_name character varying(100),
    role public.user_role DEFAULT 'coder'::public.user_role NOT NULL,
    status public.user_status DEFAULT 'active'::public.user_status NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    last_login_at timestamp without time zone,
    password_hash text
);


ALTER TABLE public.users OWNER TO hsuyi;

--
-- Name: users_user_id_seq; Type: SEQUENCE; Schema: public; Owner: hsuyi
--

CREATE SEQUENCE public.users_user_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_user_id_seq OWNER TO hsuyi;

--
-- Name: users_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: hsuyi
--

ALTER SEQUENCE public.users_user_id_seq OWNED BY public.users.user_id;


--
-- Name: agent_conversations conversation_id; Type: DEFAULT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.agent_conversations ALTER COLUMN conversation_id SET DEFAULT nextval('public.agent_conversations_conversation_id_seq'::regclass);


--
-- Name: agent_messages message_id; Type: DEFAULT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.agent_messages ALTER COLUMN message_id SET DEFAULT nextval('public.agent_messages_message_id_seq'::regclass);


--
-- Name: case_codes case_code_id; Type: DEFAULT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.case_codes ALTER COLUMN case_code_id SET DEFAULT nextval('public.case_codes_case_code_id_seq'::regclass);


--
-- Name: case_orders order_id; Type: DEFAULT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.case_orders ALTER COLUMN order_id SET DEFAULT nextval('public.case_orders_order_id_seq'::regclass);


--
-- Name: case_report_sections section_id; Type: DEFAULT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.case_report_sections ALTER COLUMN section_id SET DEFAULT nextval('public.case_report_sections_section_id_seq'::regclass);


--
-- Name: case_vitals vital_id; Type: DEFAULT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.case_vitals ALTER COLUMN vital_id SET DEFAULT nextval('public.case_vitals_vital_id_seq'::regclass);


--
-- Name: coding_history history_id; Type: DEFAULT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.coding_history ALTER COLUMN history_id SET DEFAULT nextval('public.coding_history_history_id_seq'::regclass);


--
-- Name: document_chunks chunk_id; Type: DEFAULT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.document_chunks ALTER COLUMN chunk_id SET DEFAULT nextval('public.document_chunks_chunk_id_seq'::regclass);


--
-- Name: icd_10 icd_10_id; Type: DEFAULT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.icd_10 ALTER COLUMN icd_10_id SET DEFAULT nextval('public.icd_10_icd_10_id_seq'::regclass);


--
-- Name: icd_9 icd_9_id; Type: DEFAULT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.icd_9 ALTER COLUMN icd_9_id SET DEFAULT nextval('public.icd_9_icd_9_id_seq'::regclass);


--
-- Name: imed_write_ops op_id; Type: DEFAULT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.imed_write_ops ALTER COLUMN op_id SET DEFAULT nextval('public.imed_write_ops_op_id_seq'::regclass);


--
-- Name: knowledge_base knowledge_id; Type: DEFAULT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.knowledge_base ALTER COLUMN knowledge_id SET DEFAULT nextval('public.knowledge_base_knowledge_id_seq'::regclass);


--
-- Name: users user_id; Type: DEFAULT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.users ALTER COLUMN user_id SET DEFAULT nextval('public.users_user_id_seq'::regclass);


--
-- Data for Name: case_code_edits; Type: TABLE DATA; Schema: demo_baseline; Owner: hsuyi
--

COPY demo_baseline.case_code_edits (case_id, payload, updated_at) FROM stdin;
\.


--
-- Data for Name: case_codes; Type: TABLE DATA; Schema: demo_baseline; Owner: hsuyi
--

COPY demo_baseline.case_codes (case_code_id, case_id, code_role, source, imed_ref_id, assigned_by, assigned_at, icd_10_id, icd_9_id, operation_start, operation_end, operation_type) FROM stdin;
\.


--
-- Data for Name: case_orders; Type: TABLE DATA; Schema: demo_baseline; Owner: hsuyi
--

COPY demo_baseline.case_orders (order_id, case_id, order_category, imed_source, imed_ref_id, order_name, order_detail, ordered_at) FROM stdin;
\.


--
-- Data for Name: case_report_sections; Type: TABLE DATA; Schema: demo_baseline; Owner: hsuyi
--

COPY demo_baseline.case_report_sections (section_id, case_id, documenttype, fieldname, value, recorddatetime) FROM stdin;
\.


--
-- Data for Name: case_stars; Type: TABLE DATA; Schema: demo_baseline; Owner: hsuyi
--

COPY demo_baseline.case_stars (case_id, starred_by, starred_at) FROM stdin;
\.


--
-- Data for Name: case_vitals; Type: TABLE DATA; Schema: demo_baseline; Owner: hsuyi
--

COPY demo_baseline.case_vitals (vital_id, case_id, measured_at, temperature, systolic, diastolic, heart_rate, oxygen_saturation, weight, height) FROM stdin;
\.


--
-- Data for Name: cases; Type: TABLE DATA; Schema: demo_baseline; Owner: hsuyi
--

COPY demo_baseline.cases (case_id, patient_ref, encountertype, sex, birthdate, ageyear, admissiondatetime, dischargedatetime, dischargetype, dischargestatus, ispregnant, ward, department, coverage_type, completeness_status, missing_detail, disease_group, severity_level, case_status, fetched_at) FROM stdin;
\.


--
-- Data for Name: coding_history; Type: TABLE DATA; Schema: demo_baseline; Owner: hsuyi
--

COPY demo_baseline.coding_history (history_id, case_id, user_id, action_type, action_detail, created_at) FROM stdin;
\.


--
-- Data for Name: coverage_types; Type: TABLE DATA; Schema: demo_baseline; Owner: hsuyi
--

COPY demo_baseline.coverage_types (coverage_code, scheme_family, label_th, label_en, payer) FROM stdin;
OFC_O3	OFC	\N	\N	CGD
UCS_89_I	UCS	\N	\N	NHSO
OFC_O1	OFC	\N	\N	CGD
LGO_L2	LGO	\N	\N	NHSO
LGO_L1	LGO	\N	\N	NHSO
UCS_89	UCS	\N	\N	NHSO
WEL_73	WEL	\N	\N	NHSO
P1027	OTHER	\N	\N	\N
WEL_77_I	WEL	\N	\N	NHSO
WEL_88	WEL	\N	\N	NHSO
WEL_77	WEL	\N	\N	NHSO
OFC_O4	OFC	\N	\N	CGD
WEL_88_I	WEL	\N	\N	NHSO
VLG_L2	VLG	\N	\N	NHSO
WEL_71	WEL	\N	\N	NHSO
OFC_O5	OFC	\N	\N	CGD
LGO_L5	LGO	\N	\N	NHSO
WEL_74_I	WEL	\N	\N	NHSO
WEL_71_I	WEL	\N	\N	NHSO
WEL_82_I	WEL	\N	\N	NHSO
WEL_72_I	WEL	\N	\N	NHSO
WEL_76_I	WEL	\N	\N	NHSO
OFC_E2	OFC	\N	\N	CGD
OFC_B3	OFC	\N	\N	CGD
WEL_73_I	WEL	\N	\N	NHSO
OFC_E1	OFC	\N	\N	CGD
foreign	FOREIGN	\N	\N	\N
DIS_D1	DIS	\N	\N	NHSO
Cashonly	SELF_PAY	\N	\N	SELF
VOF_OFC	VOF	\N	\N	CGD
WEL_72	WEL	\N	\N	NHSO
WEL_81_I	WEL	\N	\N	NHSO
UCS_88	UCS	\N	\N	NHSO
\.


--
-- Data for Name: document_chunks; Type: TABLE DATA; Schema: demo_baseline; Owner: hsuyi
--

COPY demo_baseline.document_chunks (chunk_id, case_id, chunk_text, chunk_index, embedding_ref) FROM stdin;
\.


--
-- Data for Name: icd_10; Type: TABLE DATA; Schema: demo_baseline; Owner: hsuyi
--

COPY demo_baseline.icd_10 (icd_10_id, code, description) FROM stdin;
1	A02.1	Salmonella sepsis
2	A05.9	Food poisoning
3	A07.3	Isosporiasis
4	A09.0	Infectious diarrhea
5	A09.9	Acute gastroenteritis
6	A15.7	Primary respiratory tuberculosis, confirmed bacteriologically and histologically
7	A30	Leprosy [Hansen disease]
8	A31.1	Cutaneous mycobacterial infection
9	A39.2	Acute meningococcaemia
10	A39.3	Chronic meningococcaemia
11	A39.4	Meningococcaemia, unspecified
12	A41.5	Klebsiella pneumoniae septicemia
13	A41.9	Septicaemia, unspecified
14	A42.8	Other forms of actinomycosis
15	A46	Erysipelas
16	A54.8	Other gonococcal infections
17	A60.0	Herpesviral infection of genitalia and urogenital tract
18	A81.2	Progressive multifocal leukencephalopathy
19	B00.0	Eczema herpeticum
20	B00.1	Herpesviral vesicular dermatitis
21	B00.2	Herpesviral gingivostomatitis and pharyngotonsillitis
22	B00.5	Herpesviral ocular disease
23	B00.7	Disseminated herpesviral disease
24	B00.8	Other forms of herpesviral infection, specified as chronic ulcers
25	B02.9	Herpes Zoster
26	B07	Viral warts at right foot
27	B08.1	Molluscum contagiosum
28	B08.2	Roseola infantum
29	B08.8	Foot- and- mouth disease
30	B16.9	Acute viral hepatitis B
31	B18.1	chronic HBV infection
32	B18.2	Chronic viral hepatitis C
33	B20.0	HIV disease resulting in mycobacterial infection
34	B22.7	HIV disease resulting in multiple diseases classified elsewhere
35	B24	HIV disease
36	B25.8	Other cytomegaloviral diseas e, specified as retinitis
37	B25.9	Cytomegaloviral disease, unspecified, except for liver, spleen
38	B34.1	Enterovirus infection
39	B35.4	Tinea corporis
40	B37.1	Pulmonary candidiasis
41	B37.8	Candidiasis of other sites, specified as of oesophagus
42	B95.2	Enterococcus faecium form pus penis
43	B95.4	Viridans Streptococcus infection
44	B96.0	Mycoplasma pneumoniae as the cause of diseases classified to
45	B96.1	Klebsiella pneumoniae ssp pneumoniae
46	B96.2	E.coli infection
47	B96.3	Haemophilus influenzae as the cause of diseases classified to
48	B97.0	Adenovirus as the cause of diseases classified to other chapters
49	B97.1	Enterovirus as the cause of diseases classified to other chapters
50	B97.2	Coronavirus as the cause of diseases classified to other chapters
51	B97.3	Retrovirus as the cause of diseases classified to other chapters
52	B97.4	Respiratory syncytial virus as the cause of diseases classified to
53	B97.5	Reovirus as the cause of diseases classified to other chapters
54	B97.6	Parvovirus as the cause of diseases classified to other chapters
55	B97.7	Papillomavirus as the cause of diseases classified to other
56	B97.8	Other viral agents as the cause of diseases classified to other
57	B98.0	H. pylori infection
58	B98.1	Vibrio vulnificus as the cause of diseases classified to other
59	C00.8	Overlapping lesion of lip
60	C18.4	CA colon, transverse colon
61	C18.7	CA sigmoid colon, pT3N1bM1b stage IVb
62	C18.9	CA colon
63	C19	Adenocarcinoma of rectosigmoid junction with impending large bowel obstruction
64	C20	CA rectum
65	C22.0	HCC
66	C34.1	CA lung, upper lobe
67	C50.2	CA breast, upper-inner quadrant
68	C50.4	Left CA breast
69	C50.9	CA Rt breast
70	C60.9	CA penis
71	C67.9	CA bladder
72	C73	CA thyroid
73	C76	Malignant neoplasms of ill-defined sites
74	C77.5	Intrapelvic lymph node metastasis
75	C77.9	Metastasis CA to lymph node, SPC
76	C78.0	Metastasis CA to lung
77	C78.7	Metastasis CA to liver
78	C79.3	Metastasis CA to brain and cerebral meninges
79	C79.5	Metastasis CA to bone and bone marrow
80	C79.7	Metastasis CA to adrenal gland
81	C79.8	pelvic nodule metastatic adenocarcinoma
82	C79.9	Secondary malignant neoplasm, unspecified site
83	C80	Malignant neoplasm, without specification of site
84	C80.0	Malignant neoplasm, primary site unknown
85	C80.9	Malignant neoplasm, primary site unspecified
86	C83.1	Mantle cell lymphoma
87	C83.3	Diffuse non-Hodgkin's lymphoma large cell (diffuse)
88	C83.7	Burkitt lymphoma
89	C85.1	B cell lymphoma
90	C90.0	Multiple myeloma
91	C92.1	Chronic myeloid leukaemia
92	C97	Malignant neoplasms of independent (primary) multiple sites
93	D14.0	Benign neoplasm of middle ear, nasal cavity and accessory sinuses
94	D17.0	Benign lipomatous neoplasm of skin and subcutaneous tissue of head, face and neck
95	D17.1	lipoma at back
96	D17.2	Lipoma Rt hip
97	D18.0	Hemangioma
98	D25.1	Intramural leiomyoma of uterus
99	D25.9	Myoma uteri
100	D27	Dermoid Cyst, Ovary
101	D32.9	meningioma
102	D35.0	E05–E06
103	D38.6	Lung tumor
104	D41.4	Tumor of bladder
105	D46.9	MDS
106	D47.7	D50–D53
107	D50.0	Iron deﬁciency anaemia secondary to blood loss (chronic)
108	D50.9	Iron deficiency anaemia
109	D56.0	Alpha thalassaemia
110	D56.9	Thalassemia
111	D59.1	AIHA
112	D62	Anemia due to acute blood loss
113	D63.0	Anemia in neoplastic disease
114	D63.8	Anemia of CKD
115	D64.9	Anemia
116	D69.3	ITP(Idiopathic thrombocytopenic purpura)
117	D69.5	CMT induced  Thrombocytopenia
118	D69.6	Thrombocytopenia
119	D72.1	Eosinophilia
120	D89.3	Immune Reconstitution Inflammatory Syndrome (IRIS)
121	E02	Hypothyroidism, subclinical iodine def
122	E03.9	Hypothyroidism
123	E04.1	Nontoxic single thyroid nodule
124	E05.0	graves' diseaes
125	E05.9	Thyrotoxicosis
126	E11.5	DM type 2 foot with Diabetic ulcer
127	E11.9	DM Type 2 (Diabetes mellitus Type 2)
128	E12	E40–E46
129	E14.2	DM with renal complication
130	E14.3	Diabetic cataract
131	E14.9	DM unknown type
132	E24	E80.0–E80.2
133	E27.4	secondary adrenal insufficiency
134	E28.2	PCOS
135	E34.0	Carcinoid syndrome
136	E44.1	Mild protein-energy malnutrition
137	E61.1	Iron deficiency
138	E64.9	E80.0–E80.2
139	E66.0	Obesity due to excess calories
140	E66.2	Obesity with alveolar hypoventilation
141	E66.8	morbid obesity
142	E66.9	Obesity
143	E68	Sequelae of hyperalimentation
144	E78.1	Hypertriglyceridemia
145	E78.5	Hyperlipidemia
146	E78.9	DLP (Dyslipidemia)
147	E79.0	Hyperuricemia
148	E83.1	secondary hemochromatosis
149	E83.3	hypophosphatemia
150	E83.4	hypomagnesemia
151	E83.5	hypocalcemia
152	E84	Type of diabetes Due to
153	E86	Volume depletion
154	E87.1	Hyponatremia
155	E87.2	Lactic acidosis
156	E87.5	Hyperkalemia
157	E87.6	Hypokalemia
158	E87.7	volume overload
159	E89.0	Hypothyroidism, postprocedural
160	E89.1	F10.1–F10.2
161	F02.3	Dementia in Parkinson's disease
162	F03	Dementia
163	F11	F13–F16
164	F20.0	Paranoid schizophrenia
165	F31	Bipolar affective disorder
166	F31.9	Bipolar affective disorder
167	F32.2	major depressive disorder
168	F32.9	Depression
169	F33	Recurrent depressive disorder
170	F33.0	Recurrent depressive disorder, current episode mild, Without somatic symptoms
171	F33.9	Recurrent depressive disorder
172	F40.1	Social phobias
173	F41.0	Panic disorder [episodic  paroxysmal anxiety]
174	F41.1	Generalized anxiety disorder
175	F42	Obsessive-compulsive disorder
176	F43.0	Acute stress reaction
177	F60.3	Emotionally unstable personality disorder
178	F61	Mixed and other personality disorders
179	F69	Unspeciﬁed disorder of adult personality and behaviour
180	F71.9	Moderate mental retardation: without mention of impairment of behaviour
181	F80.0	Specific speech articulation disorder
182	F81.9	Developmental disorder of scholastic skills, unspecified
183	F84.0	Childhood autism
184	F90.9	ADHD
185	G00.9	Bacterial meningitis
186	G03	Meningitis due to other and unspecified causes
187	G09	Sequelae of inflammatory diseases of central nervous system
188	G20	Parkinson's disease
189	G25.5	Other chorea
190	G40.2	Complex partial seizures
191	G40.6	Grand mal seizures
192	G43.9	Migraine headache
193	G46.7	Lacunar syndromes
194	G47.0	Insomnia
195	G47.3	obstructive sleep apnea
196	G51.0	Bell's palsy
197	G56.0	Carpal tunnel syndrome
198	G57.5	Tarsal tunnel syndrome
199	G58.7	Mononeuritis multiplex
200	G62.9	Rt. sciatic neuropathy
201	G70.0	Myasthenia gravis
202	G81.0	Flaccid hemiplegia
203	G81.1	Spastic hemiplegia
204	G81.9	Right Hemiparesis
205	G82.0	Flaccid paraplegia
206	G90.0	Idiopathic peripheral autonomic neuropathy
207	G91.1	Hydrocephalus
208	G93.4	Encephalopathy, unspecified
209	H00.0	Hordeolum
210	H00.1	Chalazion
211	H01.0	Blepharitis
212	H02.8	dermatochalasis
213	H04.1	Dry eye
214	H05.0	preseptal cellulitis
215	H10.1	Allergic conjunctivitis
216	H10.3	Acute conjunctivitis
217	H11.1	Pinguecula
218	H46	Optic neuritis
219	H52.1	Myopia
220	H55	Nystagmus and other irregular eye movements
221	H61.2	Impacted cerumen
222	H72.0	TM perforation Rt. ear ,Central
223	H73.0	Acute myringitis
224	H81.1	BPPV
225	H81.3	Peripheral vertigo
226	H90.3	Sensorineural hearing loss, bilateral
227	H90.5	Sensorineural hearing loss
228	H93.1	Tinnitus
229	I05.8	Other mitral valve diseases, or Heart disease
230	I05.9	Mitral valve disease, unspecified
231	I09.1	Rheumatic diseases of endocardium, valve unspecified
232	I09.9	Rheumatic heart disease, unspecified
233	I10	Essential HT
234	I15.0	Renovascular hypertension
235	I15.1	Hypertension secondary to other renal disorders
236	I15.2	Hypertension secondary to endocrine disorders
237	I15.8	Other secondary hypertension
238	I15.9	HT in young
239	I21.4	NSTEMI
240	I24.0	Coronary thrombosis not resulting in myocardial infarction
241	I25.1	CAD(Coronary artery disease)
242	I25.2	Old myocardial infarction
243	I26.0	Acute Pulmonary embolism with RV failure
244	I26.9	Pulmonary embolism
245	I27.9	Pulmonary heart disease, unspecified
246	I34.1	Mitral valve prolapse
247	I46.1	Sudden cardiac death, so described
248	I46.9	Cardiac arrest, unspeciﬁed
249	I47.1	SVT
250	I48	Atrial fibrillation
251	I48.9	AF
252	I49.1	PAC
253	I49.3	Premature ventricular contractions
254	I50.0	CHF
255	I50.9	Heart failure, unspecified
256	I51.9	Heart disease, unspecified, except when specified as terminal
257	I61.0	basal ganglia hemorrhage
258	I61.1	Lt. basal ganglion hemorrhage
259	I63.3	Cerebral infarction of cerebral arteries due to thrombosis
260	I67.2	Cerebral atherosclerosis
261	I69.1	Sequelae of cerebrovascular disease
262	I69.2	Sequelae of nontraumatic intracranial hemorrhage
263	I69.3	Sequelae of cerebral infarction
264	I69.4	Sequelae of cerebrovascular disease
265	I70.9	Generalized and unspecified atherosclerosis
266	I71.1	Thoracic aortic aneurysm, ruptured
267	I71.2	Thoracic aortic aneurysm, without mention of rupture
268	I71.3	Abdominal aortic aneurysm, ruptured
269	I71.4	Abdominal aortic aneurysm, without mention of rupture
270	I71.9	Aortic aneurysm
271	I73.9	PVD(Peripheral vascular disease)
272	I78.1	Nevus, non-neoplastic
273	I80.2	DVT
274	I80.9	Phlebitis and thrombophlebitis of unspeciﬁed site
275	I82.9	Embolism and thrombosis of unspeciﬁed vein
276	I87.2	Venous insufficiency (chronic)(peripheral)
277	I95.9	Hypotension
278	I99	Other and unspeciﬁed disorders of circulatory system
279	J00	Common cold
280	J01.9	Acute sinusitis
281	J02.9	Acute pharyngitis
282	J03.9	Acute tonsillitis
283	J05.0	Croup
284	J05.1	Acute epiglottitis
285	J10.1	Influenza A positive
286	J15.0	Pneumonia due to Klebsiella pneumoniae
287	J15.6	pneumonia Acinetobacter baumannii
288	J15.9	Bacterial pneumonia
289	J16	Pneumonia due to other infectious organisms, not elsewhere
290	J18.1	Lobar pneumonia
291	J18.9	Pneumonia
292	J20.9	Acute bronchitis
293	J30.4	Allergic rhinitis
294	J31.0	Chronic rhinitis
295	J32.0	Chronic maxillary sinusitis
296	J32.9	Chronic sinusitis
297	J33.9	Nasal polyp
298	J34.2	Deviated nasal septum
299	J40	Bronchitis, not specified as acute or chronic
300	J42	Unspecified chronic bronchitis
301	J44.0	COPD with acute lower respiratory infection
302	J44.1	COPD with acute exacerbation
303	J44.9	COPD
304	J45.9	Bronchial hyperresponsiveness (TM)
305	J46	Status asthmaticus
306	J47	Bronchiectasis
307	J81	Pulmonary oedema
308	J90	Pleural effusion
309	J96.0	Acute respiratory failure
310	J96.00	Acute respiratory failure Type I
311	J96.09	Acute respiratory failure type IV
312	J96.9	Respiratory failure, unspeciﬁed
313	J98.4	lung nodule
314	K01	Embedded and impacted teeth
315	K01.0	Embedded and impacted teeth
316	K04.01	Acute pulpitis
317	K12.0	Apthus ulcer
318	K12.2	Deep neck infection
319	K14.0	Glossitis
320	K20	Esophagitis
321	K21.9	GERD
322	K22.1	Esophageal ulcer
323	K25.3	Gastric ulcer: acute without haemorrhage or perforation
324	K27	Peptic ulcer, site unspecified
325	K29.1	Acute gastritis
326	K29.9	Gastroduodenitis.
327	K30	Functional dyspepsia
328	K31.9	Duodenal lesion
329	K35.3	Acute suppurative appendicitis with localized peritonitis
330	K35.8	Acute appendicitis
331	K43.2	Incisional hernia without obstruction or gangrene
332	K55.0	omental infarction
333	K56.4	Other impaction of intestine
334	K56.6	Large bowel obstruction due to tumor
335	K57.1	Diverticular disease of large intestine
336	K57.3	Diverticulosis of colon
337	K57.5	cecal diverticula and ileal diverticula
338	K57.9	Acute diverticulitis
339	K58.0	IBS with diarrhea
340	K59.0	neuropathic bowel
341	K62.0	Anal canal polyp
342	K63.5	Polyp of colon
343	K64.1	Hemorrhoid Grade 2
344	K64.2	Hemorrhoid Grade 3
345	K64.8	Internal hemorrhoid
346	K64.9	Hemorrhoid
347	K70.0	Alcoholic fatty liver
348	K70.3	Alcoholic cirrhosis of liver
349	K70.4	K73.- (Chronic hepatitis, not elsewhere classified), code
350	K71	Toxic liver disease
351	K74.0	Hepatic fibrosis
352	K74.1	Hepatic sclerosis
353	K74.2	Hepatic fibrosis with hepatic sclerosis
354	K74.6	cirrhosis of liver
355	K75.8	Other specified inflammatory liver diseases, if specified as
356	K75.9	Inflammatory liver disease, unspecified
357	K76.0	Fatty liver
358	K76.9	Liver disease, unspecified
359	K80.2	symptomatic gallstone
360	K80.3	Bile duct stone with cholangitis
361	K80.4	Calculus of bile duct with cholecystitis
362	K83.1	dilated cbd
363	K85	K86.0–K86.1
364	K85.9	Acute pancreatitis, unspecified
365	K92.2	UGIB
366	L01	Impetigo
367	L02.1	Abcess, neck
368	L02.4	Abscess, hip
369	L03	Cellulitis
370	L03.0	Paronychia
371	L03.1	Left lower leg cellulituis
372	L04.0	Acute lymphadenitis
373	L08.9	Infected wound
374	L22	Diaper [napkin] dermatitis
375	L23.9	Allergic contact dermatitis
376	L30.1	Dyshidrosis [pompholyx]
377	L30.9	chronic eczema
378	L42	Pityriasis rosea
379	L50.9	Acute urticaria
380	L63.9	Alopecia areata
381	L70.9	Acne
382	L72.1	sebaceous cyst
383	L80	Vitiligo
384	L83	Acanthosis nigricans
385	L84	Callus
386	L85.3	Xerosis cutis
387	L89	Decubitus ulcer
388	L91.0	Keloid scar
389	M05.89	Other seropositive rheumatoid arthritis
390	M06.99	Rheumatoid arthritis
391	M10.09	Gouty arthritis
392	M10.99	Gout
393	M17.0	OA Knee,bilateral
394	M17.1	OA left knee
395	M25.54	Pain in joint: intercarpal/finger joint
396	M25.56	Pain in joint: knee joint
397	M25.59	polyarthralgia
398	M35.3	Polymyalgia rheumatica
399	M41.29	Idiopathic scoliosis
400	M43.16	Spondylolisthesis, lumbar region
401	M43.17	Spondylolisthesis, lumbosacral region
402	M43.19	Spondylolisthesis
403	M43.6	Torticollis, unspeciﬁed
404	M47.22	CSR
405	M47.26	Other spondylosis with radiculopathy: lumbar region
406	M47.8	Other spondylosis
407	M47.96	Lumbar spondylosis
408	M48.0	Spinal stenosis, (except for the cervical region)
409	M48.06	SCS L-spine
410	M48.07	SCS LS-spine
411	M48.09	\N
412	M49.47	Neuropathic spondylopathy: lumbosacral region
413	M50.9	Cervical disc disorder
414	M51.1	Lumbar disc disorder with radiculopathy
415	M51.2	HNP
416	M54.19	radiculopathy in Spinal stenosis
417	M54.5	Low back pain
418	M54.9	back pain
419	M62.60	Muscle strain, multiple sites
420	M62.61	Muscle strain, shoulder region
421	M62.64	Muscle strain, hand
422	M62.66	Muscle strain, lower leg
423	M62.68	\N
424	M62.69	Muscle strain
425	M65.2	Calcific tendinitis
426	M65.34	Trigger finger
427	M65.43	dequevain
428	M72.2	Plantar fasciitis
429	M75.0	Frozen Shoulder
430	M75.1	Rotator cuff tear of left shoulder (supraspinatus, high-grade partial bursal side tear)
431	M75.2	Biceps tenosynovitis
432	M75.4	Subacromial impingement with spur
433	M76.6	Achilles tendinitis
434	M77.1	Tennis elbow
435	M77.94	Tendinitis Rt wrist
436	M77.99	Tendinitis
437	M79.29	neuropathic pain
438	M79.70	Myofascial pain in limb Multiple sites
439	M79.71	Myofascial pain in limb Shoulder region
440	M79.78	Fibromyalgia: other site
441	M79.79	Myofascial pain in limb
442	M79.89	Myofascial pain syndrome
443	M85.89	Bone density disorder
444	M94.0	Costrochondritis
445	M94.2	Chondromalacia
446	N04	Nephrotic syndrome deny kidney bx
447	N10	Acute pyelonephritis
448	N13.1	Hydronephrosis with ureteral stricture
449	N13.6	Lt UC with moderate to severe HN with UTI
450	N17.9	Acute kidney injury
451	N18.2	CKD stage 2
452	N18.3	CKD stage 3
453	N18.5	ESRD(End-stage renal disease)
454	N19	Unspecified kidney failure
455	N20.0	Renal calculi
456	N21.0	bladder stone
457	N26	Unspecified contracted kidney
458	N28.0	Rt renal infraction
459	N30.0	Acute cystitis
460	N30.9	Cystitis
461	N31	Neuromuscular dysfunction of bladder, not elsewhere
462	N31.2	Flaccid neuropathic bladder
463	N39.0	Urinary tract infection
464	N39.3	Stress incontinence
465	N40	BPH
466	N45	Orchitis and epididymitis
467	N46	Male infertility
468	N47	Redundant prepuce, phimosis, and paraphimosis
469	N48.1	Balanitis
470	N60.1	cysts both breasts
471	N61	Inflammatory disorders of breast
472	N63	Breast mass
473	N64.4	Breast pain
474	N73.9	PID
475	N80.0	Adenomyosis
476	N81.3	prolapsed uteri grade III
477	N86	Erosion and ectropion of cervix uteri
478	N87.0	LSIL
479	N89.8	Leukorrhea
480	N91.1	Secondary amenorrhoea
481	N93.8	DUB
482	N93.9	Abnormal uterine and vaginal bleeding
483	N94.6	Dysmenorrhea
484	N95.1	Menopausal and female climacteric states
485	N95.9	perimenopausal symptoms
486	N96	Habitual aborter
487	O33.9	maternal care due to CPD
488	O71.6	Obstetric damage to pelvic joints and ligaments
489	O82.0	Delivery by elective caesarean section
490	O94	Sequelae of complication of pregnancy, childbirth and the
491	P00.0	Severe birth asphyxia is coded at (b) and hydrocephalus at (a)
492	P02.0	Light for dates with fetal malnutrition is coded at (a)
493	P05.0	Light for dates
494	P10.0	Massive inhalation of meconium
495	P22.0	Respiratory distress syndrome
496	P24.0	Prolonged pregnancy
497	P28.5	Respiratory failure of newborn
498	P59.9	Neonatal jaundice
499	P83.1	Erythema Toxicum Neonatorum
500	Q03.9	Hydrocephalus
501	Q10.0	Congenital ptosis
502	Q25.0	PDA
503	Q28.2	Arteriovenous malformation of cerebral vessels
504	Q38.1	Tongue tie
505	Q44.6	Cystic disease of liver
506	Q81.0	Epidermolysis bullosa simplex
507	Q82.8	skin tag
508	R00.2	Palpitations
509	R04.2	Hemoptysis
510	R05	Cough
511	R06.5	Snoring
512	R10.1	Dyspepsia
513	R10.2	Pelvic pain
514	R10.4	Abdominal pain
515	R13	Dysphagia
516	R18	Ascites
517	R20.8	Numbness
518	R31	gross hematuria
519	R39.2	Prerenal azotremia
520	R42	Dizziness
521	R47.0	Dysphasia and aphasia
522	R50.9	AFI
523	R51	Headache
524	R53	Fatique
525	R56.8	seizure
526	R57.2	septic shock
527	R60.0	Leg edema
528	R60.9	Edema cause
529	R64	Cachexia
530	R65.0	Systemic inflammatory response syndrome of infectious origin
531	R65.1	Systemic inflammatory response syndrome of infectious origin
532	R65.9	Systemic inflammatory response syndrome, unspecified
533	R73.0	IFG (impaired glucose tolerance)
534	R73.9	Hyperglycemia
535	R75	Laboratory evidence of human immunodeficiency virus [HIV]
536	R91	Suspected CA lung
537	R94.5	Transaminitis
538	S01.8	laceration wound at head
539	S15	S17–S19
540	S30.2	Rt scrotal hematoma
541	S41.1	Large LW upper arm Rt
542	S42.30	Closed Fracture of shaft of humerus.
543	S45	S47–S49
544	S46.0	Injury of tendon of the rotator cuff of shoulder
545	S50.8	Lt.forearm
546	S50.80	Abrasion of elbow and forearm
547	S52.509	Closed Fracture of distal radius, unspecified (TM)
548	S55	S57–S59
549	S61.0	Open wound of finger(s)
550	S62.21	Fracture 1st MCP, open
551	S65	S67–S69
552	S75	S77–S79
553	S83.6	Sprain and strain of knee
554	S85	S87–S89
555	S90.80	Abrasion of ankle and foot
556	S93.4	Ankle sprain
557	S95	S97–S99
558	T09.0	Superﬁcial injury of trunk, level unspeciﬁed
559	T09.1	T09.8–T09.9
560	T11.0	Superﬁcial injury of upper limb, level unspeciﬁed
561	T13.0	Superﬁcial injury of lower limb, level unspeciﬁed
562	T14.0	Superﬁcial injury of unspeciﬁed body region
563	T14.5	T14.7–T14.9
564	T17.2	Foreign body in soft tissue
565	T20.1	Burn of ﬁrst degree of head and neck
566	T21.1	Burn of ﬁrst degree of trunk
567	T22.1	Burn of ﬁrst degree of shoulder and upper limb, except wrist and hand
568	T23.1	Burn of ﬁrst degree of wrist and hand
569	T24.1	Burn of ﬁrst degree of hip and lower limb, except ankle and foot
570	T25.1	Burn of ﬁrst degree of ankle and foot
571	T30.2	Burn, 2nd degree
572	T37.5	T38.0–T38.1
573	T80.2	T80.8–T80.9
574	T90.1	T90.8–T90.9
575	U57.21	ลมปลายปัตฆาตไหล่ U57.21
576	U57.30	ลมปลายปัตฆาตโค้งคอ U57.30
577	U57.31	ลมปลายปัตฆาตสัญญาณ 1 หลัง U57.31
578	U57.32	ลมปลายปัตฆาตสัญญาณ 3 หลัง U57.32
579	U57.33	ลมปลายปัตฆาตสัญญาณ 4 หลัง / คอ U57.33
580	U57.34	ลมปลายปัตฆาตสัญญาณ 5 หลัง / คอ U57.34
581	U59.06	นหารูพิการ หรือ เส้นเอ็นพิการ U59.06
582	U61.4	สันนิบาตลูกนก U61.4
583	U69.84	ท้องผูก U69.84
584	U78.011	Stomach duct pain   U78.011
585	U78.028	Constipation U78.028
586	U78.081	Dry cough   U78.081
587	U78.117	Hemiplegia U78.117
588	U78.125	Dementia U78.125
589	U78.250	Impediment disease   U78.250
590	U78.256	Bone impediment   U78.256
591	U78.257	Flesh impediment   U78.257
592	U78.288	Sweating from the palms and soles U78.288
593	U78.403	Herpes zoster U78.403
594	U78.422	Urticaria U78.422
595	U78.490	Generalized pain U78.490
596	U78.493	Lumbago U78.493
597	U78.824	Allergic rhinitis   U78.824
598	U78.906	Impediment of the sinew   U78.906
599	U79.427	Lung heat pattern / syndrome   U79.427
600	V22.49	ขี่ MC ชน MC
601	V28.49	MC ล้มเอง(คนขับ)
602	V29	Motorcycle rider injured in transport accidents
603	W01.99	ล้ม
604	W22.09	โดนกระแทก
605	W45.99	ก้างปลาติดในลำคอ.
606	W54.99	Dog Bite
607	W57.0	Bitten or stung by nonvenomous insect and other nonvenomous arthropods
608	W57.99	Insect Bite
609	X98	Assault by steam, hot vapours and hot objects
610	X99	Assault by sharp object
611	Y41.1	IRZE-induced IRIS
612	Y43.1	Ragorafenib-induced hypertension
613	Y43.3	mFOLFOX6-induced anemia/thrombocytopenia
614	Y64	Y83–Y84
615	Z00.0	Check up
616	Z00.1	Well baby examination
617	Z01.6	Radiological examination
618	Z01.7	Laboratory examination
619	Z02.4	Driving licence
620	Z02.7	ขอใบรับรองแพทย์ ต่อสัญญาจ้าง
621	Z09.8	Follow up after treatment
622	Z09.9	Follow up
623	Z12.1	Special screening examination for neoplasm of intestinal tract
624	Z12.3	Special screening examination for neoplasm of breast
625	Z20.1	Contact with TB
626	Z24.2	Rabies Vaccination
627	Z24.6	Hepatitis B Vaccination
628	Z27.4	MMR Vaccination
629	Z30.0	Counselling for contraception
630	Z30.9	Contraceptive management
631	Z34.0	ANC for first pregnancy
632	Z34.8	ANC
633	Z37.0	Single live birth
634	Z38.0	Singleton, born in hospital
635	Z39	Postpartum care and examination
636	Z42.9	Follow up care for plastic surgery
637	Z43.0	Attention to tracheostomy
638	Z47.8	Fracture humerus, shaft, closed
639	Z48.0	f/u wound at lateral canthal area
640	Z49.1	Extracorporeal dialysis
641	Z51.1	Chemotherapy for neoplasm
642	Z51.4	pre-op evaluation
643	Z53.2	ยกเลิกตรวจ
644	Z53.8	มาทำนัด
645	Z58.1	Exposure to air pollution
646	Z72.1	Chronic alcohol drinking
647	Z76.0	Refill medication
648	Z76.2	Health supervision and care of other healthy infant and child
649	Z95.2	s/p AVR
650	Z95.4	Presence of heart valve replacement
651	E11.65	Type 2 diabetes mellitus with hyperglycaemia
652	V89.2	Person injured in unspecified motor-vehicle accident, traffic
653	F98.0	F98.0
654	F98.9	F98.9
655	G43.0	G43.0
656	G43.2	G43.2
657	G43.3	G43.3
658	G43.8	G43.8
\.


--
-- Data for Name: icd_9; Type: TABLE DATA; Schema: demo_baseline; Owner: hsuyi
--

COPY demo_baseline.icd_9 (icd_9_id, code, description) FROM stdin;
1	00.24	IVUS (Intravascular imaging of coronary vessels)
2	00.40	1vv ; Procedure on single vessel
3	00.45	Stent 1 ; Insertion of one vascular stent
4	00.66	PCI at LCX
5	01.24	Other craniotomy
6	03.09	Other exploration and decompression of spinal canal
7	03.31	Lumbar puncture
8	03.91	Injection of anesthetic into spinal canal for analgesia
9	04.43	Release of carpal tunnel
10	06.2	Unilateral thyroid lobectomy
11	06.39	Other partial thyroidectomy
12	06.4	Complete thyroidectomy
13	08.20	Removal of lesion of eyelid, not otherwise specified
14	09.81	Dacryocystorhinostomy [DCR]
15	10.0	Removal of embedded foreign body from conjunctiva by incision
16	13.41	Phacoemulsification and aspiration of cataract
17	13.71	Insertion of intraocular lens prosthesis at time of cataract extraction
18	18.29	Excision or destruction of other lesion of external ear
19	19.4	Myringoplasty
20	1B41811	Double-handed needle insertion, (Di-Cang) 1B41811
21	1B61811	Double-handed needle insertion, (Jia-Che) 1B61811
22	1C21800	Acupuncture anesthesia, (Ting-Gong) 1C21800
23	1J21800	Acupuncture anesthesia, (Bai-Hui) 1J21800
24	1J21810	Single-handed needle insertion, (Bai-Hui) 1J21810
25	1J21811	Double-handed needle insertion, (Bai-Hui) 1J21811
26	1J21891	Moxa burner moxibustion, (Bai-Hui) 1J21891
27	1J51810	Single-handed needle insertion, (Shang-Xing) 1J51810
28	1J61811	Double-handed needle insertion, (Shen-Ting) 1J61811
29	1R11810	Single-handed needle insertion, (Si-Shen-Cong) 1R11810
30	1R11811	Double-handed needle insertion, (Si-Shen-Cong) 1R11811
31	1R31811	Double-handed needle insertion, (Yin-Tang) 1R31811
32	1R51811	Double-handed needle insertion, (Tai-Yang) 1R51811
33	20.01	Myringotomy with insertion of tube
34	21.03	Control of epistaxis by cauterization and packing
35	21.21	Nasal endoscope
36	21.22	Biopsy of nose
37	21.31	Local excision or destruction of intranasal lesion
38	23.01	Forceps extraction of tooth
39	23.09	Extraction of other tooth
40	23.19	Surgical removal of tooth
41	27.0	Incision and drainage of submandibular area
42	27.59	Other plastic repair of mouth
43	28.2	Tonsillectomy without adenoidectomy
44	28.3	Tonsillectomy with adenoidectomy
45	2A11811	Double-handed needle insertion, (Fu-Tu) 2A11811
46	2D01811	Double-handed needle insertion, (Tian-Zhu) 2D01811
47	2G01800	Acupuncture anesthesia, (Feng-Chi) 2G01800
48	2G01811	Double-handed needle insertion, (Feng-Chi) 2G01811
49	2J01810	Single-handed needle insertion, (Da-Zhui) 2J01810
50	2J21810	Single-handed needle insertion, (Feng-Fu) 2J21810
51	2R41801	Electro-acupuncture therapy, (Jing-Bai-Lao) 2R41801
52	2R41810	Single-handed needle insertion, (Jing-Bai-Lao) 2R41810
53	31.1	Temporary tracheostomy
54	31.42	laryngoscopy
55	33.22	Fiber-optic bronchoscopy
56	33.24	Closed [endoscopic] biopsy of bronchus
57	34.04	Insertion of intercostal catheter for drainage
58	34.91	Thoracocentesis
59	36.06	Insertion of non-drug-eluting coronary artery stent(s)
60	36.07	Stent DES ; Insertion of drug-eluting coronary artery stent(s)
61	37.20	Noninvasive programmed electrical stimulation [NIPS]
62	37.22	Left heart cardiac catheterization
63	37.78	Insertion of temporary transvenous pacemaker system
64	37.83	Initial insertion of dual-chamber pacemaker device
65	38.93	Venous catheterization, not elsewhere classified
66	38.94	C-line Insertion
67	38.95	Venous catheterization for renal dialysis
68	39.27	Arteriovenostomy for renal dialysis
69	39.50	Angioplasty of other non-coronary vessel(s)
70	39.95	Extracorporeal [hemodialysis]
71	40.11	Biopsy of lymphatic structure
72	41.31	Biopsy of bone marrow
73	42.23	Esophagoscopy
74	42.92	Dilation of esophagus
75	43.11	Percutaneous [endoscopic] gastrostomy [PEG]
76	44.13	Other gastroscopy
77	44.43	Endoscopic control of gastric or duodenal bleeding
78	45.13	Other endoscopy of small intestine
79	45.16	EGD (esophagogastroduodenoscopy) [with closed biopsy]
80	45.23	Colonoscopy
81	45.25	Closed [endoscopic] biopsy of large intestine
82	45.42	Endoscopic polypectomy of large intestine
83	47.01	Laparoscopic appendectomy
84	47.09	Appendectomy
85	48.23	PROCTOSCOPY
86	48.36	[Endoscopic] polypectomy of rectum
87	48.63	Low anterior resection
88	49.45	Ligation of hemorrhoids
89	49.46	Hemorrhoidectomy
90	4B61810	Single-handed needle insertion, (Tian-Shu) 4B61810
91	4B61811	Double-handed needle insertion, (Tian-Shu) 4B61811
92	4H31811	Double-handed needle insertion, (Guan-Yuan) 4H31811
93	4H51811	Double-handed needle insertion, (Qi-Hai) 4H51811
94	4HC1811	Double-handed needle insertion, (Shang-Wan) 4HC1811
95	50.11	Closed (percutaneous) [needle] biopsy of liver
96	51.10	ERCP(Endoscopic Retrograde Cholangio Pancreatography)
97	51.22	Cholecystectomy
98	51.23	Laparoscopic cholecystectomy
99	53.00	Unilateral repair of inguinal hernia, not otherwise specified
100	53.05	Repair of inguinal hernia with graft or prosthesis
101	53.49	Other umbilical herniorrhaphy
102	54.11	Exploratory laparotomy
103	54.21	Laparoscopy
104	54.23	biopsy of pelvic metastatic nodule
105	54.91	Percutaneous abdominal drainage
106	55.03	Percutaneous nephrostomy without fragmentation
107	55.23	Closed [percutaneous] biopsy of kidney
108	57.32	Cystoscope
109	57.94	Insertion of indwelling urinary catheter
110	58.6	Dilation of urethra
111	59.8	Double J insertion
112	5907811	การนวดด้วยวิธีการแพทย์แผนไทยแบบราชสำนัก ที่หลัง (5907811)
113	5907820	การประคบด้วยสมุนไพร ที่หลัง (5907820)
114	5C11800	Acupuncture anesthesia, (Tian-Zong) 5C11800
115	5C11801	Electro-acupuncture therapy, (Tian-Zong) 5C11801
116	5C11810	Single-handed needle insertion, (Tian-Zong) 5C11810
117	5C11811	Double-handed needle insertion, (Tian-Zong) 5C11811
118	5C21800	Acupuncture anesthesia, (Bing-Feng) 5C21800
119	5D31810	Single-handed needle insertion, (Fei-Shu) 5D31810
120	5D51811	Double-handed needle insertion, (Xin-Shu) 5D51811
121	5D71801	Electro-acupuncture therapy, (Ge-Shu) 5D71801
122	5D71811	Double-handed needle insertion, (Ge-Shu)  5D71811
123	5DD1800	Acupuncture anesthesia, (Shen-Shu) 5DD1800
124	5DD1801	Electro-acupuncture therapy, (Shen-Shu) 5DD1801
125	5DD1810	Single-handed needle insertion, (Shen-Shu) 5DD1810
126	5DD1811	Double-handed needle insertion, (Shen-Shu) 5DD1811
127	5DF1800	Acupuncture anesthesia, (Da-Chang-Shu) 5DF1800
128	5DF1801	Electro-acupuncture therapy, (Da-Chang-Shu) 5DF1801
129	5DF1811	Double-handed needle insertion, (Da-Chang-Shu) 5DF1811
130	5E41801	Electro-acupuncture therapy, (Zhi-Shi) 5E41801
131	5E61811	Double-handed needle insertion, (Zhi-Bian) 5E61811
132	5J21800	Acupuncture anesthesia, (Yao-Yang-Guan) 5J21800
133	5T01811	Double-handed needle insertion, (Jia-ji) 5T01811
134	60.11	Closed [percutaneous] [needle] biopsy of prostate
135	60.29	Other transurethral prostatectomy
136	61.0	explore scrotum stop bleeding
137	61.2	Excision of hydrocele (of tunica vaginalis)
138	61.3	clot evacuation
139	62.5	Orchiopexy
140	64.0	Circumcision
141	65.29	Other local excision or destruction of ovary
142	65.41	Laparoscopic unilateral salpingo-oophorectomy
143	66.29	Other bilateral endoscopic destruction or occlusion of fallopian tubes
144	66.51	Total bilateral salpingectomy
145	67.32	Destruction of lesion of cervix by cauterization
146	68.16	Closed biopsy of uterus
147	68.49	Other and unspecified total abdominal hysterectomy
148	68.51	Colpohysterectomy [laparoscopically assisted (LAVH)]
149	69.02	Dilation and curettage following delivery or abortion
150	69.09	Other dilation and curettage of uterus
151	6A41800	Acupuncture anesthesia, (Shou-San-Li) 6A41800
152	6A41801	Electro-acupuncture therapy, (Shou-San-Li) 6A41801
153	6A41810	Single-handed needle insertion, (Shou-San-Li) 6A41810
154	6A41811	Double-handed needle insertion, (Shou-San-Li) 6A41811
155	6A51800	Acupuncture anesthesia, (Qu-Chi) 6A51800
156	6A51810	Single-handed needle insertion, (Qu-Chi) 6A51810
157	6A51811	Double-handed needle insertion, (Qu-Chi) 6A51811
158	6A81800	Acupuncture anesthesia, (Bi-Nao) 6A81800
159	6A81801	Electro-acupuncture therapy, (Bi-Nao) 6A81801
160	6A81811	Double-handed needle insertion, (Bi-Nao) 6A81811
161	6A91800	Acupuncture anesthesia, (Jian-Yu) 6A91800
162	6A91801	Electro-acupuncture therapy, (Jian-Yu) 6A91801
163	6A91811	Double-handed needle insertion, (Jian-Yu) 6A91811
164	6C41800	Acupuncture anesthesia, (Jian-Zhen) 6C41800
165	6F11800	Acupuncture anesthesia, (Wai-Guan) 6F11800
166	6F11811	Double-handed needle insertion, (Wai-Guan) 6F11811
167	6FA1800	Acupuncture anesthesia, (Jian-Liao) 6FA1800
168	6FA1811	Double-handed needle insertion, (Jian-Liao) 6FA1811
169	6G01800	Acupuncture anesthesia, (Jian-Jing) 6G01800
170	6G01801	Electro-acupuncture therapy, (Jian-Jing) 6G01801
171	6G01810	Single-handed needle insertion, (Jian-Jing) 6G01810
172	6G01811	Double-handed needle insertion, (Jian-Jing) 6G01811
173	6K41811	Double-handed needle insertion, (Lie-Que) 6K41811
174	6N41800	Acupuncture anesthesia, (Nei-Guan) 6N41800
175	71.22	Incision of Bartholin's gland (cyst)
176	71.79	vaginal repair
177	7217811	การนวดด้วยวิธีการแพทย์แผนไทยแบบราชสำนัก ที่ไหล่, บ่า (7217811)
178	7217820	การประคบด้วยสมุนไพร ที่ไหล่, บ่า (7217820)
179	7217839	การใช้ยาบำบัด  ไม่ระบุวิธี ที่ไหล่, บ่า (7217839)
180	7267811	การนวดด้วยวิธีการแพทย์แผนไทยแบบราชสำนัก ที่มือ  (7267811)
181	73.59	Other manually assisted delivery
182	73.6	Episiotomy
183	74.1	Low cervical cesarean section
184	77.29	Wedge osteotomy
185	78.69	Removal of implanted devices from bone, other
186	79.01	Closed reduction of fracture of humerus without internal fixation
187	79.31	Open reduction of fracture with internal fixation, humerus
188	79.35	Open reduction of fracture of femur with internal fixation
189	79.36	Open reduction of fracture of tibia and fibula with internal fixation
190	7A41800	Acupuncture anesthesia, (He-Gu) 7A41800
191	7A41810	Single-handed needle insertion, (He-Gu) 7A41810
290	93.54	Application of splint
192	7A41811	Double-handed needle insertion, (He-Gu) 7A41811
193	7A51811	Double-handed needle insertion, (Yang-Xi) 7A51811
194	7U51811	Double-handed needle insertion, (Ba-Xie) 7U51811
195	80.21	Arthroscopy, shoulder
196	80.26	Arthroscopy of knee
197	80.6	Excision of semilunar cartilage of knee
198	81.51	Total hip replacement
199	81.54	Total knee replacement left
200	81.92	Joint injection
201	82.21	Excision of lesion of tendon sheath of hand
202	83.39	Excision of lesion of other soft tissue
203	83.63	Rotator cuff repair
204	84.11	Amputation of toe
205	84.15	Other amputation below knee
206	84.55	bone cement insertion
207	85.11	Closed [percutaneous] [needle] biopsy of breast
208	85.12	Open biopsy of breast
209	85.21	Local excision of lesion of breast
210	85.41	Unilateral simple mastectomy
211	86.01	Aspiration of skin and subcutaneous tissue
212	86.04	\N
213	86.11	Biopsy of skin and subcutaneous tissue
214	86.22	Excisional debridement of wound, infection, or burn
215	86.23	Removal of nail, nail bed, or nail fold
216	86.59	Closure of skin
217	87.03	CT Brain Without Contrast
218	87.37	\N
219	87.41	CT Chest with contrast
220	87.44	Routine chest x-ray
221	87.71	CT KUB
222	87.76	Ureterography
223	8717811	การนวดด้วยวิธีการแพทย์แผนไทยแบบราชสำนัก ที่สะโพก, เอว (8717811)
224	8717820	การประคบด้วยสมุนไพร ที่สะโพก, เอว (8717820)
225	88.01	CT Whole Abdomen
226	88.38	CTA Neck (Carotid Artery)
227	88.56	CAG Two Catheters
228	88.72	Echo-Transthoracic
229	88.73	\N
230	88.75	Diagnostic ultrasound of urinary system
231	88.76	Ultrasound Upper Abdomen
232	88.77	Diagnostic ultrasound of peripheral vascular system
233	88.78	Diagnostic ultrasound of gravid uterus
234	88.79	Ultrasound Endovaginal
235	88.91	MRI Brain,MRI Hippocampus
236	88.93	Magnetic resonance imaging of spinal canal
237	89.11	Tonometry
238	89.14	Electroencephalogram
239	89.44	Other cardiovascular stress test
240	89.52	EKG -- see also Electrocardiogram
241	89.65	Measurement of systemic arterial blood gases
242	89.7	General physical examination
243	8B51800	Acupuncture anesthesia, (Zu-San-Li) 8B51800
244	8B51801	Electro-acupuncture therapy, (Zu-San-Li) 8B51801
245	8B51811	Double-handed needle insertion, (Zu-San-Li) 8B51811
246	8B71800	Acupuncture anesthesia, (Tiao-Kou) 8B71800
247	8BA1800	Acupuncture anesthesia, (Jie-Xi) 8BA1800
248	8BA1811	Double-handed needle insertion, (Jie-Xi) 8BA1811
249	8BA1891	Moxa burner moxibustion, (Jie-Xi) 8BA1891
250	8D01810	Single-handed needle insertion,(Cheng-Fu) 8D01810
251	8D11801	Electro-acupuncture therapy, (Yin-Men) 8D11801
252	8D41800	Acupuncture anesthesia, (Wei-Zhong) 8D41800
253	8D41801	Electro-acupuncture therapy, (Wei-Zhong) 8D41801
254	8D41810	Single-handed needle insertion, (Wei-Zhong) 8D41810
255	8D41811	Double-handed needle insertion, (Wei-Zhong) 8D41811
256	8E21811	Double-handed needle insertion, (Cheng-Shan) 8E21811
257	8E51801	Electro-acupuncture therapy, (Kun-Lun) 8E51801
258	8E51811	Double-handed needle insertion, (Kun-Lun) 8E51811
259	8G11811	Double-handed needle insertion, (Huan-Tiao) 8G11811
260	8G21800	Acupuncture anesthesia, (Feng-shi) 8G21800
261	8G21801	Electro-acupuncture therapy, (Feng-shi) 8G21801
262	8G21811	Double-handed needle insertion, (Feng-shi) 8G21811
263	8G51800	Acupuncture anesthesia, (Yang-Ling-Quan) 8G51800
264	8G51801	Electro-acupuncture therapy, (Yang-Ling-Quan) 8G51801
265	8G51811	Double-handed needle insertion, (Yang-Ling-Quan) 8G51811
266	8GB1811	Double-handed needle insertion, (Qiu-Xu) 8GB1811
267	8GC1801	Electro-acupuncture therapy, (Zu-Lin-Qi) 8GC1801
268	8L61800	Acupuncture anesthesia, (San-Yin-Jiao) 8L61800
269	8LA1800	Acupuncture anesthesia, (Xue-Hai) 8LA1800
270	8LA1811	Double-handed needle insertion, (Xue-Hai) 8LA1811
271	8M31800	Acupuncture anesthesia, (Tai-Xi) 8M31800
272	8M71800	Acupuncture anesthesia, (Fu-Liu) 8M71800
273	8P31800	Acupuncture anesthesia, (Tai-Chong) 8P31800
274	8W51891	Moxa burner moxibustion, (Xi-Yan) 8W51891
275	8WA1811	Double-handed needle insertion ,(Ba-Feng) 8WA1811
276	9007811	การนวดด้วยวิธีการแพทย์แผนไทยแบบราชสำนัก ที่ทั่วร่างกาย (9007811)
277	9007820	การประคบด้วยสมุนไพร ที่ทั่วร่างกาย (9007820)
278	9007838	การใช้ยาบำบัดวิธีอื่น ที่ทั่วร่างกาย (9007838)
279	9007839	การใช้ยาบำบัด  ไม่ระบุวิธี ที่ทั่วร่างกาย (9007839)
280	93.12	Other active musculoskeletal exercise
281	93.14	Training in joint movements
282	93.21	Manual and mechanical traction
283	93.22	Ambulation and gait training
284	93.27	\N
285	93.34	Diathermy
286	93.35	Other heat therapy
287	93.38	Combined physical therapy without mention of the components
288	93.39	Other physical therapy
289	93.53	Application of other cast
291	93.57	Application of other wound dressing
292	93.81	\N
293	93.82	Educational therapy
294	93.83	\N
295	93.89	Rehabilitation, not elsewhere classified
296	93.90	High flow cannula
297	93.94	Therapy [nebulizer]
298	93.96	Other oxygen enrichment
299	95.09	Eye examination, not otherwise specified
300	95.41	Audiogram
301	95.46	Dix-Hall pike maneuvex
302	96.04	Insertion of endotracheal tube
303	96.07	Insertion of other (naso-)gastric tube
304	96.33	Gastric lavage
305	96.6	Enteral infusion of concentrated nutritional substances
306	96.70	Continuous invasive mechanical ventilation of unspecified duration
307	96.71	On ventilator < 96 hours
308	96.72	On ventilator >= 96 hours
309	97.64	Removal of urinary drainage device
310	98.02	Removal of intraluminal foreign body from esophagus without incision
311	98.13	Remove FB from pharynx
312	99.04	Transfusion of packed cells
313	99.05	plt transfusion
314	99.06	FFP transfusion
315	99.10	s/p rtPA
316	99.15	Parenteral infusion of concentrated nutritional substances
317	99.18	Injection or infusion of electrolytes
318	99.21	Injection of antibiotic
319	99.25	Infusion (intra-arterial) (intravenous) [antineoplastic agent (chemotherapeutic)]
320	99.29	Injection or infusion of other therapeutic or prophylactic substance
321	99.38	Administration of tetanus toxoid
322	99.52	Prophylactic vaccination against influenza
323	99.59	Other vaccination and inoculation
324	99.60	Cardiopulmonary resuscitation, not otherwise specified
325	99.62	Other electric countershock of heart
326	99.83	Phototherapy
327	9991801	Electro-acupuncture therapy 9991801
328	9991810	Single-handed needle insertion 9991810
329	9991811	Double-handed needle insertion 9991811
330	9991878	Indirect moxibustion 9991878
331	9991953	Cotton-burning cupping method 9991953
332	9991959	Cupping method 9991959
333	86.3	Excision of lesion of subcutaneous tissue
334	58.99	urinary stress incontinence --see Repair
335	70.51	with graft or prosthesis 70.54
336	83.72	Stretching
337	89.58	penile 89.58
338	96.7	hepatic, extracorporeal 50.92
339	27.73	27.73
340	56.82	56.82
341	56.89	56.89
\.


--
-- Data for Name: imed_write_ops; Type: TABLE DATA; Schema: demo_baseline; Owner: hsuyi
--

COPY demo_baseline.imed_write_ops (op_id, case_id, op, code_kind, object_id, before_json, created_at) FROM stdin;
\.


--
-- Data for Name: knowledge_base; Type: TABLE DATA; Schema: demo_baseline; Owner: hsuyi
--

COPY demo_baseline.knowledge_base (knowledge_id, source_type, content, taught_by, status, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: demo_baseline; Owner: hsuyi
--

COPY demo_baseline.users (user_id, email, oauth_provider, oauth_subject, full_name, role, status, created_at, last_login_at, password_hash) FROM stdin;
3	frank@email.com	\N	\N	Frank	coder	active	2026-08-21 05:06:33.137705	2026-08-27 13:12:55	$2a$10$GF8N2xgUJd38eqk6037DMedAaAwRcSbBdWuTwC7dvF1AUO.UbWWCy
2	ouzdim@gmail.com	\N	\N	Ouzdim	coder	active	2026-08-21 05:00:47.453072	2026-08-27 13:21:11	$2a$10$GF8N2xgUJd38eqk6037DMedAaAwRcSbBdWuTwC7dvF1AUO.UbWWCy
1	admin@medcodeai.demo	\N	\N	Super Admin	admin	active	2026-08-21 04:59:25.215459	2026-08-27 23:12:12	$2a$10$4G.PiPA1pJsEtw8VesEOvuIryrVGg53sqL7TLEG34cJRahny./Nl2
\.


--
-- Data for Name: agent_conversations; Type: TABLE DATA; Schema: public; Owner: hsuyi
--

COPY public.agent_conversations (conversation_id, user_id, mode, title, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: agent_messages; Type: TABLE DATA; Schema: public; Owner: hsuyi
--

COPY public.agent_messages (message_id, conversation_id, role, content, sources, unverified_codes, created_at) FROM stdin;
\.


--
-- Data for Name: app_settings; Type: TABLE DATA; Schema: public; Owner: hsuyi
--

COPY public.app_settings (key, value, updated_at, updated_by) FROM stdin;
caseFields.vn	true	\N	\N
caseFields.name	false	\N	\N
caseFields.hn	true	\N	\N
\.


--
-- Data for Name: auth_sessions; Type: TABLE DATA; Schema: public; Owner: hsuyi
--

COPY public.auth_sessions (session_id, user_id, refresh_token_enc, expires_at, created_at, revoked) FROM stdin;
\.


--
-- Data for Name: case_code_edits; Type: TABLE DATA; Schema: public; Owner: hsuyi
--

COPY public.case_code_edits (case_id, payload, updated_at) FROM stdin;
\.


--
-- Data for Name: case_codes; Type: TABLE DATA; Schema: public; Owner: hsuyi
--

COPY public.case_codes (case_code_id, case_id, code_role, source, imed_ref_id, assigned_by, assigned_at, icd_10_id, icd_9_id, operation_start, operation_end, operation_type) FROM stdin;
\.


--
-- Data for Name: case_orders; Type: TABLE DATA; Schema: public; Owner: hsuyi
--

COPY public.case_orders (order_id, case_id, order_category, imed_source, imed_ref_id, order_name, order_detail, ordered_at) FROM stdin;
\.


--
-- Data for Name: case_report_sections; Type: TABLE DATA; Schema: public; Owner: hsuyi
--

COPY public.case_report_sections (section_id, case_id, documenttype, fieldname, value, recorddatetime) FROM stdin;
\.


--
-- Data for Name: case_stars; Type: TABLE DATA; Schema: public; Owner: hsuyi
--

COPY public.case_stars (case_id, starred_by, starred_at) FROM stdin;
\.


--
-- Data for Name: case_vitals; Type: TABLE DATA; Schema: public; Owner: hsuyi
--

COPY public.case_vitals (vital_id, case_id, measured_at, temperature, systolic, diastolic, heart_rate, oxygen_saturation, weight, height) FROM stdin;
\.


--
-- Data for Name: cases; Type: TABLE DATA; Schema: public; Owner: hsuyi
--

COPY public.cases (case_id, patient_ref, encountertype, sex, birthdate, ageyear, admissiondatetime, dischargedatetime, dischargetype, dischargestatus, ispregnant, ward, department, coverage_type, completeness_status, missing_detail, disease_group, severity_level, case_status, fetched_at) FROM stdin;
\.


--
-- Data for Name: coding_history; Type: TABLE DATA; Schema: public; Owner: hsuyi
--

COPY public.coding_history (history_id, case_id, user_id, action_type, action_detail, created_at) FROM stdin;
\.


--
-- Data for Name: coverage_types; Type: TABLE DATA; Schema: public; Owner: hsuyi
--

COPY public.coverage_types (coverage_code, scheme_family, label_th, label_en, payer) FROM stdin;
OFC_O3	OFC	\N	\N	CGD
UCS_89_I	UCS	\N	\N	NHSO
OFC_O1	OFC	\N	\N	CGD
LGO_L2	LGO	\N	\N	NHSO
LGO_L1	LGO	\N	\N	NHSO
UCS_89	UCS	\N	\N	NHSO
WEL_73	WEL	\N	\N	NHSO
P1027	OTHER	\N	\N	\N
WEL_77_I	WEL	\N	\N	NHSO
WEL_88	WEL	\N	\N	NHSO
WEL_77	WEL	\N	\N	NHSO
OFC_O4	OFC	\N	\N	CGD
WEL_88_I	WEL	\N	\N	NHSO
VLG_L2	VLG	\N	\N	NHSO
WEL_71	WEL	\N	\N	NHSO
OFC_O5	OFC	\N	\N	CGD
LGO_L5	LGO	\N	\N	NHSO
WEL_74_I	WEL	\N	\N	NHSO
WEL_71_I	WEL	\N	\N	NHSO
WEL_82_I	WEL	\N	\N	NHSO
WEL_72_I	WEL	\N	\N	NHSO
WEL_76_I	WEL	\N	\N	NHSO
OFC_E2	OFC	\N	\N	CGD
OFC_B3	OFC	\N	\N	CGD
WEL_73_I	WEL	\N	\N	NHSO
OFC_E1	OFC	\N	\N	CGD
foreign	FOREIGN	\N	\N	\N
DIS_D1	DIS	\N	\N	NHSO
Cashonly	SELF_PAY	\N	\N	SELF
VOF_OFC	VOF	\N	\N	CGD
WEL_72	WEL	\N	\N	NHSO
WEL_81_I	WEL	\N	\N	NHSO
UCS_88	UCS	\N	\N	NHSO
\.


--
-- Data for Name: document_chunks; Type: TABLE DATA; Schema: public; Owner: hsuyi
--

COPY public.document_chunks (chunk_id, case_id, chunk_text, chunk_index, embedding_ref) FROM stdin;
\.


--
-- Data for Name: icd_10; Type: TABLE DATA; Schema: public; Owner: hsuyi
--

COPY public.icd_10 (icd_10_id, code, description) FROM stdin;
1	A02.1	Salmonella sepsis
2	A05.9	Food poisoning
3	A07.3	Isosporiasis
4	A09.0	Infectious diarrhea
5	A09.9	Acute gastroenteritis
6	A15.7	Primary respiratory tuberculosis, confirmed bacteriologically and histologically
7	A30	Leprosy [Hansen disease]
8	A31.1	Cutaneous mycobacterial infection
9	A39.2	Acute meningococcaemia
10	A39.3	Chronic meningococcaemia
11	A39.4	Meningococcaemia, unspecified
12	A41.5	Klebsiella pneumoniae septicemia
13	A41.9	Septicaemia, unspecified
14	A42.8	Other forms of actinomycosis
15	A46	Erysipelas
16	A54.8	Other gonococcal infections
17	A60.0	Herpesviral infection of genitalia and urogenital tract
18	A81.2	Progressive multifocal leukencephalopathy
19	B00.0	Eczema herpeticum
20	B00.1	Herpesviral vesicular dermatitis
21	B00.2	Herpesviral gingivostomatitis and pharyngotonsillitis
22	B00.5	Herpesviral ocular disease
23	B00.7	Disseminated herpesviral disease
24	B00.8	Other forms of herpesviral infection, specified as chronic ulcers
25	B02.9	Herpes Zoster
26	B07	Viral warts at right foot
27	B08.1	Molluscum contagiosum
28	B08.2	Roseola infantum
29	B08.8	Foot- and- mouth disease
30	B16.9	Acute viral hepatitis B
31	B18.1	chronic HBV infection
32	B18.2	Chronic viral hepatitis C
33	B20.0	HIV disease resulting in mycobacterial infection
34	B22.7	HIV disease resulting in multiple diseases classified elsewhere
35	B24	HIV disease
36	B25.8	Other cytomegaloviral diseas e, specified as retinitis
37	B25.9	Cytomegaloviral disease, unspecified, except for liver, spleen
38	B34.1	Enterovirus infection
39	B35.4	Tinea corporis
40	B37.1	Pulmonary candidiasis
41	B37.8	Candidiasis of other sites, specified as of oesophagus
42	B95.2	Enterococcus faecium form pus penis
43	B95.4	Viridans Streptococcus infection
44	B96.0	Mycoplasma pneumoniae as the cause of diseases classified to
45	B96.1	Klebsiella pneumoniae ssp pneumoniae
46	B96.2	E.coli infection
47	B96.3	Haemophilus influenzae as the cause of diseases classified to
48	B97.0	Adenovirus as the cause of diseases classified to other chapters
49	B97.1	Enterovirus as the cause of diseases classified to other chapters
50	B97.2	Coronavirus as the cause of diseases classified to other chapters
51	B97.3	Retrovirus as the cause of diseases classified to other chapters
52	B97.4	Respiratory syncytial virus as the cause of diseases classified to
53	B97.5	Reovirus as the cause of diseases classified to other chapters
54	B97.6	Parvovirus as the cause of diseases classified to other chapters
55	B97.7	Papillomavirus as the cause of diseases classified to other
56	B97.8	Other viral agents as the cause of diseases classified to other
57	B98.0	H. pylori infection
58	B98.1	Vibrio vulnificus as the cause of diseases classified to other
59	C00.8	Overlapping lesion of lip
60	C18.4	CA colon, transverse colon
61	C18.7	CA sigmoid colon, pT3N1bM1b stage IVb
62	C18.9	CA colon
63	C19	Adenocarcinoma of rectosigmoid junction with impending large bowel obstruction
64	C20	CA rectum
65	C22.0	HCC
66	C34.1	CA lung, upper lobe
67	C50.2	CA breast, upper-inner quadrant
68	C50.4	Left CA breast
69	C50.9	CA Rt breast
70	C60.9	CA penis
71	C67.9	CA bladder
72	C73	CA thyroid
73	C76	Malignant neoplasms of ill-defined sites
74	C77.5	Intrapelvic lymph node metastasis
75	C77.9	Metastasis CA to lymph node, SPC
76	C78.0	Metastasis CA to lung
77	C78.7	Metastasis CA to liver
78	C79.3	Metastasis CA to brain and cerebral meninges
79	C79.5	Metastasis CA to bone and bone marrow
80	C79.7	Metastasis CA to adrenal gland
81	C79.8	pelvic nodule metastatic adenocarcinoma
82	C79.9	Secondary malignant neoplasm, unspecified site
83	C80	Malignant neoplasm, without specification of site
84	C80.0	Malignant neoplasm, primary site unknown
85	C80.9	Malignant neoplasm, primary site unspecified
86	C83.1	Mantle cell lymphoma
87	C83.3	Diffuse non-Hodgkin's lymphoma large cell (diffuse)
88	C83.7	Burkitt lymphoma
89	C85.1	B cell lymphoma
90	C90.0	Multiple myeloma
91	C92.1	Chronic myeloid leukaemia
92	C97	Malignant neoplasms of independent (primary) multiple sites
93	D14.0	Benign neoplasm of middle ear, nasal cavity and accessory sinuses
94	D17.0	Benign lipomatous neoplasm of skin and subcutaneous tissue of head, face and neck
95	D17.1	lipoma at back
96	D17.2	Lipoma Rt hip
97	D18.0	Hemangioma
98	D25.1	Intramural leiomyoma of uterus
99	D25.9	Myoma uteri
100	D27	Dermoid Cyst, Ovary
101	D32.9	meningioma
102	D35.0	E05–E06
103	D38.6	Lung tumor
104	D41.4	Tumor of bladder
105	D46.9	MDS
106	D47.7	D50–D53
107	D50.0	Iron deﬁciency anaemia secondary to blood loss (chronic)
108	D50.9	Iron deficiency anaemia
109	D56.0	Alpha thalassaemia
110	D56.9	Thalassemia
111	D59.1	AIHA
112	D62	Anemia due to acute blood loss
113	D63.0	Anemia in neoplastic disease
114	D63.8	Anemia of CKD
115	D64.9	Anemia
116	D69.3	ITP(Idiopathic thrombocytopenic purpura)
117	D69.5	CMT induced  Thrombocytopenia
118	D69.6	Thrombocytopenia
119	D72.1	Eosinophilia
120	D89.3	Immune Reconstitution Inflammatory Syndrome (IRIS)
121	E02	Hypothyroidism, subclinical iodine def
122	E03.9	Hypothyroidism
123	E04.1	Nontoxic single thyroid nodule
124	E05.0	graves' diseaes
125	E05.9	Thyrotoxicosis
126	E11.5	DM type 2 foot with Diabetic ulcer
127	E11.9	DM Type 2 (Diabetes mellitus Type 2)
128	E12	E40–E46
129	E14.2	DM with renal complication
130	E14.3	Diabetic cataract
131	E14.9	DM unknown type
132	E24	E80.0–E80.2
133	E27.4	secondary adrenal insufficiency
134	E28.2	PCOS
135	E34.0	Carcinoid syndrome
136	E44.1	Mild protein-energy malnutrition
137	E61.1	Iron deficiency
138	E64.9	E80.0–E80.2
139	E66.0	Obesity due to excess calories
140	E66.2	Obesity with alveolar hypoventilation
141	E66.8	morbid obesity
142	E66.9	Obesity
143	E68	Sequelae of hyperalimentation
144	E78.1	Hypertriglyceridemia
145	E78.5	Hyperlipidemia
146	E78.9	DLP (Dyslipidemia)
147	E79.0	Hyperuricemia
148	E83.1	secondary hemochromatosis
149	E83.3	hypophosphatemia
150	E83.4	hypomagnesemia
151	E83.5	hypocalcemia
152	E84	Type of diabetes Due to
153	E86	Volume depletion
154	E87.1	Hyponatremia
155	E87.2	Lactic acidosis
156	E87.5	Hyperkalemia
157	E87.6	Hypokalemia
158	E87.7	volume overload
159	E89.0	Hypothyroidism, postprocedural
160	E89.1	F10.1–F10.2
161	F02.3	Dementia in Parkinson's disease
162	F03	Dementia
163	F11	F13–F16
164	F20.0	Paranoid schizophrenia
165	F31	Bipolar affective disorder
166	F31.9	Bipolar affective disorder
167	F32.2	major depressive disorder
168	F32.9	Depression
169	F33	Recurrent depressive disorder
170	F33.0	Recurrent depressive disorder, current episode mild, Without somatic symptoms
171	F33.9	Recurrent depressive disorder
172	F40.1	Social phobias
173	F41.0	Panic disorder [episodic  paroxysmal anxiety]
174	F41.1	Generalized anxiety disorder
175	F42	Obsessive-compulsive disorder
176	F43.0	Acute stress reaction
177	F60.3	Emotionally unstable personality disorder
178	F61	Mixed and other personality disorders
179	F69	Unspeciﬁed disorder of adult personality and behaviour
180	F71.9	Moderate mental retardation: without mention of impairment of behaviour
181	F80.0	Specific speech articulation disorder
182	F81.9	Developmental disorder of scholastic skills, unspecified
183	F84.0	Childhood autism
184	F90.9	ADHD
185	G00.9	Bacterial meningitis
186	G03	Meningitis due to other and unspecified causes
187	G09	Sequelae of inflammatory diseases of central nervous system
188	G20	Parkinson's disease
189	G25.5	Other chorea
190	G40.2	Complex partial seizures
191	G40.6	Grand mal seizures
192	G43.9	Migraine headache
193	G46.7	Lacunar syndromes
194	G47.0	Insomnia
195	G47.3	obstructive sleep apnea
196	G51.0	Bell's palsy
197	G56.0	Carpal tunnel syndrome
198	G57.5	Tarsal tunnel syndrome
199	G58.7	Mononeuritis multiplex
200	G62.9	Rt. sciatic neuropathy
201	G70.0	Myasthenia gravis
202	G81.0	Flaccid hemiplegia
203	G81.1	Spastic hemiplegia
204	G81.9	Right Hemiparesis
205	G82.0	Flaccid paraplegia
206	G90.0	Idiopathic peripheral autonomic neuropathy
207	G91.1	Hydrocephalus
208	G93.4	Encephalopathy, unspecified
209	H00.0	Hordeolum
210	H00.1	Chalazion
211	H01.0	Blepharitis
212	H02.8	dermatochalasis
213	H04.1	Dry eye
214	H05.0	preseptal cellulitis
215	H10.1	Allergic conjunctivitis
216	H10.3	Acute conjunctivitis
217	H11.1	Pinguecula
218	H46	Optic neuritis
219	H52.1	Myopia
220	H55	Nystagmus and other irregular eye movements
221	H61.2	Impacted cerumen
222	H72.0	TM perforation Rt. ear ,Central
223	H73.0	Acute myringitis
224	H81.1	BPPV
225	H81.3	Peripheral vertigo
226	H90.3	Sensorineural hearing loss, bilateral
227	H90.5	Sensorineural hearing loss
228	H93.1	Tinnitus
229	I05.8	Other mitral valve diseases, or Heart disease
230	I05.9	Mitral valve disease, unspecified
231	I09.1	Rheumatic diseases of endocardium, valve unspecified
232	I09.9	Rheumatic heart disease, unspecified
233	I10	Essential HT
234	I15.0	Renovascular hypertension
235	I15.1	Hypertension secondary to other renal disorders
236	I15.2	Hypertension secondary to endocrine disorders
237	I15.8	Other secondary hypertension
238	I15.9	HT in young
239	I21.4	NSTEMI
240	I24.0	Coronary thrombosis not resulting in myocardial infarction
241	I25.1	CAD(Coronary artery disease)
242	I25.2	Old myocardial infarction
243	I26.0	Acute Pulmonary embolism with RV failure
244	I26.9	Pulmonary embolism
245	I27.9	Pulmonary heart disease, unspecified
246	I34.1	Mitral valve prolapse
247	I46.1	Sudden cardiac death, so described
248	I46.9	Cardiac arrest, unspeciﬁed
249	I47.1	SVT
250	I48	Atrial fibrillation
251	I48.9	AF
252	I49.1	PAC
253	I49.3	Premature ventricular contractions
254	I50.0	CHF
255	I50.9	Heart failure, unspecified
256	I51.9	Heart disease, unspecified, except when specified as terminal
257	I61.0	basal ganglia hemorrhage
258	I61.1	Lt. basal ganglion hemorrhage
259	I63.3	Cerebral infarction of cerebral arteries due to thrombosis
260	I67.2	Cerebral atherosclerosis
261	I69.1	Sequelae of cerebrovascular disease
262	I69.2	Sequelae of nontraumatic intracranial hemorrhage
263	I69.3	Sequelae of cerebral infarction
264	I69.4	Sequelae of cerebrovascular disease
265	I70.9	Generalized and unspecified atherosclerosis
266	I71.1	Thoracic aortic aneurysm, ruptured
267	I71.2	Thoracic aortic aneurysm, without mention of rupture
268	I71.3	Abdominal aortic aneurysm, ruptured
269	I71.4	Abdominal aortic aneurysm, without mention of rupture
270	I71.9	Aortic aneurysm
271	I73.9	PVD(Peripheral vascular disease)
272	I78.1	Nevus, non-neoplastic
273	I80.2	DVT
274	I80.9	Phlebitis and thrombophlebitis of unspeciﬁed site
275	I82.9	Embolism and thrombosis of unspeciﬁed vein
276	I87.2	Venous insufficiency (chronic)(peripheral)
277	I95.9	Hypotension
278	I99	Other and unspeciﬁed disorders of circulatory system
279	J00	Common cold
280	J01.9	Acute sinusitis
281	J02.9	Acute pharyngitis
282	J03.9	Acute tonsillitis
283	J05.0	Croup
284	J05.1	Acute epiglottitis
285	J10.1	Influenza A positive
286	J15.0	Pneumonia due to Klebsiella pneumoniae
287	J15.6	pneumonia Acinetobacter baumannii
288	J15.9	Bacterial pneumonia
289	J16	Pneumonia due to other infectious organisms, not elsewhere
290	J18.1	Lobar pneumonia
291	J18.9	Pneumonia
292	J20.9	Acute bronchitis
293	J30.4	Allergic rhinitis
294	J31.0	Chronic rhinitis
295	J32.0	Chronic maxillary sinusitis
296	J32.9	Chronic sinusitis
297	J33.9	Nasal polyp
298	J34.2	Deviated nasal septum
299	J40	Bronchitis, not specified as acute or chronic
300	J42	Unspecified chronic bronchitis
301	J44.0	COPD with acute lower respiratory infection
302	J44.1	COPD with acute exacerbation
303	J44.9	COPD
304	J45.9	Bronchial hyperresponsiveness (TM)
305	J46	Status asthmaticus
306	J47	Bronchiectasis
307	J81	Pulmonary oedema
308	J90	Pleural effusion
309	J96.0	Acute respiratory failure
310	J96.00	Acute respiratory failure Type I
311	J96.09	Acute respiratory failure type IV
312	J96.9	Respiratory failure, unspeciﬁed
313	J98.4	lung nodule
314	K01	Embedded and impacted teeth
315	K01.0	Embedded and impacted teeth
316	K04.01	Acute pulpitis
317	K12.0	Apthus ulcer
318	K12.2	Deep neck infection
319	K14.0	Glossitis
320	K20	Esophagitis
321	K21.9	GERD
322	K22.1	Esophageal ulcer
323	K25.3	Gastric ulcer: acute without haemorrhage or perforation
324	K27	Peptic ulcer, site unspecified
325	K29.1	Acute gastritis
326	K29.9	Gastroduodenitis.
327	K30	Functional dyspepsia
328	K31.9	Duodenal lesion
329	K35.3	Acute suppurative appendicitis with localized peritonitis
330	K35.8	Acute appendicitis
331	K43.2	Incisional hernia without obstruction or gangrene
332	K55.0	omental infarction
333	K56.4	Other impaction of intestine
334	K56.6	Large bowel obstruction due to tumor
335	K57.1	Diverticular disease of large intestine
336	K57.3	Diverticulosis of colon
337	K57.5	cecal diverticula and ileal diverticula
338	K57.9	Acute diverticulitis
339	K58.0	IBS with diarrhea
340	K59.0	neuropathic bowel
341	K62.0	Anal canal polyp
342	K63.5	Polyp of colon
343	K64.1	Hemorrhoid Grade 2
344	K64.2	Hemorrhoid Grade 3
345	K64.8	Internal hemorrhoid
346	K64.9	Hemorrhoid
347	K70.0	Alcoholic fatty liver
348	K70.3	Alcoholic cirrhosis of liver
349	K70.4	K73.- (Chronic hepatitis, not elsewhere classified), code
350	K71	Toxic liver disease
351	K74.0	Hepatic fibrosis
352	K74.1	Hepatic sclerosis
353	K74.2	Hepatic fibrosis with hepatic sclerosis
354	K74.6	cirrhosis of liver
355	K75.8	Other specified inflammatory liver diseases, if specified as
356	K75.9	Inflammatory liver disease, unspecified
357	K76.0	Fatty liver
358	K76.9	Liver disease, unspecified
359	K80.2	symptomatic gallstone
360	K80.3	Bile duct stone with cholangitis
361	K80.4	Calculus of bile duct with cholecystitis
362	K83.1	dilated cbd
363	K85	K86.0–K86.1
364	K85.9	Acute pancreatitis, unspecified
365	K92.2	UGIB
366	L01	Impetigo
367	L02.1	Abcess, neck
368	L02.4	Abscess, hip
369	L03	Cellulitis
370	L03.0	Paronychia
371	L03.1	Left lower leg cellulituis
372	L04.0	Acute lymphadenitis
373	L08.9	Infected wound
374	L22	Diaper [napkin] dermatitis
375	L23.9	Allergic contact dermatitis
376	L30.1	Dyshidrosis [pompholyx]
377	L30.9	chronic eczema
378	L42	Pityriasis rosea
379	L50.9	Acute urticaria
380	L63.9	Alopecia areata
381	L70.9	Acne
382	L72.1	sebaceous cyst
383	L80	Vitiligo
384	L83	Acanthosis nigricans
385	L84	Callus
386	L85.3	Xerosis cutis
387	L89	Decubitus ulcer
388	L91.0	Keloid scar
389	M05.89	Other seropositive rheumatoid arthritis
390	M06.99	Rheumatoid arthritis
391	M10.09	Gouty arthritis
392	M10.99	Gout
393	M17.0	OA Knee,bilateral
394	M17.1	OA left knee
395	M25.54	Pain in joint: intercarpal/finger joint
396	M25.56	Pain in joint: knee joint
397	M25.59	polyarthralgia
398	M35.3	Polymyalgia rheumatica
399	M41.29	Idiopathic scoliosis
400	M43.16	Spondylolisthesis, lumbar region
401	M43.17	Spondylolisthesis, lumbosacral region
402	M43.19	Spondylolisthesis
403	M43.6	Torticollis, unspeciﬁed
404	M47.22	CSR
405	M47.26	Other spondylosis with radiculopathy: lumbar region
406	M47.8	Other spondylosis
407	M47.96	Lumbar spondylosis
408	M48.0	Spinal stenosis, (except for the cervical region)
409	M48.06	SCS L-spine
410	M48.07	SCS LS-spine
411	M48.09	\N
412	M49.47	Neuropathic spondylopathy: lumbosacral region
413	M50.9	Cervical disc disorder
414	M51.1	Lumbar disc disorder with radiculopathy
415	M51.2	HNP
416	M54.19	radiculopathy in Spinal stenosis
417	M54.5	Low back pain
418	M54.9	back pain
419	M62.60	Muscle strain, multiple sites
420	M62.61	Muscle strain, shoulder region
421	M62.64	Muscle strain, hand
422	M62.66	Muscle strain, lower leg
423	M62.68	\N
424	M62.69	Muscle strain
425	M65.2	Calcific tendinitis
426	M65.34	Trigger finger
427	M65.43	dequevain
428	M72.2	Plantar fasciitis
429	M75.0	Frozen Shoulder
430	M75.1	Rotator cuff tear of left shoulder (supraspinatus, high-grade partial bursal side tear)
431	M75.2	Biceps tenosynovitis
432	M75.4	Subacromial impingement with spur
433	M76.6	Achilles tendinitis
434	M77.1	Tennis elbow
435	M77.94	Tendinitis Rt wrist
436	M77.99	Tendinitis
437	M79.29	neuropathic pain
438	M79.70	Myofascial pain in limb Multiple sites
439	M79.71	Myofascial pain in limb Shoulder region
440	M79.78	Fibromyalgia: other site
441	M79.79	Myofascial pain in limb
442	M79.89	Myofascial pain syndrome
443	M85.89	Bone density disorder
444	M94.0	Costrochondritis
445	M94.2	Chondromalacia
446	N04	Nephrotic syndrome deny kidney bx
447	N10	Acute pyelonephritis
448	N13.1	Hydronephrosis with ureteral stricture
449	N13.6	Lt UC with moderate to severe HN with UTI
450	N17.9	Acute kidney injury
451	N18.2	CKD stage 2
452	N18.3	CKD stage 3
453	N18.5	ESRD(End-stage renal disease)
454	N19	Unspecified kidney failure
455	N20.0	Renal calculi
456	N21.0	bladder stone
457	N26	Unspecified contracted kidney
458	N28.0	Rt renal infraction
459	N30.0	Acute cystitis
460	N30.9	Cystitis
461	N31	Neuromuscular dysfunction of bladder, not elsewhere
462	N31.2	Flaccid neuropathic bladder
463	N39.0	Urinary tract infection
464	N39.3	Stress incontinence
465	N40	BPH
466	N45	Orchitis and epididymitis
467	N46	Male infertility
468	N47	Redundant prepuce, phimosis, and paraphimosis
469	N48.1	Balanitis
470	N60.1	cysts both breasts
471	N61	Inflammatory disorders of breast
472	N63	Breast mass
473	N64.4	Breast pain
474	N73.9	PID
475	N80.0	Adenomyosis
476	N81.3	prolapsed uteri grade III
477	N86	Erosion and ectropion of cervix uteri
478	N87.0	LSIL
479	N89.8	Leukorrhea
480	N91.1	Secondary amenorrhoea
481	N93.8	DUB
482	N93.9	Abnormal uterine and vaginal bleeding
483	N94.6	Dysmenorrhea
484	N95.1	Menopausal and female climacteric states
485	N95.9	perimenopausal symptoms
486	N96	Habitual aborter
487	O33.9	maternal care due to CPD
488	O71.6	Obstetric damage to pelvic joints and ligaments
489	O82.0	Delivery by elective caesarean section
490	O94	Sequelae of complication of pregnancy, childbirth and the
491	P00.0	Severe birth asphyxia is coded at (b) and hydrocephalus at (a)
492	P02.0	Light for dates with fetal malnutrition is coded at (a)
493	P05.0	Light for dates
494	P10.0	Massive inhalation of meconium
495	P22.0	Respiratory distress syndrome
496	P24.0	Prolonged pregnancy
497	P28.5	Respiratory failure of newborn
498	P59.9	Neonatal jaundice
499	P83.1	Erythema Toxicum Neonatorum
500	Q03.9	Hydrocephalus
501	Q10.0	Congenital ptosis
502	Q25.0	PDA
503	Q28.2	Arteriovenous malformation of cerebral vessels
504	Q38.1	Tongue tie
505	Q44.6	Cystic disease of liver
506	Q81.0	Epidermolysis bullosa simplex
507	Q82.8	skin tag
508	R00.2	Palpitations
509	R04.2	Hemoptysis
510	R05	Cough
511	R06.5	Snoring
512	R10.1	Dyspepsia
513	R10.2	Pelvic pain
514	R10.4	Abdominal pain
515	R13	Dysphagia
516	R18	Ascites
517	R20.8	Numbness
518	R31	gross hematuria
519	R39.2	Prerenal azotremia
520	R42	Dizziness
521	R47.0	Dysphasia and aphasia
522	R50.9	AFI
523	R51	Headache
524	R53	Fatique
525	R56.8	seizure
526	R57.2	septic shock
527	R60.0	Leg edema
528	R60.9	Edema cause
529	R64	Cachexia
530	R65.0	Systemic inflammatory response syndrome of infectious origin
531	R65.1	Systemic inflammatory response syndrome of infectious origin
532	R65.9	Systemic inflammatory response syndrome, unspecified
533	R73.0	IFG (impaired glucose tolerance)
534	R73.9	Hyperglycemia
535	R75	Laboratory evidence of human immunodeficiency virus [HIV]
536	R91	Suspected CA lung
537	R94.5	Transaminitis
538	S01.8	laceration wound at head
539	S15	S17–S19
540	S30.2	Rt scrotal hematoma
541	S41.1	Large LW upper arm Rt
542	S42.30	Closed Fracture of shaft of humerus.
543	S45	S47–S49
544	S46.0	Injury of tendon of the rotator cuff of shoulder
545	S50.8	Lt.forearm
546	S50.80	Abrasion of elbow and forearm
547	S52.509	Closed Fracture of distal radius, unspecified (TM)
548	S55	S57–S59
549	S61.0	Open wound of finger(s)
550	S62.21	Fracture 1st MCP, open
551	S65	S67–S69
552	S75	S77–S79
553	S83.6	Sprain and strain of knee
554	S85	S87–S89
555	S90.80	Abrasion of ankle and foot
556	S93.4	Ankle sprain
557	S95	S97–S99
558	T09.0	Superﬁcial injury of trunk, level unspeciﬁed
559	T09.1	T09.8–T09.9
560	T11.0	Superﬁcial injury of upper limb, level unspeciﬁed
561	T13.0	Superﬁcial injury of lower limb, level unspeciﬁed
562	T14.0	Superﬁcial injury of unspeciﬁed body region
563	T14.5	T14.7–T14.9
564	T17.2	Foreign body in soft tissue
565	T20.1	Burn of ﬁrst degree of head and neck
566	T21.1	Burn of ﬁrst degree of trunk
567	T22.1	Burn of ﬁrst degree of shoulder and upper limb, except wrist and hand
568	T23.1	Burn of ﬁrst degree of wrist and hand
569	T24.1	Burn of ﬁrst degree of hip and lower limb, except ankle and foot
570	T25.1	Burn of ﬁrst degree of ankle and foot
571	T30.2	Burn, 2nd degree
572	T37.5	T38.0–T38.1
573	T80.2	T80.8–T80.9
574	T90.1	T90.8–T90.9
575	U57.21	ลมปลายปัตฆาตไหล่ U57.21
576	U57.30	ลมปลายปัตฆาตโค้งคอ U57.30
577	U57.31	ลมปลายปัตฆาตสัญญาณ 1 หลัง U57.31
578	U57.32	ลมปลายปัตฆาตสัญญาณ 3 หลัง U57.32
579	U57.33	ลมปลายปัตฆาตสัญญาณ 4 หลัง / คอ U57.33
580	U57.34	ลมปลายปัตฆาตสัญญาณ 5 หลัง / คอ U57.34
581	U59.06	นหารูพิการ หรือ เส้นเอ็นพิการ U59.06
582	U61.4	สันนิบาตลูกนก U61.4
583	U69.84	ท้องผูก U69.84
584	U78.011	Stomach duct pain   U78.011
585	U78.028	Constipation U78.028
586	U78.081	Dry cough   U78.081
587	U78.117	Hemiplegia U78.117
588	U78.125	Dementia U78.125
589	U78.250	Impediment disease   U78.250
590	U78.256	Bone impediment   U78.256
591	U78.257	Flesh impediment   U78.257
592	U78.288	Sweating from the palms and soles U78.288
593	U78.403	Herpes zoster U78.403
594	U78.422	Urticaria U78.422
595	U78.490	Generalized pain U78.490
596	U78.493	Lumbago U78.493
597	U78.824	Allergic rhinitis   U78.824
598	U78.906	Impediment of the sinew   U78.906
599	U79.427	Lung heat pattern / syndrome   U79.427
600	V22.49	ขี่ MC ชน MC
601	V28.49	MC ล้มเอง(คนขับ)
602	V29	Motorcycle rider injured in transport accidents
603	W01.99	ล้ม
604	W22.09	โดนกระแทก
605	W45.99	ก้างปลาติดในลำคอ.
606	W54.99	Dog Bite
607	W57.0	Bitten or stung by nonvenomous insect and other nonvenomous arthropods
608	W57.99	Insect Bite
609	X98	Assault by steam, hot vapours and hot objects
610	X99	Assault by sharp object
611	Y41.1	IRZE-induced IRIS
612	Y43.1	Ragorafenib-induced hypertension
613	Y43.3	mFOLFOX6-induced anemia/thrombocytopenia
614	Y64	Y83–Y84
615	Z00.0	Check up
616	Z00.1	Well baby examination
617	Z01.6	Radiological examination
618	Z01.7	Laboratory examination
619	Z02.4	Driving licence
620	Z02.7	ขอใบรับรองแพทย์ ต่อสัญญาจ้าง
621	Z09.8	Follow up after treatment
622	Z09.9	Follow up
623	Z12.1	Special screening examination for neoplasm of intestinal tract
624	Z12.3	Special screening examination for neoplasm of breast
625	Z20.1	Contact with TB
626	Z24.2	Rabies Vaccination
627	Z24.6	Hepatitis B Vaccination
628	Z27.4	MMR Vaccination
629	Z30.0	Counselling for contraception
630	Z30.9	Contraceptive management
631	Z34.0	ANC for first pregnancy
632	Z34.8	ANC
633	Z37.0	Single live birth
634	Z38.0	Singleton, born in hospital
635	Z39	Postpartum care and examination
636	Z42.9	Follow up care for plastic surgery
637	Z43.0	Attention to tracheostomy
638	Z47.8	Fracture humerus, shaft, closed
639	Z48.0	f/u wound at lateral canthal area
640	Z49.1	Extracorporeal dialysis
641	Z51.1	Chemotherapy for neoplasm
642	Z51.4	pre-op evaluation
643	Z53.2	ยกเลิกตรวจ
644	Z53.8	มาทำนัด
645	Z58.1	Exposure to air pollution
646	Z72.1	Chronic alcohol drinking
647	Z76.0	Refill medication
648	Z76.2	Health supervision and care of other healthy infant and child
649	Z95.2	s/p AVR
650	Z95.4	Presence of heart valve replacement
651	E11.65	Type 2 diabetes mellitus with hyperglycaemia
652	V89.2	Person injured in unspecified motor-vehicle accident, traffic
653	F98.0	F98.0
654	F98.9	F98.9
655	G43.0	G43.0
656	G43.2	G43.2
657	G43.3	G43.3
658	G43.8	G43.8
\.


--
-- Data for Name: icd_9; Type: TABLE DATA; Schema: public; Owner: hsuyi
--

COPY public.icd_9 (icd_9_id, code, description) FROM stdin;
1	00.24	IVUS (Intravascular imaging of coronary vessels)
2	00.40	1vv ; Procedure on single vessel
3	00.45	Stent 1 ; Insertion of one vascular stent
4	00.66	PCI at LCX
5	01.24	Other craniotomy
6	03.09	Other exploration and decompression of spinal canal
7	03.31	Lumbar puncture
8	03.91	Injection of anesthetic into spinal canal for analgesia
9	04.43	Release of carpal tunnel
10	06.2	Unilateral thyroid lobectomy
11	06.39	Other partial thyroidectomy
12	06.4	Complete thyroidectomy
13	08.20	Removal of lesion of eyelid, not otherwise specified
14	09.81	Dacryocystorhinostomy [DCR]
15	10.0	Removal of embedded foreign body from conjunctiva by incision
16	13.41	Phacoemulsification and aspiration of cataract
17	13.71	Insertion of intraocular lens prosthesis at time of cataract extraction
18	18.29	Excision or destruction of other lesion of external ear
19	19.4	Myringoplasty
20	1B41811	Double-handed needle insertion, (Di-Cang) 1B41811
21	1B61811	Double-handed needle insertion, (Jia-Che) 1B61811
22	1C21800	Acupuncture anesthesia, (Ting-Gong) 1C21800
23	1J21800	Acupuncture anesthesia, (Bai-Hui) 1J21800
24	1J21810	Single-handed needle insertion, (Bai-Hui) 1J21810
25	1J21811	Double-handed needle insertion, (Bai-Hui) 1J21811
26	1J21891	Moxa burner moxibustion, (Bai-Hui) 1J21891
27	1J51810	Single-handed needle insertion, (Shang-Xing) 1J51810
28	1J61811	Double-handed needle insertion, (Shen-Ting) 1J61811
29	1R11810	Single-handed needle insertion, (Si-Shen-Cong) 1R11810
30	1R11811	Double-handed needle insertion, (Si-Shen-Cong) 1R11811
31	1R31811	Double-handed needle insertion, (Yin-Tang) 1R31811
32	1R51811	Double-handed needle insertion, (Tai-Yang) 1R51811
33	20.01	Myringotomy with insertion of tube
34	21.03	Control of epistaxis by cauterization and packing
35	21.21	Nasal endoscope
36	21.22	Biopsy of nose
37	21.31	Local excision or destruction of intranasal lesion
38	23.01	Forceps extraction of tooth
39	23.09	Extraction of other tooth
40	23.19	Surgical removal of tooth
41	27.0	Incision and drainage of submandibular area
42	27.59	Other plastic repair of mouth
43	28.2	Tonsillectomy without adenoidectomy
44	28.3	Tonsillectomy with adenoidectomy
45	2A11811	Double-handed needle insertion, (Fu-Tu) 2A11811
46	2D01811	Double-handed needle insertion, (Tian-Zhu) 2D01811
47	2G01800	Acupuncture anesthesia, (Feng-Chi) 2G01800
48	2G01811	Double-handed needle insertion, (Feng-Chi) 2G01811
49	2J01810	Single-handed needle insertion, (Da-Zhui) 2J01810
50	2J21810	Single-handed needle insertion, (Feng-Fu) 2J21810
51	2R41801	Electro-acupuncture therapy, (Jing-Bai-Lao) 2R41801
52	2R41810	Single-handed needle insertion, (Jing-Bai-Lao) 2R41810
53	31.1	Temporary tracheostomy
54	31.42	laryngoscopy
55	33.22	Fiber-optic bronchoscopy
56	33.24	Closed [endoscopic] biopsy of bronchus
57	34.04	Insertion of intercostal catheter for drainage
58	34.91	Thoracocentesis
59	36.06	Insertion of non-drug-eluting coronary artery stent(s)
60	36.07	Stent DES ; Insertion of drug-eluting coronary artery stent(s)
61	37.20	Noninvasive programmed electrical stimulation [NIPS]
62	37.22	Left heart cardiac catheterization
63	37.78	Insertion of temporary transvenous pacemaker system
64	37.83	Initial insertion of dual-chamber pacemaker device
65	38.93	Venous catheterization, not elsewhere classified
66	38.94	C-line Insertion
67	38.95	Venous catheterization for renal dialysis
68	39.27	Arteriovenostomy for renal dialysis
69	39.50	Angioplasty of other non-coronary vessel(s)
70	39.95	Extracorporeal [hemodialysis]
71	40.11	Biopsy of lymphatic structure
72	41.31	Biopsy of bone marrow
73	42.23	Esophagoscopy
74	42.92	Dilation of esophagus
75	43.11	Percutaneous [endoscopic] gastrostomy [PEG]
76	44.13	Other gastroscopy
77	44.43	Endoscopic control of gastric or duodenal bleeding
78	45.13	Other endoscopy of small intestine
79	45.16	EGD (esophagogastroduodenoscopy) [with closed biopsy]
80	45.23	Colonoscopy
81	45.25	Closed [endoscopic] biopsy of large intestine
82	45.42	Endoscopic polypectomy of large intestine
83	47.01	Laparoscopic appendectomy
84	47.09	Appendectomy
85	48.23	PROCTOSCOPY
86	48.36	[Endoscopic] polypectomy of rectum
87	48.63	Low anterior resection
88	49.45	Ligation of hemorrhoids
89	49.46	Hemorrhoidectomy
90	4B61810	Single-handed needle insertion, (Tian-Shu) 4B61810
91	4B61811	Double-handed needle insertion, (Tian-Shu) 4B61811
92	4H31811	Double-handed needle insertion, (Guan-Yuan) 4H31811
93	4H51811	Double-handed needle insertion, (Qi-Hai) 4H51811
94	4HC1811	Double-handed needle insertion, (Shang-Wan) 4HC1811
95	50.11	Closed (percutaneous) [needle] biopsy of liver
96	51.10	ERCP(Endoscopic Retrograde Cholangio Pancreatography)
97	51.22	Cholecystectomy
98	51.23	Laparoscopic cholecystectomy
99	53.00	Unilateral repair of inguinal hernia, not otherwise specified
100	53.05	Repair of inguinal hernia with graft or prosthesis
101	53.49	Other umbilical herniorrhaphy
102	54.11	Exploratory laparotomy
103	54.21	Laparoscopy
104	54.23	biopsy of pelvic metastatic nodule
105	54.91	Percutaneous abdominal drainage
106	55.03	Percutaneous nephrostomy without fragmentation
107	55.23	Closed [percutaneous] biopsy of kidney
108	57.32	Cystoscope
109	57.94	Insertion of indwelling urinary catheter
110	58.6	Dilation of urethra
111	59.8	Double J insertion
112	5907811	การนวดด้วยวิธีการแพทย์แผนไทยแบบราชสำนัก ที่หลัง (5907811)
113	5907820	การประคบด้วยสมุนไพร ที่หลัง (5907820)
114	5C11800	Acupuncture anesthesia, (Tian-Zong) 5C11800
115	5C11801	Electro-acupuncture therapy, (Tian-Zong) 5C11801
116	5C11810	Single-handed needle insertion, (Tian-Zong) 5C11810
117	5C11811	Double-handed needle insertion, (Tian-Zong) 5C11811
118	5C21800	Acupuncture anesthesia, (Bing-Feng) 5C21800
119	5D31810	Single-handed needle insertion, (Fei-Shu) 5D31810
120	5D51811	Double-handed needle insertion, (Xin-Shu) 5D51811
121	5D71801	Electro-acupuncture therapy, (Ge-Shu) 5D71801
122	5D71811	Double-handed needle insertion, (Ge-Shu)  5D71811
123	5DD1800	Acupuncture anesthesia, (Shen-Shu) 5DD1800
124	5DD1801	Electro-acupuncture therapy, (Shen-Shu) 5DD1801
125	5DD1810	Single-handed needle insertion, (Shen-Shu) 5DD1810
126	5DD1811	Double-handed needle insertion, (Shen-Shu) 5DD1811
127	5DF1800	Acupuncture anesthesia, (Da-Chang-Shu) 5DF1800
128	5DF1801	Electro-acupuncture therapy, (Da-Chang-Shu) 5DF1801
129	5DF1811	Double-handed needle insertion, (Da-Chang-Shu) 5DF1811
130	5E41801	Electro-acupuncture therapy, (Zhi-Shi) 5E41801
131	5E61811	Double-handed needle insertion, (Zhi-Bian) 5E61811
132	5J21800	Acupuncture anesthesia, (Yao-Yang-Guan) 5J21800
133	5T01811	Double-handed needle insertion, (Jia-ji) 5T01811
134	60.11	Closed [percutaneous] [needle] biopsy of prostate
135	60.29	Other transurethral prostatectomy
136	61.0	explore scrotum stop bleeding
137	61.2	Excision of hydrocele (of tunica vaginalis)
138	61.3	clot evacuation
139	62.5	Orchiopexy
140	64.0	Circumcision
141	65.29	Other local excision or destruction of ovary
142	65.41	Laparoscopic unilateral salpingo-oophorectomy
143	66.29	Other bilateral endoscopic destruction or occlusion of fallopian tubes
144	66.51	Total bilateral salpingectomy
145	67.32	Destruction of lesion of cervix by cauterization
146	68.16	Closed biopsy of uterus
147	68.49	Other and unspecified total abdominal hysterectomy
148	68.51	Colpohysterectomy [laparoscopically assisted (LAVH)]
149	69.02	Dilation and curettage following delivery or abortion
150	69.09	Other dilation and curettage of uterus
151	6A41800	Acupuncture anesthesia, (Shou-San-Li) 6A41800
152	6A41801	Electro-acupuncture therapy, (Shou-San-Li) 6A41801
153	6A41810	Single-handed needle insertion, (Shou-San-Li) 6A41810
154	6A41811	Double-handed needle insertion, (Shou-San-Li) 6A41811
155	6A51800	Acupuncture anesthesia, (Qu-Chi) 6A51800
156	6A51810	Single-handed needle insertion, (Qu-Chi) 6A51810
157	6A51811	Double-handed needle insertion, (Qu-Chi) 6A51811
158	6A81800	Acupuncture anesthesia, (Bi-Nao) 6A81800
159	6A81801	Electro-acupuncture therapy, (Bi-Nao) 6A81801
160	6A81811	Double-handed needle insertion, (Bi-Nao) 6A81811
161	6A91800	Acupuncture anesthesia, (Jian-Yu) 6A91800
162	6A91801	Electro-acupuncture therapy, (Jian-Yu) 6A91801
163	6A91811	Double-handed needle insertion, (Jian-Yu) 6A91811
164	6C41800	Acupuncture anesthesia, (Jian-Zhen) 6C41800
165	6F11800	Acupuncture anesthesia, (Wai-Guan) 6F11800
166	6F11811	Double-handed needle insertion, (Wai-Guan) 6F11811
167	6FA1800	Acupuncture anesthesia, (Jian-Liao) 6FA1800
168	6FA1811	Double-handed needle insertion, (Jian-Liao) 6FA1811
169	6G01800	Acupuncture anesthesia, (Jian-Jing) 6G01800
170	6G01801	Electro-acupuncture therapy, (Jian-Jing) 6G01801
171	6G01810	Single-handed needle insertion, (Jian-Jing) 6G01810
172	6G01811	Double-handed needle insertion, (Jian-Jing) 6G01811
173	6K41811	Double-handed needle insertion, (Lie-Que) 6K41811
174	6N41800	Acupuncture anesthesia, (Nei-Guan) 6N41800
175	71.22	Incision of Bartholin's gland (cyst)
176	71.79	vaginal repair
177	7217811	การนวดด้วยวิธีการแพทย์แผนไทยแบบราชสำนัก ที่ไหล่, บ่า (7217811)
178	7217820	การประคบด้วยสมุนไพร ที่ไหล่, บ่า (7217820)
179	7217839	การใช้ยาบำบัด  ไม่ระบุวิธี ที่ไหล่, บ่า (7217839)
180	7267811	การนวดด้วยวิธีการแพทย์แผนไทยแบบราชสำนัก ที่มือ  (7267811)
181	73.59	Other manually assisted delivery
182	73.6	Episiotomy
183	74.1	Low cervical cesarean section
184	77.29	Wedge osteotomy
185	78.69	Removal of implanted devices from bone, other
186	79.01	Closed reduction of fracture of humerus without internal fixation
187	79.31	Open reduction of fracture with internal fixation, humerus
188	79.35	Open reduction of fracture of femur with internal fixation
189	79.36	Open reduction of fracture of tibia and fibula with internal fixation
190	7A41800	Acupuncture anesthesia, (He-Gu) 7A41800
191	7A41810	Single-handed needle insertion, (He-Gu) 7A41810
290	93.54	Application of splint
192	7A41811	Double-handed needle insertion, (He-Gu) 7A41811
193	7A51811	Double-handed needle insertion, (Yang-Xi) 7A51811
194	7U51811	Double-handed needle insertion, (Ba-Xie) 7U51811
195	80.21	Arthroscopy, shoulder
196	80.26	Arthroscopy of knee
197	80.6	Excision of semilunar cartilage of knee
198	81.51	Total hip replacement
199	81.54	Total knee replacement left
200	81.92	Joint injection
201	82.21	Excision of lesion of tendon sheath of hand
202	83.39	Excision of lesion of other soft tissue
203	83.63	Rotator cuff repair
204	84.11	Amputation of toe
205	84.15	Other amputation below knee
206	84.55	bone cement insertion
207	85.11	Closed [percutaneous] [needle] biopsy of breast
208	85.12	Open biopsy of breast
209	85.21	Local excision of lesion of breast
210	85.41	Unilateral simple mastectomy
211	86.01	Aspiration of skin and subcutaneous tissue
212	86.04	\N
213	86.11	Biopsy of skin and subcutaneous tissue
214	86.22	Excisional debridement of wound, infection, or burn
215	86.23	Removal of nail, nail bed, or nail fold
216	86.59	Closure of skin
217	87.03	CT Brain Without Contrast
218	87.37	\N
219	87.41	CT Chest with contrast
220	87.44	Routine chest x-ray
221	87.71	CT KUB
222	87.76	Ureterography
223	8717811	การนวดด้วยวิธีการแพทย์แผนไทยแบบราชสำนัก ที่สะโพก, เอว (8717811)
224	8717820	การประคบด้วยสมุนไพร ที่สะโพก, เอว (8717820)
225	88.01	CT Whole Abdomen
226	88.38	CTA Neck (Carotid Artery)
227	88.56	CAG Two Catheters
228	88.72	Echo-Transthoracic
229	88.73	\N
230	88.75	Diagnostic ultrasound of urinary system
231	88.76	Ultrasound Upper Abdomen
232	88.77	Diagnostic ultrasound of peripheral vascular system
233	88.78	Diagnostic ultrasound of gravid uterus
234	88.79	Ultrasound Endovaginal
235	88.91	MRI Brain,MRI Hippocampus
236	88.93	Magnetic resonance imaging of spinal canal
237	89.11	Tonometry
238	89.14	Electroencephalogram
239	89.44	Other cardiovascular stress test
240	89.52	EKG -- see also Electrocardiogram
241	89.65	Measurement of systemic arterial blood gases
242	89.7	General physical examination
243	8B51800	Acupuncture anesthesia, (Zu-San-Li) 8B51800
244	8B51801	Electro-acupuncture therapy, (Zu-San-Li) 8B51801
245	8B51811	Double-handed needle insertion, (Zu-San-Li) 8B51811
246	8B71800	Acupuncture anesthesia, (Tiao-Kou) 8B71800
247	8BA1800	Acupuncture anesthesia, (Jie-Xi) 8BA1800
248	8BA1811	Double-handed needle insertion, (Jie-Xi) 8BA1811
249	8BA1891	Moxa burner moxibustion, (Jie-Xi) 8BA1891
250	8D01810	Single-handed needle insertion,(Cheng-Fu) 8D01810
251	8D11801	Electro-acupuncture therapy, (Yin-Men) 8D11801
252	8D41800	Acupuncture anesthesia, (Wei-Zhong) 8D41800
253	8D41801	Electro-acupuncture therapy, (Wei-Zhong) 8D41801
254	8D41810	Single-handed needle insertion, (Wei-Zhong) 8D41810
255	8D41811	Double-handed needle insertion, (Wei-Zhong) 8D41811
256	8E21811	Double-handed needle insertion, (Cheng-Shan) 8E21811
257	8E51801	Electro-acupuncture therapy, (Kun-Lun) 8E51801
258	8E51811	Double-handed needle insertion, (Kun-Lun) 8E51811
259	8G11811	Double-handed needle insertion, (Huan-Tiao) 8G11811
260	8G21800	Acupuncture anesthesia, (Feng-shi) 8G21800
261	8G21801	Electro-acupuncture therapy, (Feng-shi) 8G21801
262	8G21811	Double-handed needle insertion, (Feng-shi) 8G21811
263	8G51800	Acupuncture anesthesia, (Yang-Ling-Quan) 8G51800
264	8G51801	Electro-acupuncture therapy, (Yang-Ling-Quan) 8G51801
265	8G51811	Double-handed needle insertion, (Yang-Ling-Quan) 8G51811
266	8GB1811	Double-handed needle insertion, (Qiu-Xu) 8GB1811
267	8GC1801	Electro-acupuncture therapy, (Zu-Lin-Qi) 8GC1801
268	8L61800	Acupuncture anesthesia, (San-Yin-Jiao) 8L61800
269	8LA1800	Acupuncture anesthesia, (Xue-Hai) 8LA1800
270	8LA1811	Double-handed needle insertion, (Xue-Hai) 8LA1811
271	8M31800	Acupuncture anesthesia, (Tai-Xi) 8M31800
272	8M71800	Acupuncture anesthesia, (Fu-Liu) 8M71800
273	8P31800	Acupuncture anesthesia, (Tai-Chong) 8P31800
274	8W51891	Moxa burner moxibustion, (Xi-Yan) 8W51891
275	8WA1811	Double-handed needle insertion ,(Ba-Feng) 8WA1811
276	9007811	การนวดด้วยวิธีการแพทย์แผนไทยแบบราชสำนัก ที่ทั่วร่างกาย (9007811)
277	9007820	การประคบด้วยสมุนไพร ที่ทั่วร่างกาย (9007820)
278	9007838	การใช้ยาบำบัดวิธีอื่น ที่ทั่วร่างกาย (9007838)
279	9007839	การใช้ยาบำบัด  ไม่ระบุวิธี ที่ทั่วร่างกาย (9007839)
280	93.12	Other active musculoskeletal exercise
281	93.14	Training in joint movements
282	93.21	Manual and mechanical traction
283	93.22	Ambulation and gait training
284	93.27	\N
285	93.34	Diathermy
286	93.35	Other heat therapy
287	93.38	Combined physical therapy without mention of the components
288	93.39	Other physical therapy
289	93.53	Application of other cast
291	93.57	Application of other wound dressing
292	93.81	\N
293	93.82	Educational therapy
294	93.83	\N
295	93.89	Rehabilitation, not elsewhere classified
296	93.90	High flow cannula
297	93.94	Therapy [nebulizer]
298	93.96	Other oxygen enrichment
299	95.09	Eye examination, not otherwise specified
300	95.41	Audiogram
301	95.46	Dix-Hall pike maneuvex
302	96.04	Insertion of endotracheal tube
303	96.07	Insertion of other (naso-)gastric tube
304	96.33	Gastric lavage
305	96.6	Enteral infusion of concentrated nutritional substances
306	96.70	Continuous invasive mechanical ventilation of unspecified duration
307	96.71	On ventilator < 96 hours
308	96.72	On ventilator >= 96 hours
309	97.64	Removal of urinary drainage device
310	98.02	Removal of intraluminal foreign body from esophagus without incision
311	98.13	Remove FB from pharynx
312	99.04	Transfusion of packed cells
313	99.05	plt transfusion
314	99.06	FFP transfusion
315	99.10	s/p rtPA
316	99.15	Parenteral infusion of concentrated nutritional substances
317	99.18	Injection or infusion of electrolytes
318	99.21	Injection of antibiotic
319	99.25	Infusion (intra-arterial) (intravenous) [antineoplastic agent (chemotherapeutic)]
320	99.29	Injection or infusion of other therapeutic or prophylactic substance
321	99.38	Administration of tetanus toxoid
322	99.52	Prophylactic vaccination against influenza
323	99.59	Other vaccination and inoculation
324	99.60	Cardiopulmonary resuscitation, not otherwise specified
325	99.62	Other electric countershock of heart
326	99.83	Phototherapy
327	9991801	Electro-acupuncture therapy 9991801
328	9991810	Single-handed needle insertion 9991810
329	9991811	Double-handed needle insertion 9991811
330	9991878	Indirect moxibustion 9991878
331	9991953	Cotton-burning cupping method 9991953
332	9991959	Cupping method 9991959
333	86.3	Excision of lesion of subcutaneous tissue
334	58.99	urinary stress incontinence --see Repair
335	70.51	with graft or prosthesis 70.54
336	83.72	Stretching
337	89.58	penile 89.58
338	96.7	hepatic, extracorporeal 50.92
339	27.73	27.73
340	56.82	56.82
341	56.89	56.89
\.


--
-- Data for Name: imed_write_ops; Type: TABLE DATA; Schema: public; Owner: hsuyi
--

COPY public.imed_write_ops (op_id, case_id, op, code_kind, object_id, before_json, created_at) FROM stdin;
\.


--
-- Data for Name: knowledge_base; Type: TABLE DATA; Schema: public; Owner: hsuyi
--

COPY public.knowledge_base (knowledge_id, source_type, content, taught_by, status, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: hsuyi
--

COPY public.users (user_id, email, oauth_provider, oauth_subject, full_name, role, status, created_at, last_login_at, password_hash) FROM stdin;
3	frank@email.com	\N	\N	Frank	coder	active	2026-08-21 05:06:33.137705	2026-08-27 13:12:55	$2a$10$GF8N2xgUJd38eqk6037DMedAaAwRcSbBdWuTwC7dvF1AUO.UbWWCy
2	ouzdim@gmail.com	\N	\N	Ouzdim	coder	active	2026-08-21 05:00:47.453072	2026-08-27 13:21:11	$2a$10$GF8N2xgUJd38eqk6037DMedAaAwRcSbBdWuTwC7dvF1AUO.UbWWCy
1	admin@medcodeai.demo	\N	\N	Super Admin	admin	active	2026-08-21 04:59:25.215459	2026-08-27 23:12:12	$2a$10$4G.PiPA1pJsEtw8VesEOvuIryrVGg53sqL7TLEG34cJRahny./Nl2
\.


--
-- Name: agent_conversations_conversation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hsuyi
--

SELECT pg_catalog.setval('public.agent_conversations_conversation_id_seq', 1, false);


--
-- Name: agent_messages_message_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hsuyi
--

SELECT pg_catalog.setval('public.agent_messages_message_id_seq', 1, false);


--
-- Name: case_codes_case_code_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hsuyi
--

SELECT pg_catalog.setval('public.case_codes_case_code_id_seq', 1, false);


--
-- Name: case_orders_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hsuyi
--

SELECT pg_catalog.setval('public.case_orders_order_id_seq', 1, false);


--
-- Name: case_report_sections_section_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hsuyi
--

SELECT pg_catalog.setval('public.case_report_sections_section_id_seq', 1, false);


--
-- Name: case_vitals_vital_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hsuyi
--

SELECT pg_catalog.setval('public.case_vitals_vital_id_seq', 1, false);


--
-- Name: coding_history_history_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hsuyi
--

SELECT pg_catalog.setval('public.coding_history_history_id_seq', 1, false);


--
-- Name: document_chunks_chunk_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hsuyi
--

SELECT pg_catalog.setval('public.document_chunks_chunk_id_seq', 1, false);


--
-- Name: icd_10_icd_10_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hsuyi
--

SELECT pg_catalog.setval('public.icd_10_icd_10_id_seq', 658, true);


--
-- Name: icd_9_icd_9_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hsuyi
--

SELECT pg_catalog.setval('public.icd_9_icd_9_id_seq', 341, true);


--
-- Name: imed_write_ops_op_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hsuyi
--

SELECT pg_catalog.setval('public.imed_write_ops_op_id_seq', 1, false);


--
-- Name: knowledge_base_knowledge_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hsuyi
--

SELECT pg_catalog.setval('public.knowledge_base_knowledge_id_seq', 1, false);


--
-- Name: users_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: hsuyi
--

SELECT pg_catalog.setval('public.users_user_id_seq', 13, true);


--
-- Name: agent_conversations agent_conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.agent_conversations
    ADD CONSTRAINT agent_conversations_pkey PRIMARY KEY (conversation_id);


--
-- Name: agent_messages agent_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.agent_messages
    ADD CONSTRAINT agent_messages_pkey PRIMARY KEY (message_id);


--
-- Name: app_settings app_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.app_settings
    ADD CONSTRAINT app_settings_pkey PRIMARY KEY (key);


--
-- Name: auth_sessions auth_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.auth_sessions
    ADD CONSTRAINT auth_sessions_pkey PRIMARY KEY (session_id);


--
-- Name: case_code_edits case_code_edits_pkey; Type: CONSTRAINT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.case_code_edits
    ADD CONSTRAINT case_code_edits_pkey PRIMARY KEY (case_id);


--
-- Name: case_codes case_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.case_codes
    ADD CONSTRAINT case_codes_pkey PRIMARY KEY (case_code_id);


--
-- Name: case_orders case_orders_pkey; Type: CONSTRAINT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.case_orders
    ADD CONSTRAINT case_orders_pkey PRIMARY KEY (order_id);


--
-- Name: case_report_sections case_report_sections_pkey; Type: CONSTRAINT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.case_report_sections
    ADD CONSTRAINT case_report_sections_pkey PRIMARY KEY (section_id);


--
-- Name: case_stars case_stars_pkey; Type: CONSTRAINT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.case_stars
    ADD CONSTRAINT case_stars_pkey PRIMARY KEY (case_id);


--
-- Name: case_vitals case_vitals_pkey; Type: CONSTRAINT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.case_vitals
    ADD CONSTRAINT case_vitals_pkey PRIMARY KEY (vital_id);


--
-- Name: cases cases_pkey; Type: CONSTRAINT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_pkey PRIMARY KEY (case_id);


--
-- Name: coding_history coding_history_pkey; Type: CONSTRAINT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.coding_history
    ADD CONSTRAINT coding_history_pkey PRIMARY KEY (history_id);


--
-- Name: coverage_types coverage_types_pkey; Type: CONSTRAINT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.coverage_types
    ADD CONSTRAINT coverage_types_pkey PRIMARY KEY (coverage_code);


--
-- Name: document_chunks document_chunks_pkey; Type: CONSTRAINT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.document_chunks
    ADD CONSTRAINT document_chunks_pkey PRIMARY KEY (chunk_id);


--
-- Name: icd_10 icd_10_code_key; Type: CONSTRAINT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.icd_10
    ADD CONSTRAINT icd_10_code_key UNIQUE (code);


--
-- Name: icd_10 icd_10_pkey; Type: CONSTRAINT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.icd_10
    ADD CONSTRAINT icd_10_pkey PRIMARY KEY (icd_10_id);


--
-- Name: icd_9 icd_9_code_key; Type: CONSTRAINT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.icd_9
    ADD CONSTRAINT icd_9_code_key UNIQUE (code);


--
-- Name: icd_9 icd_9_pkey; Type: CONSTRAINT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.icd_9
    ADD CONSTRAINT icd_9_pkey PRIMARY KEY (icd_9_id);


--
-- Name: imed_write_ops imed_write_ops_pkey; Type: CONSTRAINT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.imed_write_ops
    ADD CONSTRAINT imed_write_ops_pkey PRIMARY KEY (op_id);


--
-- Name: knowledge_base knowledge_base_pkey; Type: CONSTRAINT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.knowledge_base
    ADD CONSTRAINT knowledge_base_pkey PRIMARY KEY (knowledge_id);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (user_id);


--
-- Name: agent_conversations_user_idx; Type: INDEX; Schema: public; Owner: hsuyi
--

CREATE INDEX agent_conversations_user_idx ON public.agent_conversations USING btree (user_id);


--
-- Name: agent_messages_convo_idx; Type: INDEX; Schema: public; Owner: hsuyi
--

CREATE INDEX agent_messages_convo_idx ON public.agent_messages USING btree (conversation_id);


--
-- Name: case_codes_icd_10_idx; Type: INDEX; Schema: public; Owner: hsuyi
--

CREATE INDEX case_codes_icd_10_idx ON public.case_codes USING btree (icd_10_id);


--
-- Name: case_codes_icd_9_idx; Type: INDEX; Schema: public; Owner: hsuyi
--

CREATE INDEX case_codes_icd_9_idx ON public.case_codes USING btree (icd_9_id);


--
-- Name: case_vitals_case_idx; Type: INDEX; Schema: public; Owner: hsuyi
--

CREATE INDEX case_vitals_case_idx ON public.case_vitals USING btree (case_id);


--
-- Name: imed_write_ops_case_idx; Type: INDEX; Schema: public; Owner: hsuyi
--

CREATE INDEX imed_write_ops_case_idx ON public.imed_write_ops USING btree (case_id);


--
-- Name: agent_conversations agent_conversations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.agent_conversations
    ADD CONSTRAINT agent_conversations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- Name: agent_messages agent_messages_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.agent_messages
    ADD CONSTRAINT agent_messages_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.agent_conversations(conversation_id) ON DELETE CASCADE;


--
-- Name: auth_sessions auth_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.auth_sessions
    ADD CONSTRAINT auth_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: case_code_edits case_code_edits_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.case_code_edits
    ADD CONSTRAINT case_code_edits_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: case_codes case_codes_assigned_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.case_codes
    ADD CONSTRAINT case_codes_assigned_by_fkey FOREIGN KEY (assigned_by) REFERENCES public.users(user_id);


--
-- Name: case_codes case_codes_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.case_codes
    ADD CONSTRAINT case_codes_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: case_codes case_codes_icd_10_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.case_codes
    ADD CONSTRAINT case_codes_icd_10_id_fkey FOREIGN KEY (icd_10_id) REFERENCES public.icd_10(icd_10_id);


--
-- Name: case_codes case_codes_icd_9_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.case_codes
    ADD CONSTRAINT case_codes_icd_9_id_fkey FOREIGN KEY (icd_9_id) REFERENCES public.icd_9(icd_9_id);


--
-- Name: case_orders case_orders_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.case_orders
    ADD CONSTRAINT case_orders_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: case_report_sections case_report_sections_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.case_report_sections
    ADD CONSTRAINT case_report_sections_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: case_stars case_stars_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.case_stars
    ADD CONSTRAINT case_stars_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: case_vitals case_vitals_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.case_vitals
    ADD CONSTRAINT case_vitals_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: cases cases_coverage_type_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_coverage_type_fkey FOREIGN KEY (coverage_type) REFERENCES public.coverage_types(coverage_code);


--
-- Name: coding_history coding_history_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.coding_history
    ADD CONSTRAINT coding_history_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: coding_history coding_history_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.coding_history
    ADD CONSTRAINT coding_history_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(user_id);


--
-- Name: document_chunks document_chunks_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.document_chunks
    ADD CONSTRAINT document_chunks_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: imed_write_ops imed_write_ops_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.imed_write_ops
    ADD CONSTRAINT imed_write_ops_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(case_id);


--
-- Name: knowledge_base knowledge_base_taught_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: hsuyi
--

ALTER TABLE ONLY public.knowledge_base
    ADD CONSTRAINT knowledge_base_taught_by_fkey FOREIGN KEY (taught_by) REFERENCES public.users(user_id);


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: hsuyi
--

REVOKE USAGE ON SCHEMA public FROM PUBLIC;


--
-- PostgreSQL database dump complete
--

\unrestrict uF5zOKy1WPO1bprMptmbF5QIJeFzhhFqkvxw2hQsNjJyhhcGh9h7H9IzNiRCzSM

