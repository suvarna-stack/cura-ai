--
-- PostgreSQL database dump
--

\restrict LaykUF23kvw4BVpaBUn8KRDW9V80d7R6qtqJYDTmi75QhEYeQaJfcAym0UqG4Wb

-- Dumped from database version 18.4 (Homebrew)
-- Dumped by pg_dump version 18.4 (Homebrew)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: imed; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA imed;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: medhack_bedmanagement; Type: TABLE; Schema: imed; Owner: -
--

CREATE TABLE imed.medhack_bedmanagement (
    transactionnumber text,
    serviceid text,
    department text,
    ward text,
    bednumber text,
    startdatetime text,
    enddatetime text
);


--
-- Name: medhack_billingitem; Type: TABLE; Schema: imed; Owner: -
--

CREATE TABLE imed.medhack_billingitem (
    transactionnumber text,
    id text,
    name text,
    itemid text,
    tmlt text,
    cgd text,
    feeschedule text,
    quantity text,
    remark text,
    verifydatetime text
);


--
-- Name: medhack_diagnosis_icd10; Type: TABLE; Schema: imed; Owner: -
--

CREATE TABLE imed.medhack_diagnosis_icd10 (
    transactionnumber text,
    encountertype text,
    id text,
    name text,
    icd text,
    diagnosistype text,
    is_cancelled text,
    updated_at text
);


--
-- Name: medhack_medicalrecord; Type: TABLE; Schema: imed; Owner: -
--

CREATE TABLE imed.medhack_medicalrecord (
    transactionnumber text,
    documenttype text,
    fieldname text,
    value text,
    recorddatetime text
);


--
-- Name: medhack_medicalrecord_result; Type: TABLE; Schema: imed; Owner: -
--

CREATE TABLE imed.medhack_medicalrecord_result (
    transactionnumber text,
    tmlt text,
    cgd text,
    name text,
    documenttype text,
    fieldid text,
    fieldname text,
    subfieldname text,
    value text,
    uom text,
    recorddatetime text
);


--
-- Name: medhack_orderdrug; Type: TABLE; Schema: imed; Owner: -
--

CREATE TABLE imed.medhack_orderdrug (
    transactionnumber text,
    id text,
    name text,
    itemid text,
    tmt text,
    dosagesignature text,
    dosageinstruction text,
    quantity text,
    remark text,
    receiveddatetime text
);


--
-- Name: medhack_orderlab; Type: TABLE; Schema: imed; Owner: -
--

CREATE TABLE imed.medhack_orderlab (
    transactionnumber text,
    id text,
    panelname text,
    paneltmlt text,
    panelcgd text,
    collectdatetime text,
    reportdatetime text,
    itemid text,
    itemtmlt text,
    itemcgd text,
    itemname text,
    itemvalue text,
    itemuom text
);


--
-- Name: medhack_patient; Type: TABLE; Schema: imed; Owner: -
--

CREATE TABLE imed.medhack_patient (
    transactionnumber text NOT NULL,
    admissionnumber text,
    birthdate text,
    ageyear text,
    admissiondatetime text,
    dischargedatetime text,
    dischargetype text,
    dischargestatus text,
    ispregnant text,
    sex text,
    healthcoverage text,
    coding_status text
);


--
-- Name: medhack_procedure_icd9; Type: TABLE; Schema: imed; Owner: -
--

CREATE TABLE imed.medhack_procedure_icd9 (
    transactionnumber text,
    encountertype text,
    id text,
    name text,
    icd text,
    startdatetime text,
    enddatetime text,
    operationtype text,
    is_cancelled text,
    updated_at text
);


--
-- Name: medhack_vitalsign; Type: TABLE; Schema: imed; Owner: -
--

CREATE TABLE imed.medhack_vitalsign (
    transactionnumber text,
    measuredatetime text,
    temperature text,
    diastolicbloodpressure text,
    systolicbloodpressure text,
    heartrate text,
    oxygensaturation text,
    weight text,
    height text
);


--
-- Data for Name: medhack_bedmanagement; Type: TABLE DATA; Schema: imed; Owner: -
--

COPY imed.medhack_bedmanagement (transactionnumber, serviceid, department, ward, bednumber, startdatetime, enddatetime) FROM stdin;
87026072413210500101	87026072413210010101	แผนก OPD MED (อายุรกรรม)	\N	\N	2026-07-24 13:21:05	\N
87026072209142300201	87026072209142010101	แผนก OPD SURGICAL (ศัลยศาสตร์)	\N	\N	2026-07-22 09:14:23	\N
87026072508311700301	87026072508311010101	แผนก OPD MED (อายุรกรรม)	\N	\N	2026-07-25 08:31:17	\N
87026072414445200401	87026072414445010101	แผนก OPD ORTHOPEDIC (โรคกระดูกและข้อ)	\N	\N	2026-07-24 14:44:52	\N
87026073109520800501	87026073109520010101	แผนก OPD GP (ทั่วไป ชั้น1)	\N	\N	2026-07-31 09:52:08	\N
87026073111085600601	87026073111085010101	แผนก OPD MED (อายุรกรรม)	\N	\N	2026-07-31 11:08:56	\N
87026072310024100701	87026072310024010101	แผนก OPD SURGICAL (ศัลยศาสตร์)	\N	\N	2026-07-23 10:02:41	\N
87026072711124400801	87026072711124010101	แผนก OPD SURGICAL (ศัลยศาสตร์)	\N	\N	2026-07-27 11:12:44	\N
87026072813401900901	87026072813401010101	แผนก OPD SURGICAL (ศัลยศาสตร์)	\N	\N	2026-07-28 13:40:19	\N
87026072716380901001	87026072716380010101	แผนก ER (อุบัติเหตุและฉุกเฉิน)	\N	\N	2026-07-27 16:38:09	\N
87026080110481501101	87026080110481010101	แผนก OPD MED (อายุรกรรม)	\N	\N	2026-08-01 10:48:15	\N
87026072915054701201	87026072915054010101	แผนก OPD MED (อายุรกรรม)	\N	\N	2026-07-29 15:05:47	\N
87026073010193301301	87026073010193010101	แผนก OPD ORTHOPEDIC (โรคกระดูกและข้อ)	\N	\N	2026-07-30 10:19:33	\N
87026072808552901401	87026072808552010101	แผนก OPD MED (อายุรกรรม)	\N	\N	2026-07-28 08:55:29	\N
87026072810245101501	87026072810245010101	แผนก OPD GP (ทั่วไป ชั้น1)	\N	\N	2026-07-28 10:24:51	\N
87026072909410201601	87026072909410010101	แผนก OPD E.N.T (หู คอ จมูก)	\N	\N	2026-07-29 09:41:02	\N
87026072913173601701	87026072913173010101	แผนก OPD GP (ทั่วไป ชั้น1)	\N	\N	2026-07-29 13:17:36	\N
87026073115294701801	87026073115294010101	แผนก OPD GP (ทั่วไป ชั้น1)	\N	\N	2026-07-31 15:29:47	\N
87026073008122001901	87026073008122010101	แผนก OPD GP (ทั่วไป ชั้น1)	\N	\N	2026-07-30 08:12:20	\N
87026073014031102001	87026073014031010101	แผนก OPD GP (ทั่วไป ชั้น1)	\N	\N	2026-07-30 14:03:11	\N
87026073015264002101	87026073015264010101	แผนก OPD MED (อายุรกรรม)	\N	\N	2026-07-30 15:26:40	\N
\.


--
-- Data for Name: medhack_billingitem; Type: TABLE DATA; Schema: imed; Owner: -
--

COPY imed.medhack_billingitem (transactionnumber, id, name, itemid, tmlt, cgd, feeschedule, quantity, remark, verifydatetime) FROM stdin;
87026072413210500101	87026072413210013901	ค่าบริการสถานพยาบาล-Hospital Charge	NEW25	\N	\N	\N	1	\N	2026-07-24 13:21:05
87026072413210500101	87026072413210014001	ค่าบริการผู้ป่วยนอก	MD00199	\N	55021	55021	1	\N	2026-07-24 13:21:05
87026072209142300201	87026072209142012501	ค่าบริการสถานพยาบาล-Hospital Charge	NEW25	\N	\N	\N	1	\N	2026-07-22 09:14:23
87026072209142300201	87026072209142012601	ค่าบริการผู้ป่วยนอก	MD00199	\N	55021	55021	1	\N	2026-07-22 09:14:23
87026072508311700301	87026072508311013301	ค่าบริการสถานพยาบาล-Hospital Charge	NEW25	\N	\N	\N	1	\N	2026-07-25 08:31:17
87026072508311700301	87026072508311013401	ค่าบริการผู้ป่วยนอก	MD00199	\N	55021	55021	1	\N	2026-07-25 08:31:17
87026072414445200401	87026072414445010601	ค่าบริการสถานพยาบาล-Hospital Charge	NEW25	\N	\N	\N	1	\N	2026-07-24 14:44:52
87026072414445200401	87026072414445010701	ค่าบริการผู้ป่วยนอก	MD00199	\N	55021	55021	1	\N	2026-07-24 14:44:52
87026073109520800501	87026073109520010401	ค่าบริการสถานพยาบาล-Hospital Charge	NEW25	\N	\N	\N	1	\N	2026-07-31 09:52:08
87026073109520800501	87026073109520010501	ค่าบริการผู้ป่วยนอก	MD00199	\N	55021	55021	1	\N	2026-07-31 09:52:08
87026073111085600601	87026073111085010401	ค่าบริการสถานพยาบาล-Hospital Charge	NEW25	\N	\N	\N	1	\N	2026-07-31 11:08:56
87026073111085600601	87026073111085010501	ค่าบริการผู้ป่วยนอก	MD00199	\N	55021	55021	1	\N	2026-07-31 11:08:56
87026072310024100701	87026072310024010401	ค่าบริการสถานพยาบาล-Hospital Charge	NEW25	\N	\N	\N	1	\N	2026-07-23 10:02:41
87026072310024100701	87026072310024010501	ค่าบริการผู้ป่วยนอก	MD00199	\N	55021	55021	1	\N	2026-07-23 10:02:41
87026072711124400801	87026072711124010501	ค่าบริการสถานพยาบาล-Hospital Charge	NEW25	\N	\N	\N	1	\N	2026-07-27 11:12:44
87026072711124400801	87026072711124010601	ค่าบริการผู้ป่วยนอก	MD00199	\N	55021	55021	1	\N	2026-07-27 11:12:44
87026072813401900901	87026072813401010401	ค่าบริการสถานพยาบาล-Hospital Charge	NEW25	\N	\N	\N	1	\N	2026-07-28 13:40:19
87026072813401900901	87026072813401010501	ค่าบริการผู้ป่วยนอก	MD00199	\N	55021	55021	1	\N	2026-07-28 13:40:19
87026072716380901001	87026072716380010301	ค่าบริการสถานพยาบาล-Hospital Charge	NEW25	\N	\N	\N	1	\N	2026-07-27 16:38:09
87026072716380901001	87026072716380010401	ค่าบริการผู้ป่วยนอก	MD00199	\N	55021	55021	1	\N	2026-07-27 16:38:09
87026080110481501101	87026080110481010501	ค่าบริการสถานพยาบาล-Hospital Charge	NEW25	\N	\N	\N	1	\N	2026-08-01 10:48:15
87026080110481501101	87026080110481010601	ค่าบริการผู้ป่วยนอก	MD00199	\N	55021	55021	1	\N	2026-08-01 10:48:15
87026072915054701201	87026072915054010401	ค่าบริการสถานพยาบาล-Hospital Charge	NEW25	\N	\N	\N	1	\N	2026-07-29 15:05:47
87026072915054701201	87026072915054010501	ค่าบริการผู้ป่วยนอก	MD00199	\N	55021	55021	1	\N	2026-07-29 15:05:47
87026073010193301301	87026073010193010401	ค่าบริการสถานพยาบาล-Hospital Charge	NEW25	\N	\N	\N	1	\N	2026-07-30 10:19:33
87026073010193301301	87026073010193010501	ค่าบริการผู้ป่วยนอก	MD00199	\N	55021	55021	1	\N	2026-07-30 10:19:33
87026072808552901401	87026072808552010301	ค่าบริการสถานพยาบาล-Hospital Charge	NEW25	\N	\N	\N	1	\N	2026-07-28 08:55:29
87026072808552901401	87026072808552010401	ค่าบริการผู้ป่วยนอก	MD00199	\N	55021	55021	1	\N	2026-07-28 08:55:29
87026072810245101501	87026072810245010301	ค่าบริการสถานพยาบาล-Hospital Charge	NEW25	\N	\N	\N	1	\N	2026-07-28 10:24:51
87026072810245101501	87026072810245010401	ค่าบริการผู้ป่วยนอก	MD00199	\N	55021	55021	1	\N	2026-07-28 10:24:51
87026072909410201601	87026072909410010401	ค่าบริการสถานพยาบาล-Hospital Charge	NEW25	\N	\N	\N	1	\N	2026-07-29 09:41:02
87026072909410201601	87026072909410010501	ค่าบริการผู้ป่วยนอก	MD00199	\N	55021	55021	1	\N	2026-07-29 09:41:02
87026072913173601701	87026072913173012401	ค่าบริการสถานพยาบาล-Hospital Charge	NEW25	\N	\N	\N	1	\N	2026-07-29 13:17:36
87026072913173601701	87026072913173012501	ค่าบริการผู้ป่วยนอก	MD00199	\N	55021	55021	1	\N	2026-07-29 13:17:36
87026073115294701801	87026073115294010301	ค่าบริการสถานพยาบาล-Hospital Charge	NEW25	\N	\N	\N	1	\N	2026-07-31 15:29:47
87026073115294701801	87026073115294010401	ค่าบริการผู้ป่วยนอก	MD00199	\N	55021	55021	1	\N	2026-07-31 15:29:47
87026073008122001901	87026073008122016301	ค่าบริการสถานพยาบาล-Hospital Charge	NEW25	\N	\N	\N	1	\N	2026-07-30 08:12:20
87026073008122001901	87026073008122016401	ค่าบริการผู้ป่วยนอก	MD00199	\N	55021	55021	1	\N	2026-07-30 08:12:20
87026073014031102001	87026073014031012601	ค่าบริการสถานพยาบาล-Hospital Charge	NEW25	\N	\N	\N	1	\N	2026-07-30 14:03:11
87026073014031102001	87026073014031012701	ค่าบริการผู้ป่วยนอก	MD00199	\N	55021	55021	1	\N	2026-07-30 14:03:11
87026073015264002101	87026073015264010901	ค่าบริการสถานพยาบาล-Hospital Charge	NEW25	\N	\N	\N	1	\N	2026-07-30 15:26:40
87026073015264002101	87026073015264011001	ค่าบริการผู้ป่วยนอก	MD00199	\N	55021	55021	1	\N	2026-07-30 15:26:40
\.


--
-- Data for Name: medhack_diagnosis_icd10; Type: TABLE DATA; Schema: imed; Owner: -
--

COPY imed.medhack_diagnosis_icd10 (transactionnumber, encountertype, id, name, icd, diagnosistype, is_cancelled, updated_at) FROM stdin;
87026072310024100701	0	87026072310024020101	Dermoid Cyst, Ovary	D27	PRIMARY_DIAGNOSIS	\N	\N
87026072414445200401	0	87026072414445020101	Low back pain	M54.5	PRIMARY_DIAGNOSIS	\N	\N
87026072209142300201	0	87026072209142020101	Hemorrhoid Grade 3	K64.2	PRIMARY_DIAGNOSIS	\N	\N
87026072711124400801	0	87026072711124020101	Abscess, Rt hip	L02.4	PRIMARY_DIAGNOSIS	\N	\N
87026072813401900901	0	87026072813401020101	Lipoma at back	D17.1	PRIMARY_DIAGNOSIS	\N	\N
\.


--
-- Data for Name: medhack_medicalrecord; Type: TABLE DATA; Schema: imed; Owner: -
--

COPY imed.medhack_medicalrecord (transactionnumber, documenttype, fieldname, value, recorddatetime) FROM stdin;
87026072413210500101	OPD Record	Chief Complaint	ไข้ ไอมีเสมหะเหลือง เหนื่อยง่าย 3 วัน	2026-07-24 13:21:05
87026072413210500101	OPD Record	Present Illness	3 วันก่อนมา มีไข้สูง ไอมีเสมหะสีเหลืองข้น เจ็บหน้าอกขวาเวลาหายใจเข้าลึก ๆ\r\nเหนื่อยขึ้นเวลาเดิน ไม่มีน้ำมูก ไม่เจ็บคอ ปฏิเสธสัมผัสผู้ป่วยวัณโรค\r\nU/D: HT on amlodipine, no DM\r\nno smoking 10 yr (เคยสูบ 20 pack-year)	2026-07-24 13:21:05
87026072413210500101	OPD Record	Assessment	CAP, right lower lobe (CURB-65 = 1) — OPD treatment\r\nHT — stable	2026-07-24 13:21:05
87026072413210500101	OPD Record	Plan	Augmentin 1 g bid x 7 วัน, F/U CXR 2 สัปดาห์, RTC ถ้าเหนื่อยมากขึ้น/ไข้ไม่ลง 48 ชม.	2026-07-24 13:21:05
87026072413210500101	OPD Record	Order	CBC, Influenza Ag, Creatinine, CXR PA upright	2026-07-24 13:21:05
87026072413210500101	OPD Record	Food-Drug Allergy	ไม่มีประวัติแพ้ยาแพ้อาหาร	2026-07-24 13:21:05
87026072413210500101	OPD Record	Family History	ปฏิเสธประวัติการเจ็บป่วยของบุคคลในครอบครัว	2026-07-24 13:21:05
87026072413210500101	OPD Record	Physical Examination	Respiratory: fine crepitation RLL, no wheezing	2026-07-24 13:21:05
87026072413210500101	OPD Record	Physical Examination	General Appearance: febrile, mildly dyspneic on exertion	2026-07-24 13:21:05
87026072413210500101	OPD Record	Physical Examination	General Appearance: good consciousness with orientation to time place and person	2026-07-24 13:21:05
87026072413210500101	OPD Record	Physical Examination	HEENT: not pale conjunctiva, anicteric sclera	2026-07-24 13:21:05
87026072413210500101	OPD Record	Physical Examination	Respiratory: equal breath sound with no adventitious sound	2026-07-24 13:21:05
87026072413210500101	OPD Record	Physical Examination	Cardiovascular: normal s1s2, no murmur	2026-07-24 13:21:05
87026072413210500101	OPD Record	Physical Examination	Gastrointestinal: no distension soft, no tenderness no mass active bowel sound	2026-07-24 13:21:05
87026072413210500101	OPD Record	Physical Examination	Extremities: no arthritis, no edema	2026-07-24 13:21:05
87026072413210500101	OPD Record	Physical Examination	Skin: no rash	2026-07-24 13:21:05
87026072209142300201	OPD Record	Chief Complaint	ถ่ายเป็นเลือดสดปนก้อนอุจจาระ 2 สัปดาห์ มีก้อนยื่นที่ทวารหนัก	2026-07-22 09:14:23
87026072209142300201	OPD Record	Present Illness	2 wk PTA มีเลือดสดหยดหลังถ่ายอุจจาระ ไม่ปวด มีก้อนยื่นเวลาเบ่ง ดันกลับได้เอง\r\nไม่มีน้ำหนักลด ไม่มีประวัติมะเร็งลำไส้ในครอบครัว ถ่ายแข็งเป็นประจำ ดื่มน้ำน้อย\r\nPR: internal hemorrhoid 3 o'clock grade III, no mass, no blood on glove\r\nProctoscope: internal hemorrhoid gr III at 3,7 o'clock	2026-07-22 09:14:23
87026072209142300201	OPD Record	Assessment	Internal hemorrhoid grade III\r\nPlan: hemorrhoidectomy today, advice high fiber diet	2026-07-22 09:14:23
87026072209142300201	OPD Record	Plan	Hemorrhoidectomy under local, F/U 2 wk	2026-07-22 09:14:23
87026072209142300201	OPD Record	Food-Drug Allergy	ไม่มีประวัติแพ้ยาแพ้อาหาร	2026-07-22 09:14:23
87026072209142300201	OPD Record	Family History	ปฏิเสธประวัติการเจ็บป่วยของบุคคลในครอบครัว	2026-07-22 09:14:23
87026072209142300201	OPD Record	Physical Examination	PR: internal hemorrhoid 3,7 o'clock grade III, no mass, no melena	2026-07-22 09:14:23
87026072209142300201	OPD Record	Physical Examination	General Appearance: good consciousness with orientation to time place and person	2026-07-22 09:14:23
87026072209142300201	OPD Record	Physical Examination	HEENT: not pale conjunctiva, anicteric sclera	2026-07-22 09:14:23
87026072209142300201	OPD Record	Physical Examination	Respiratory: equal breath sound with no adventitious sound	2026-07-22 09:14:23
87026072209142300201	OPD Record	Physical Examination	Cardiovascular: normal s1s2, no murmur	2026-07-22 09:14:23
87026072209142300201	OPD Record	Physical Examination	Gastrointestinal: no distension soft, no tenderness no mass active bowel sound	2026-07-22 09:14:23
87026072209142300201	OPD Record	Physical Examination	Extremities: no arthritis, no edema	2026-07-22 09:14:23
87026072209142300201	OPD Record	Physical Examination	Skin: no rash	2026-07-22 09:14:23
87026072508311700301	OPD Record	Chief Complaint	มาตามนัดเบาหวาน รับยาต่อเนื่อง	2026-07-25 08:31:17
87026072508311700301	OPD Record	Present Illness	U/D T2DM 8 ปี, dyslipidemia, HT — on metformin 1000 mg/d + simvastatin 20 mg + enalapril 5 mg\r\nทานยาสม่ำเสมอ ไม่มี hypoglycemia ไม่มีชาปลายมือปลายเท้า ไม่มีเจ็บหน้าอก\r\nSMBG เช้า 120-140 mg/dL, ออกกำลังกายเดินเร็ว 3 วัน/สัปดาห์\r\nBMI 29.8 แนะนำลดน้ำหนักต่อเนื่อง\r\nตรวจตาประจำปีล่าสุด: no diabetic retinopathy	2026-07-25 08:31:17
87026072508311700301	OPD Record	Assessment	T2DM — HbA1c 7.4% ยังไม่ถึงเป้า ปรับ metformin เป็น 2000 mg/d\r\nDyslipidemia — LDL 143 ปรับ statin ขึ้น\r\nHT — BP 134/82 ยอมรับได้\r\nObesity — BMI 29.8	2026-07-25 08:31:17
87026072508311700301	OPD Record	Plan	เพิ่ม metformin 1x2 pc, atorvastatin 20 mg hs แทน simvastatin, นัด 3 เดือน พร้อม FBS/HbA1c	2026-07-25 08:31:17
87026072508311700301	OPD Record	Order	FBS, Hb A1C, Lipid profile, Creatinine	2026-07-25 08:31:17
87026072508311700301	OPD Record	Food-Drug Allergy	ไม่มีประวัติแพ้ยาแพ้อาหาร	2026-07-25 08:31:17
87026072508311700301	OPD Record	Family History	บิดาเป็นเบาหวาน มารดาเป็นความดันโลหิตสูง	2026-07-25 08:31:17
87026072716380901001	OPD Record	Physical Examination	Extremities: no arthritis, no edema	2026-07-27 16:38:09
87026072508311700301	OPD Record	Physical Examination	Foot exam: intact protective sensation, no ulcer, dorsalis pedis 2+ both	2026-07-25 08:31:17
87026072508311700301	OPD Record	Physical Examination	General Appearance: good consciousness with orientation to time place and person	2026-07-25 08:31:17
87026072508311700301	OPD Record	Physical Examination	HEENT: not pale conjunctiva, anicteric sclera	2026-07-25 08:31:17
87026072508311700301	OPD Record	Physical Examination	Respiratory: equal breath sound with no adventitious sound	2026-07-25 08:31:17
87026072508311700301	OPD Record	Physical Examination	Cardiovascular: normal s1s2, no murmur	2026-07-25 08:31:17
87026072508311700301	OPD Record	Physical Examination	Gastrointestinal: no distension soft, no tenderness no mass active bowel sound	2026-07-25 08:31:17
87026072508311700301	OPD Record	Physical Examination	Extremities: no arthritis, no edema	2026-07-25 08:31:17
87026072508311700301	OPD Record	Physical Examination	Skin: no rash	2026-07-25 08:31:17
87026072414445200401	OPD Record	Chief Complaint	ปวดหลังส่วนล่าง 1 เดือน ร้าวลงสะโพกซ้ายเล็กน้อย	2026-07-24 14:44:52
87026072414445200401	OPD Record	Present Illness	ปวดหลังส่วนล่างเรื้อรัง 1 เดือน สัมพันธ์กับการยกของหนักที่ทำงาน\r\nปวดตื้อ ๆ ร้าวลงสะโพกซ้าย ไม่เกิน knee ไม่มีชา ไม่มีอ่อนแรง ไม่มีปัสสาวะ-อุจจาระผิดปกติ\r\nนั่งนานปวดมากขึ้น นอนพักดีขึ้น ไม่มีไข้ น้ำหนักไม่ลด\r\nSLR negative both sides	2026-07-24 14:44:52
87026072414445200401	OPD Record	Assessment	Mechanical low back pain, no red flags\r\nPlan: NSAIDs + physiotherapy (heat) + back exercise	2026-07-24 14:44:52
87026072414445200401	OPD Record	Plan	Heat therapy + back muscle exercise program, ergonomic advice, F/U 4 wk	2026-07-24 14:44:52
87026072414445200401	OPD Record	Food-Drug Allergy	ไม่มีประวัติแพ้ยาแพ้อาหาร	2026-07-24 14:44:52
87026072414445200401	OPD Record	Family History	ปฏิเสธประวัติการเจ็บป่วยของบุคคลในครอบครัว	2026-07-24 14:44:52
87026072414445200401	OPD Record	Physical Examination	Back: paraspinal muscle tenderness L4-5 level, no midline tenderness, SLR negative	2026-07-24 14:44:52
87026072414445200401	OPD Record	Physical Examination	Neurological: motor power gr.5 both lower extremities, intact sensation	2026-07-24 14:44:52
87026072414445200401	OPD Record	Physical Examination	General Appearance: good consciousness with orientation to time place and person	2026-07-24 14:44:52
87026072414445200401	OPD Record	Physical Examination	HEENT: not pale conjunctiva, anicteric sclera	2026-07-24 14:44:52
87026072414445200401	OPD Record	Physical Examination	Respiratory: equal breath sound with no adventitious sound	2026-07-24 14:44:52
87026072414445200401	OPD Record	Physical Examination	Cardiovascular: normal s1s2, no murmur	2026-07-24 14:44:52
87026072414445200401	OPD Record	Physical Examination	Gastrointestinal: no distension soft, no tenderness no mass active bowel sound	2026-07-24 14:44:52
87026072414445200401	OPD Record	Physical Examination	Extremities: no arthritis, no edema	2026-07-24 14:44:52
87026072414445200401	OPD Record	Physical Examination	Skin: no rash	2026-07-24 14:44:52
87026073109520800501	OPD Record	Chief Complaint	ถ่ายเหลว 5 ครั้ง อาเจียน 2 ครั้ง ตั้งแต่เมื่อคืน	2026-07-31 09:52:08
87026073109520800501	OPD Record	Present Illness	หลังทานส้มตำร้านข้างทาง เมื่อคืนถ่ายเหลวเป็นน้ำ 5 ครั้ง ไม่มีมูกเลือด\r\nอาเจียน 2 ครั้ง ปวดบิดท้องเป็นพัก ๆ ไข้ต่ำ ๆ ยังพอทานน้ำได้ ปัสสาวะสีเข้มเล็กน้อย	2026-07-31 09:52:08
87026073109520800501	OPD Record	Assessment	Acute gastroenteritis, mild dehydration — ORS + symptomatic, no antibiotic	2026-07-31 09:52:08
87026073109520800501	OPD Record	Plan	ORS ทีละน้อยบ่อย ๆ อาหารอ่อน RTC ถ้าถ่ายเป็นมูกเลือด ซึม หรือทานไม่ได้	2026-07-31 09:52:08
87026073109520800501	OPD Record	Food-Drug Allergy	ไม่มีประวัติแพ้ยาแพ้อาหาร	2026-07-31 09:52:08
87026073109520800501	OPD Record	Physical Examination	Gastrointestinal: hyperactive bowel sound, mild diffuse tenderness, no guarding	2026-07-31 09:52:08
87026073109520800501	OPD Record	Physical Examination	General Appearance: mildly dehydrated, dry lips	2026-07-31 09:52:08
87026073109520800501	OPD Record	Physical Examination	General Appearance: good consciousness with orientation to time place and person	2026-07-31 09:52:08
87026073109520800501	OPD Record	Physical Examination	HEENT: not pale conjunctiva, anicteric sclera	2026-07-31 09:52:08
87026073109520800501	OPD Record	Physical Examination	Respiratory: equal breath sound with no adventitious sound	2026-07-31 09:52:08
87026073109520800501	OPD Record	Physical Examination	Cardiovascular: normal s1s2, no murmur	2026-07-31 09:52:08
87026073109520800501	OPD Record	Physical Examination	Gastrointestinal: no distension soft, no tenderness no mass active bowel sound	2026-07-31 09:52:08
87026073109520800501	OPD Record	Physical Examination	Extremities: no arthritis, no edema	2026-07-31 09:52:08
87026073109520800501	OPD Record	Physical Examination	Skin: no rash	2026-07-31 09:52:08
87026073111085600601	OPD Record	Chief Complaint	ปวดหัวข้างเดียวตุบ ๆ เป็น ๆ หาย ๆ 3 เดือน วันนี้ปวดมาก	2026-07-31 11:08:56
87026073111085600601	OPD Record	Present Illness	ปวดศีรษะข้างขวาตุบ ๆ 3-4 ชม./ครั้ง คลื่นไส้ แพ้แสง เสียงดังทำให้ปวดมากขึ้น\r\nมี aura เห็นแสงระยิบก่อนปวด ~20 นาที ประจำเดือนกระตุ้น นอนพักในที่มืดดีขึ้น\r\nความถี่ 2-3 ครั้ง/เดือน ไม่มีอ่อนแรง ไม่มีชา ไม่มีไข้	2026-07-31 11:08:56
87026073111085600601	OPD Record	Assessment	Migraine with aura — abortive NSAIDs + antiemetic, แนะนำ headache diary\r\nยังไม่เข้าเกณฑ์ prophylaxis	2026-07-31 11:08:56
87026073111085600601	OPD Record	Plan	Naproxen เมื่อเริ่มปวด, F/U 2 เดือน พร้อม diary, red flag education	2026-07-31 11:08:56
87026073111085600601	OPD Record	Food-Drug Allergy	ไม่มีประวัติแพ้ยาแพ้อาหาร	2026-07-31 11:08:56
87026073111085600601	OPD Record	Family History	ปฏิเสธประวัติการเจ็บป่วยของบุคคลในครอบครัว	2026-07-31 11:08:56
87026073111085600601	OPD Record	Physical Examination	Neurological: E4V5M6, no focal deficit, fundi normal both eyes	2026-07-31 11:08:56
87026073111085600601	OPD Record	Physical Examination	General Appearance: good consciousness with orientation to time place and person	2026-07-31 11:08:56
87026073111085600601	OPD Record	Physical Examination	HEENT: not pale conjunctiva, anicteric sclera	2026-07-31 11:08:56
87026073111085600601	OPD Record	Physical Examination	Respiratory: equal breath sound with no adventitious sound	2026-07-31 11:08:56
87026073111085600601	OPD Record	Physical Examination	Cardiovascular: normal s1s2, no murmur	2026-07-31 11:08:56
87026073111085600601	OPD Record	Physical Examination	Gastrointestinal: no distension soft, no tenderness no mass active bowel sound	2026-07-31 11:08:56
87026073111085600601	OPD Record	Physical Examination	Extremities: no arthritis, no edema	2026-07-31 11:08:56
87026073111085600601	OPD Record	Physical Examination	Skin: no rash	2026-07-31 11:08:56
87026072310024100701	OPD Record	Chief Complaint	case Dermoid Cyst, Ovary มาตามนัด F/U ultrasound	2026-07-23 10:02:41
87026072310024100701	OPD Record	Present Illness	#Bilat dermoid cyst S/P Rt cystectomy, seen Lt dermoid 2.1x1.9 cm on last TVS\r\nF/U growth q 6 mo, LMP 10/7/69 x 4d regular, ไม่มีปวดหน่วงท้องน้อย ไม่มีเลือดออกผิดปกติ\r\nTVS today: Ut 6.3x3.2 cm, ET 3.1 mm, Lt dermoid 2.2x1.9 cm stable, ROV normal, no free fluid	2026-07-23 10:02:41
87026072310024100701	OPD Record	Assessment	Recurrent Lt ovarian dermoid cyst, stable size — continue conservative F/U	2026-07-23 10:02:41
87026072310024100701	OPD Record	Food-Drug Allergy	ไม่มีประวัติแพ้ยาแพ้อาหาร	2026-07-23 10:02:41
87026072310024100701	OPD Record	Family History	ปฏิเสธประวัติการเจ็บป่วยของบุคคลในครอบครัว	2026-07-23 10:02:41
87026072711124400801	OPD Record	Chief Complaint	ฝีที่สะโพกขวา ปวดบวมแดง 5 วัน	2026-07-27 11:12:44
87026072711124400801	OPD Record	Physical Examination	Skin: 3x3 cm fluctuant abscess at right buttock, erythematous, tender	2026-07-27 11:12:44
87026072711124400801	OPD Record	Physical Examination	General Appearance: good consciousness with orientation to time place and person	2026-07-27 11:12:44
87026072711124400801	OPD Record	Physical Examination	HEENT: not pale conjunctiva, anicteric sclera	2026-07-27 11:12:44
87026072711124400801	OPD Record	Physical Examination	Respiratory: equal breath sound with no adventitious sound	2026-07-27 11:12:44
87026072711124400801	OPD Record	Physical Examination	Cardiovascular: normal s1s2, no murmur	2026-07-27 11:12:44
87026072711124400801	OPD Record	Physical Examination	Gastrointestinal: no distension soft, no tenderness no mass active bowel sound	2026-07-27 11:12:44
87026072711124400801	OPD Record	Physical Examination	Extremities: no arthritis, no edema	2026-07-27 11:12:44
87026072711124400801	OPD Record	Physical Examination	Skin: no rash	2026-07-27 11:12:44
87026072813401900901	OPD Record	Present Illness	ก้อนใต้ผิวหนังบริเวณสะบักขวา โตช้า ๆ 2 ปี ขนาดปัจจุบัน ~4 ซม.\r\nนิ่ม ขยับได้ ไม่เจ็บ ไม่มีผิวหนังเปลี่ยนสี รำคาญเวลาพิงพนัก ต้องการผ่าตัดออก	2026-07-28 13:40:19
87026072813401900901	OPD Record	Assessment	Subcutaneous lipoma, right scapular area — excision under local anesthesia	2026-07-28 13:40:19
87026072813401900901	OPD Record	Food-Drug Allergy	ไม่มีประวัติแพ้ยาแพ้อาหาร	2026-07-28 13:40:19
87026072813401900901	OPD Record	Physical Examination	Skin: 4x3 cm soft movable subcutaneous mass at right scapular area, no skin change	2026-07-28 13:40:19
87026072813401900901	OPD Record	Physical Examination	General Appearance: good consciousness with orientation to time place and person	2026-07-28 13:40:19
87026072813401900901	OPD Record	Physical Examination	HEENT: not pale conjunctiva, anicteric sclera	2026-07-28 13:40:19
87026072813401900901	OPD Record	Physical Examination	Respiratory: equal breath sound with no adventitious sound	2026-07-28 13:40:19
87026072813401900901	OPD Record	Physical Examination	Cardiovascular: normal s1s2, no murmur	2026-07-28 13:40:19
87026072813401900901	OPD Record	Physical Examination	Gastrointestinal: no distension soft, no tenderness no mass active bowel sound	2026-07-28 13:40:19
87026072813401900901	OPD Record	Physical Examination	Extremities: no arthritis, no edema	2026-07-28 13:40:19
87026072813401900901	OPD Record	Physical Examination	Skin: no rash	2026-07-28 13:40:19
87026072716380901001	OPD Record	Chief Complaint	พลิกข้อเท้าซ้ายขณะเล่นฟุตบอล 2 ชั่วโมงก่อนมา	2026-07-27 16:38:09
87026072716380901001	OPD Record	Physical Examination	Extremities: left ankle swelling, tender below lateral malleolus, limited ROM, no deformity	2026-07-27 16:38:09
87026072716380901001	OPD Record	Physical Examination	General Appearance: good consciousness with orientation to time place and person	2026-07-27 16:38:09
87026072716380901001	OPD Record	Physical Examination	HEENT: not pale conjunctiva, anicteric sclera	2026-07-27 16:38:09
87026072716380901001	OPD Record	Physical Examination	Respiratory: equal breath sound with no adventitious sound	2026-07-27 16:38:09
87026072716380901001	OPD Record	Physical Examination	Cardiovascular: normal s1s2, no murmur	2026-07-27 16:38:09
87026072716380901001	OPD Record	Physical Examination	Gastrointestinal: no distension soft, no tenderness no mass active bowel sound	2026-07-27 16:38:09
87026072716380901001	OPD Record	Physical Examination	Skin: no rash	2026-07-27 16:38:09
87026080110481501101	OPD Record	Chief Complaint	หอบเหนื่อยกลางคืนบ่อยขึ้น 2 สัปดาห์ ใช้ยาพ่นบ่อย	2026-08-01 10:48:15
87026080110481501101	OPD Record	Present Illness	asthma เดิม ใช้ budesonide/formoterol — 2 สัปดาห์นี้ตื่นกลางคืนจากหอบ 3 ครั้ง/สัปดาห์\r\nใช้ reliever เกือบทุกวัน มีไอแห้ง ๆ ไม่มีไข้ ไม่มีเจ็บหน้าอก แมวเข้ามาอยู่ในบ้านใหม่	2026-08-01 10:48:15
87026080110481501101	OPD Record	Assessment	Asthma, partly controlled — step up ICS/LABA, แนะนำเลี่ยง trigger\r\nCXR วันนี้เพื่อ r/o infiltration: no acute change	2026-08-01 10:48:15
87026072915054701201	OPD Record	Present Illness	ปวดศีรษะทั้งสองข้างแบบตื้อ ๆ เกือบทุกวัน 3 เดือน ช่วงบ่ายมากขึ้น\r\nไม่มีอาเจียนพุ่ง ไม่มีตามัว ไม่มีชัก น้ำหนักคงที่ ทำงานหน้าจอนาน นอนดึก\r\nกังวลมากขอตรวจ CT สมอง	2026-07-29 15:05:47
87026072915054701201	OPD Record	Assessment	Chronic tension-type headache, no red flags — CT brain วันนี้เพื่อคลายกังวล: unremarkable	2026-07-29 15:05:47
87026072915054701201	OPD Record	Physical Examination	Neurological: E4V5M6, no focal neurological deficit, fundi normal	2026-07-29 15:05:47
87026072915054701201	OPD Record	Physical Examination	General Appearance: good consciousness with orientation to time place and person	2026-07-29 15:05:47
87026072915054701201	OPD Record	Physical Examination	HEENT: not pale conjunctiva, anicteric sclera	2026-07-29 15:05:47
87026072915054701201	OPD Record	Physical Examination	Respiratory: equal breath sound with no adventitious sound	2026-07-29 15:05:47
87026072915054701201	OPD Record	Physical Examination	Cardiovascular: normal s1s2, no murmur	2026-07-29 15:05:47
87026072915054701201	OPD Record	Physical Examination	Gastrointestinal: no distension soft, no tenderness no mass active bowel sound	2026-07-29 15:05:47
87026072915054701201	OPD Record	Physical Examination	Extremities: no arthritis, no edema	2026-07-29 15:05:47
87026072915054701201	OPD Record	Physical Examination	Skin: no rash	2026-07-29 15:05:47
87026073010193301301	OPD Record	Chief Complaint	มาตรวจมวลกระดูกตามนัด วัยหมดประจำเดือน	2026-07-30 10:19:33
87026073010193301301	OPD Record	Present Illness	หมดประจำเดือน 10 ปี มารดามีประวัติกระดูกสะโพกหักจากล้ม\r\nไม่เคยกระดูกหัก ไม่สูบบุหรี่ ดื่มนมบ้าง ออกกำลังกายเดินสม่ำเสมอ ส่วนสูงลดลง 2 ซม.	2026-07-30 10:19:33
87026073010193301301	OPD Record	Assessment	Postmenopausal — BMD วันนี้: osteopenia lumbar spine (T-score -1.8)\r\nแนะนำ calcium/vitamin D + weight-bearing exercise, ยังไม่เข้าเกณฑ์ยา	2026-07-30 10:19:33
87026072808552901401	OPD Record	Chief Complaint	มาตามนัดความดันโลหิตสูง รับยาต่อ	2026-07-28 08:55:29
87026072808552901401	OPD Record	Present Illness	U/D essential HT 12 ปี on amlodipine 5 mg — home BP 130-140/80\r\nไม่ปวดหัว ไม่เจ็บหน้าอก ไม่บวม ทานยาสม่ำเสมอ ลดเค็มได้บ้าง	2026-07-28 08:55:29
87026072808552901401	OPD Record	Assessment	Essential HT — acceptable control, continue same regimen	2026-07-28 08:55:29
87026072810245101501	OPD Record	Chief Complaint	จุกแน่นลิ้นปี่หลังอาหาร 3 สัปดาห์	2026-07-28 10:24:51
87026072810245101501	OPD Record	Physical Examination	Gastrointestinal: mild epigastric tenderness, no guarding, no mass	2026-07-28 10:24:51
87026072810245101501	OPD Record	Physical Examination	General Appearance: good consciousness with orientation to time place and person	2026-07-28 10:24:51
87026072810245101501	OPD Record	Physical Examination	HEENT: not pale conjunctiva, anicteric sclera	2026-07-28 10:24:51
87026072810245101501	OPD Record	Physical Examination	Respiratory: equal breath sound with no adventitious sound	2026-07-28 10:24:51
87026072810245101501	OPD Record	Physical Examination	Cardiovascular: normal s1s2, no murmur	2026-07-28 10:24:51
87026072810245101501	OPD Record	Physical Examination	Gastrointestinal: no distension soft, no tenderness no mass active bowel sound	2026-07-28 10:24:51
87026072810245101501	OPD Record	Physical Examination	Extremities: no arthritis, no edema	2026-07-28 10:24:51
87026072810245101501	OPD Record	Physical Examination	Skin: no rash	2026-07-28 10:24:51
87026072909410201601	OPD Record	Present Illness	คัดจมูก จามตอนเช้า น้ำมูกใส คันตา สัมพันธ์กับฝุ่น เป็นมากช่วงเช้า\r\nมีประวัติแพ้ไรฝุ่น ไม่มีไข้ ไม่มีเสมหะเขียว	2026-07-29 09:41:02
87026072909410201601	OPD Record	Assessment	Allergic rhinitis, intermittent — antihistamine + intranasal steroid	2026-07-29 09:41:02
87026072909410201601	OPD Record	Food-Drug Allergy	ไรฝุ่น อาการคัดจมูก จาม	2026-07-29 09:41:02
87026072909410201601	OPD Record	Physical Examination	HEENT: pale boggy nasal mucosa, clear discharge, no sinus tenderness	2026-07-29 09:41:02
87026072909410201601	OPD Record	Physical Examination	General Appearance: good consciousness with orientation to time place and person	2026-07-29 09:41:02
87026072909410201601	OPD Record	Physical Examination	HEENT: not pale conjunctiva, anicteric sclera	2026-07-29 09:41:02
87026072909410201601	OPD Record	Physical Examination	Respiratory: equal breath sound with no adventitious sound	2026-07-29 09:41:02
87026072909410201601	OPD Record	Physical Examination	Cardiovascular: normal s1s2, no murmur	2026-07-29 09:41:02
87026072909410201601	OPD Record	Physical Examination	Gastrointestinal: no distension soft, no tenderness no mass active bowel sound	2026-07-29 09:41:02
87026072909410201601	OPD Record	Physical Examination	Extremities: no arthritis, no edema	2026-07-29 09:41:02
87026072909410201601	OPD Record	Physical Examination	Skin: no rash	2026-07-29 09:41:02
87026072913173601701	OPD Record	Chief Complaint	ปัสสาวะแสบขัด ปัสสาวะบ่อย 2 วัน	2026-07-29 13:17:36
87026072913173601701	OPD Record	Present Illness	ปัสสาวะแสบขัด กะปริบกะปรอย ปวดท้องน้อยเล็กน้อย ไม่มีไข้ ไม่ปวดเอว\r\nไม่มีตกขาวผิดปกติ ดื่มน้ำน้อย กลั้นปัสสาวะบ่อยจากงาน	2026-07-29 13:17:36
87026072913173601701	OPD Record	Assessment	Acute uncomplicated cystitis — norfloxacin 3 วัน + เพิ่มการดื่มน้ำ	2026-07-29 13:17:36
87026072913173601701	OPD Record	Order	Urine Analysis	2026-07-29 13:17:36
87026073115294701801	OPD Record	Chief Complaint	ตาแดงขวา ขี้ตาเยอะ 2 วัน	2026-07-31 15:29:47
87026073115294701801	OPD Record	Present Illness	ตาขวาแดง มีขี้ตาสีเหลืองตอนเช้า เคืองตา ไม่ปวดตา ตามัวเล็กน้อยจากขี้ตา\r\nไม่มีประวัติสิ่งแปลกปลอมเข้าตา	2026-07-31 15:29:47
87026073008122001901	OPD Record	Chief Complaint	มาตรวจสุขภาพประจำปี ไม่มีอาการผิดปกติ	2026-07-30 08:12:20
87026073008122001901	OPD Record	Order	CBC, FBS, Lipid profile, Creatinine, Urine Analysis	2026-07-30 08:12:20
87026073008122001901	OPD Record	Physical Examination	General Appearance: good consciousness with orientation to time place and person	2026-07-30 08:12:20
87026073008122001901	OPD Record	Physical Examination	HEENT: not pale conjunctiva, anicteric sclera	2026-07-30 08:12:20
87026073008122001901	OPD Record	Physical Examination	Respiratory: equal breath sound with no adventitious sound	2026-07-30 08:12:20
87026073008122001901	OPD Record	Physical Examination	Cardiovascular: normal s1s2, no murmur	2026-07-30 08:12:20
87026073008122001901	OPD Record	Physical Examination	Gastrointestinal: no distension soft, no tenderness no mass active bowel sound	2026-07-30 08:12:20
87026073008122001901	OPD Record	Physical Examination	Extremities: no arthritis, no edema	2026-07-30 08:12:20
87026073008122001901	OPD Record	Physical Examination	Skin: no rash	2026-07-30 08:12:20
87026073014031102001	OPD Record	Chief Complaint	ไข้สูง 2 วัน ปวดเมื่อยตามตัว ทานได้น้อย	2026-07-30 14:03:11
87026073014031102001	OPD Record	Present Illness	ไข้สูงลอย 2 วัน ปวดกระบอกตา ปวดเมื่อยกล้ามเนื้อ ไม่มีน้ำมูก ไม่ไอ\r\nในหมู่บ้านมีเพื่อนเป็นไข้เลือดออก tourniquet test: negative วันนี้\r\nไม่มีจุดเลือดออก ไม่มีอาเจียน	2026-07-30 14:03:11
87026073014031102001	OPD Record	Assessment	Acute febrile illness D2, r/o dengue — NS1 negative วันนี้ นัด CBC ซ้ำพรุ่งนี้\r\nแนะนำ warning signs	2026-07-30 14:03:11
87026073014031102001	OPD Record	Order	CBC, Dengue NS1 Ag	2026-07-30 14:03:11
87026073015264002101	OPD Record	Present Illness	hypothyroidism on levothyroxine 50 mcg — อ่อนเพลียลดลง น้ำหนักคงที่ ไม่หนาวง่าย\r\nทานยาตอนเช้าท้องว่างสม่ำเสมอ (วันนี้ยาหมด รอผลก่อนจ่าย)	2026-07-30 15:26:40
87026073015264002101	OPD Record	Assessment	Hypothyroidism — TSH ยังสูงเล็กน้อย ปรับ levothyroxine เป็น 75 mcg/d นัด 8 สัปดาห์	2026-07-30 15:26:40
87026073015264002101	OPD Record	Order	Thyroid Function Test	2026-07-30 15:26:40
87026073015264002101	OPD Record	Physical Examination	HEENT: no goiter, no thyroid nodule palpable	2026-07-30 15:26:40
87026073015264002101	OPD Record	Physical Examination	General Appearance: good consciousness with orientation to time place and person	2026-07-30 15:26:40
87026073015264002101	OPD Record	Physical Examination	HEENT: not pale conjunctiva, anicteric sclera	2026-07-30 15:26:40
87026073015264002101	OPD Record	Physical Examination	Respiratory: equal breath sound with no adventitious sound	2026-07-30 15:26:40
87026073015264002101	OPD Record	Physical Examination	Cardiovascular: normal s1s2, no murmur	2026-07-30 15:26:40
87026073015264002101	OPD Record	Physical Examination	Gastrointestinal: no distension soft, no tenderness no mass active bowel sound	2026-07-30 15:26:40
87026073015264002101	OPD Record	Physical Examination	Extremities: no arthritis, no edema	2026-07-30 15:26:40
87026073015264002101	OPD Record	Physical Examination	Skin: no rash	2026-07-30 15:26:40
\.


--
-- Data for Name: medhack_medicalrecord_result; Type: TABLE DATA; Schema: imed; Owner: -
--

COPY imed.medhack_medicalrecord_result (transactionnumber, tmlt, cgd, name, documenttype, fieldid, fieldname, subfieldname, value, uom, recorddatetime) FROM stdin;
87026072413210500101	300034	30101	CBC	Diagnostic Report	87026072413	Specimen	Hb	12.9	g/dL	2026-07-24 13:21:05
87026072413210500101	300034	30101	CBC	Diagnostic Report	87026072413	Specimen	Hct	38.8	%	2026-07-24 13:21:05
87026072413210500101	300034	30101	CBC	Diagnostic Report	87026072413	Specimen	White Cell Count	14200	cells/cu.mm.	2026-07-24 13:21:05
87026072413210500101	300034	30101	CBC	Diagnostic Report	87026072413	Specimen	Platelets Count	310000	cells/cu.mm.	2026-07-24 13:21:05
87026072413210500101	300034	30101	CBC	Diagnostic Report	87026072413	Specimen	Neutrophil	81	%	2026-07-24 13:21:05
87026072413210500101	300034	30101	CBC	Diagnostic Report	87026072413	Specimen	Lymphocyte	12	%	2026-07-24 13:21:05
87026072413210500101	300034	30101	CBC	Diagnostic Report	87026072413	Specimen	Monocyte	5	%	2026-07-24 13:21:05
87026072413210500101	300034	30101	CBC	Diagnostic Report	87026072413	Specimen	Eosinophil	2	%	2026-07-24 13:21:05
87026072413210500101	351520	36611	Influenza A and B virus Ag (rapid test)	Diagnostic Report	87026072413	Specimen	Influenza A Ag	Negative	\N	2026-07-24 13:21:05
87026072413210500101	351520	36611	Influenza A and B virus Ag (rapid test)	Diagnostic Report	87026072413	Specimen	Influenza B Ag	Negative	\N	2026-07-24 13:21:05
87026072413210500101	300771	32201	Creatinine	Diagnostic Report	87026072413	Specimen	Creatinine	0.86	mg/dL	2026-07-24 13:21:05
87026072413210500101	300771	32201	Creatinine	Diagnostic Report	87026072413	Specimen	eGFR for Thai	92	mL/min/1.73m^2	2026-07-24 13:21:05
87026072413210500101	\N	41003	Chest PA Upright	Radiology Report	87026072413	Study	xray_result	CHEST PA UPRIGHT:\r\nPatchy air-space opacity at right lower lobe. No pleural effusion.\r\nCardiothoracic ratio is within normal limit. Both costophrenic angles are sharp.\r\nIMPRESSION: Right lower lobe pneumonia.	\N	2026-07-24 13:21:05
87026072209142300201	300034	30101	CBC	Diagnostic Report	87026072209	Specimen	Hb	13.8	g/dL	2026-07-22 09:14:23
87026072209142300201	300034	30101	CBC	Diagnostic Report	87026072209	Specimen	Hct	41.2	%	2026-07-22 09:14:23
87026072209142300201	300034	30101	CBC	Diagnostic Report	87026072209	Specimen	White Cell Count	7800	cells/cu.mm.	2026-07-22 09:14:23
87026072209142300201	300034	30101	CBC	Diagnostic Report	87026072209	Specimen	Platelets Count	265000	cells/cu.mm.	2026-07-22 09:14:23
87026072209142300201	300034	30101	CBC	Diagnostic Report	87026072209	Specimen	Neutrophil	58	%	2026-07-22 09:14:23
87026072209142300201	300034	30101	CBC	Diagnostic Report	87026072209	Specimen	Lymphocyte	33	%	2026-07-22 09:14:23
87026072209142300201	300034	30101	CBC	Diagnostic Report	87026072209	Specimen	Monocyte	6	%	2026-07-22 09:14:23
87026072209142300201	300034	30101	CBC	Diagnostic Report	87026072209	Specimen	Eosinophil	3	%	2026-07-22 09:14:23
87026072508311700301	301081	32203	Glucose (Fasting)	Diagnostic Report	87026072508	Specimen	Glucose (Fasting)	132	mg/dL	2026-07-25 08:31:17
87026072508311700301	301941	32301	Hb A1C	Diagnostic Report	87026072508	Specimen	Hb A1C	7.4	%	2026-07-25 08:31:17
87026072508311700301	303801	32501	Lipid profile	Diagnostic Report	87026072508	Specimen	Cholesterol	228	mg/dL	2026-07-25 08:31:17
87026072508311700301	303801	32501	Lipid profile	Diagnostic Report	87026072508	Specimen	Triglyceride	186	mg/dL	2026-07-25 08:31:17
87026072508311700301	303801	32501	Lipid profile	Diagnostic Report	87026072508	Specimen	HDL	48	mg/dL	2026-07-25 08:31:17
87026072508311700301	303801	32501	Lipid profile	Diagnostic Report	87026072508	Specimen	LDL (calculated)	143	mg/dL	2026-07-25 08:31:17
87026072508311700301	300771	32201	Creatinine	Diagnostic Report	87026072508	Specimen	Creatinine	0.86	mg/dL	2026-07-25 08:31:17
87026072508311700301	300771	32201	Creatinine	Diagnostic Report	87026072508	Specimen	eGFR for Thai	92	mL/min/1.73m^2	2026-07-25 08:31:17
87026072414445200401	\N	41201	LS spine AP/Lateral	Radiology Report	87026072414	Study	xray_result	LS SPINE AP/LATERAL:\r\nNormal alignment. Mild disc space narrowing at L4-5.\r\nNo spondylolisthesis. No fracture or bone destruction. SI joints are unremarkable.\r\nIMPRESSION: Mild degenerative change L4-5.	\N	2026-07-24 14:44:52
87026072716380901001	\N	41101	Ankle (Lt) AP/Lateral	Radiology Report	87026072716	Study	xray_result	LEFT ANKLE AP/LATERAL:\r\nNo fracture or dislocation. Soft tissue swelling over lateral malleolus.\r\nAnkle mortise is intact.\r\nIMPRESSION: Soft tissue swelling, no fracture.	\N	2026-07-27 16:38:09
87026080110481501101	\N	41003	Chest PA Upright	Radiology Report	87026080110	Study	xray_result	CHEST PA UPRIGHT:\r\nBoth lungs are clear. No infiltration or mass.\r\nNormal heart size. IMPRESSION: No acute cardiopulmonary abnormality.	\N	2026-08-01 10:48:15
87026072915054701201	\N	42201	CT Brain non contrast	Radiology Report	87026072915	Study	xray_result	CT BRAIN WITHOUT CONTRAST:\r\nNo intracranial hemorrhage, mass or midline shift.\r\nNormal ventricles and basal cisterns. No abnormal parenchymal density.\r\nIMPRESSION: Unremarkable CT brain.	\N	2026-07-29 15:05:47
87026073010193301301	\N	42702	Bone density Spine	Radiology Report	87026073010	Study	xray_result	BMD LUMBAR SPINE (L1-L4):\r\nT-score -1.8, Z-score -0.6.\r\nIMPRESSION: Osteopenia.	\N	2026-07-30 10:19:33
87026073010193301301	\N	42702	Bone density Femur	Radiology Report	87026073010	Study	xray_result	BMD FEMORAL NECK:\r\nT-score -1.4, Z-score -0.4.\r\nIMPRESSION: Osteopenia.	\N	2026-07-30 10:19:33
87026072913173601701	300481	31001	Urine Analysis	Diagnostic Report	87026072913	Specimen	Color	Yellow	\N	2026-07-29 13:17:36
87026072913173601701	300481	31001	Urine Analysis	Diagnostic Report	87026072913	Specimen	Appearance	Slightly turbid	\N	2026-07-29 13:17:36
87026072913173601701	300481	31001	Urine Analysis	Diagnostic Report	87026072913	Specimen	pH	6.0	\N	2026-07-29 13:17:36
87026072913173601701	300481	31001	Urine Analysis	Diagnostic Report	87026072913	Specimen	Sp.gr.	1.020	\N	2026-07-29 13:17:36
87026072913173601701	300481	31001	Urine Analysis	Diagnostic Report	87026072913	Specimen	WBC	20-30	cells/HPF	2026-07-29 13:17:36
87026072913173601701	300481	31001	Urine Analysis	Diagnostic Report	87026072913	Specimen	RBC	3-5	cells/HPF	2026-07-29 13:17:36
87026072913173601701	300481	31001	Urine Analysis	Diagnostic Report	87026072913	Specimen	Protein	Trace	\N	2026-07-29 13:17:36
87026072913173601701	300481	31001	Urine Analysis	Diagnostic Report	87026072913	Specimen	Glucose	Negative	\N	2026-07-29 13:17:36
87026072913173601701	300481	31001	Urine Analysis	Diagnostic Report	87026072913	Specimen	Bacteria	Moderate	\N	2026-07-29 13:17:36
87026073008122001901	300034	30101	CBC	Diagnostic Report	87026073008	Specimen	Hb	13.8	g/dL	2026-07-30 08:12:20
87026073008122001901	300034	30101	CBC	Diagnostic Report	87026073008	Specimen	Hct	41.2	%	2026-07-30 08:12:20
87026073008122001901	300034	30101	CBC	Diagnostic Report	87026073008	Specimen	White Cell Count	7800	cells/cu.mm.	2026-07-30 08:12:20
87026073008122001901	300034	30101	CBC	Diagnostic Report	87026073008	Specimen	Platelets Count	265000	cells/cu.mm.	2026-07-30 08:12:20
87026073008122001901	300034	30101	CBC	Diagnostic Report	87026073008	Specimen	Neutrophil	58	%	2026-07-30 08:12:20
87026073008122001901	300034	30101	CBC	Diagnostic Report	87026073008	Specimen	Lymphocyte	33	%	2026-07-30 08:12:20
87026073008122001901	300034	30101	CBC	Diagnostic Report	87026073008	Specimen	Monocyte	6	%	2026-07-30 08:12:20
87026073008122001901	300034	30101	CBC	Diagnostic Report	87026073008	Specimen	Eosinophil	3	%	2026-07-30 08:12:20
87026073008122001901	301081	32203	Glucose (Fasting)	Diagnostic Report	87026073008	Specimen	Glucose (Fasting)	88	mg/dL	2026-07-30 08:12:20
87026073008122001901	303801	32501	Lipid profile	Diagnostic Report	87026073008	Specimen	Cholesterol	182	mg/dL	2026-07-30 08:12:20
87026073008122001901	303801	32501	Lipid profile	Diagnostic Report	87026073008	Specimen	Triglyceride	110	mg/dL	2026-07-30 08:12:20
87026073008122001901	303801	32501	Lipid profile	Diagnostic Report	87026073008	Specimen	HDL	55	mg/dL	2026-07-30 08:12:20
87026073008122001901	303801	32501	Lipid profile	Diagnostic Report	87026073008	Specimen	LDL (calculated)	104	mg/dL	2026-07-30 08:12:20
87026073008122001901	300771	32201	Creatinine	Diagnostic Report	87026073008	Specimen	Creatinine	0.86	mg/dL	2026-07-30 08:12:20
87026073008122001901	300771	32201	Creatinine	Diagnostic Report	87026073008	Specimen	eGFR for Thai	92	mL/min/1.73m^2	2026-07-30 08:12:20
87026073008122001901	300481	31001	Urine Analysis	Diagnostic Report	87026073008	Specimen	Color	Yellow	\N	2026-07-30 08:12:20
87026073008122001901	300481	31001	Urine Analysis	Diagnostic Report	87026073008	Specimen	Appearance	Clear	\N	2026-07-30 08:12:20
87026073008122001901	300481	31001	Urine Analysis	Diagnostic Report	87026073008	Specimen	pH	6.0	\N	2026-07-30 08:12:20
87026073008122001901	300481	31001	Urine Analysis	Diagnostic Report	87026073008	Specimen	Sp.gr.	1.015	\N	2026-07-30 08:12:20
87026073008122001901	300481	31001	Urine Analysis	Diagnostic Report	87026073008	Specimen	WBC	0-1	cells/HPF	2026-07-30 08:12:20
87026073008122001901	300481	31001	Urine Analysis	Diagnostic Report	87026073008	Specimen	RBC	0-1	cells/HPF	2026-07-30 08:12:20
87026073008122001901	300481	31001	Urine Analysis	Diagnostic Report	87026073008	Specimen	Protein	Negative	\N	2026-07-30 08:12:20
87026073008122001901	300481	31001	Urine Analysis	Diagnostic Report	87026073008	Specimen	Glucose	Negative	\N	2026-07-30 08:12:20
87026073014031102001	300034	30101	CBC	Diagnostic Report	87026073014	Specimen	Hb	13.8	g/dL	2026-07-30 14:03:11
87026073014031102001	300034	30101	CBC	Diagnostic Report	87026073014	Specimen	Hct	41.2	%	2026-07-30 14:03:11
87026073014031102001	300034	30101	CBC	Diagnostic Report	87026073014	Specimen	White Cell Count	7800	cells/cu.mm.	2026-07-30 14:03:11
87026073014031102001	300034	30101	CBC	Diagnostic Report	87026073014	Specimen	Platelets Count	265000	cells/cu.mm.	2026-07-30 14:03:11
87026073014031102001	300034	30101	CBC	Diagnostic Report	87026073014	Specimen	Neutrophil	58	%	2026-07-30 14:03:11
87026073014031102001	300034	30101	CBC	Diagnostic Report	87026073014	Specimen	Lymphocyte	33	%	2026-07-30 14:03:11
87026073014031102001	300034	30101	CBC	Diagnostic Report	87026073014	Specimen	Monocyte	6	%	2026-07-30 14:03:11
87026073014031102001	300034	30101	CBC	Diagnostic Report	87026073014	Specimen	Eosinophil	3	%	2026-07-30 14:03:11
87026073014031102001	352230	36701	Dengue virus Ag NS1	Diagnostic Report	87026073014	Specimen	Dengue NS1 Ag	Negative	\N	2026-07-30 14:03:11
87026073015264002101	304401	32801	Thyroid Function Test	Diagnostic Report	87026073015	Specimen	TSH	6.8	uIU/mL	2026-07-30 15:26:40
87026073015264002101	304401	32801	Thyroid Function Test	Diagnostic Report	87026073015	Specimen	Free T4	0.9	ng/dL	2026-07-30 15:26:40
\.


--
-- Data for Name: medhack_orderdrug; Type: TABLE DATA; Schema: imed; Owner: -
--

COPY imed.medhack_orderdrug (transactionnumber, id, name, itemid, tmt, dosagesignature, dosageinstruction, quantity, remark, receiveddatetime) FROM stdin;
87026072413210500101	87026072413210013501	AMOXICILLIN + CLAVULANATE 1 G TAB [AUGMENTIN]	DRG0135	\N	oral 1 tab twice daily pc	ครั้งละ 1 เม็ด เช้า-เย็น หลังอาหาร	14	\N	2026-07-24 13:21:05
87026072413210500101	87026072413210013601	BROMHEXINE 8 MG TAB	DRG0136	\N	oral 1 tab three times daily pc	ครั้งละ 1 เม็ด วันละ 3 ครั้ง หลังอาหาร	30	\N	2026-07-24 13:21:05
87026072413210500101	87026072413210013701	PARACETAMOL 500 MG TAB	DRG0137	\N	oral 1 tab every 6 hours prn fever	ครั้งละ 1 เม็ด ทุก 6 ชั่วโมง เวลามีไข้	20	\N	2026-07-24 13:21:05
87026072209142300201	87026072209142012101	DAFLON 500 MG TAB	DRG0121	\N	oral 2 tab three times daily pc	ครั้งละ 2 เม็ด วันละ 3 ครั้ง หลังอาหาร	30	\N	2026-07-22 09:14:23
87026072209142300201	87026072209142012201	PARACETAMOL 500 MG TAB	DRG0122	\N	oral 1 tab every 6 hours prn for pain	ครั้งละ 1 เม็ด ทุก 6 ชั่วโมง เวลาปวด	20	\N	2026-07-22 09:14:23
87026072209142300201	87026072209142012301	SENOKOT TAB	DRG0123	\N	oral 2 tab once daily hs	ครั้งละ 2 เม็ด วันละ 1 ครั้ง ก่อนนอน	20	\N	2026-07-22 09:14:23
87026072508311700301	87026072508311013001	metFORMIN HCl TAB 500 MG [HAD]	DRG0130	\N	oral 2 tab twice daily pc	ครั้งละ 2 เม็ด เช้า-เย็น หลังอาหาร	240	\N	2026-07-25 08:31:17
87026072508311700301	87026072508311013101	ATORVASTATIN 20 MG TAB	DRG0131	\N	oral 1 tab once daily hs	ครั้งละ 1 เม็ด วันละ 1 ครั้ง ก่อนนอน	90	\N	2026-07-25 08:31:17
87026072508311700301	87026072508311013201	ENALAPRIL 5 MG TAB	DRG0132	\N	oral 1 tab once daily pc am	ครั้งละ 1 เม็ด วันละ 1 ครั้ง หลังอาหารเช้า	90	\N	2026-07-25 08:31:17
87026072414445200401	87026072414445010201	IBUPROFEN 400 MG TAB	DRG0102	\N	oral 1 tab three times daily pc	ครั้งละ 1 เม็ด วันละ 3 ครั้ง หลังอาหารทันที	30	\N	2026-07-24 14:44:52
87026072414445200401	87026072414445010301	TOLPERISONE 50 MG TAB	DRG0103	\N	oral 1 tab three times daily pc	ครั้งละ 1 เม็ด วันละ 3 ครั้ง หลังอาหาร	30	\N	2026-07-24 14:44:52
87026073109520800501	87026073109520010201	ORS POWDER [ROYAL-D]	DRG0102	\N	dissolve in 250 ml water sip frequently	ละลายน้ำ 250 มล. จิบบ่อย ๆ	10	\N	2026-07-31 09:52:08
87026073109520800501	87026073109520010301	DOMPERIDONE 10 MG TAB	DRG0103	\N	oral 1 tab three times daily ac	ครั้งละ 1 เม็ด วันละ 3 ครั้ง ก่อนอาหาร	15	\N	2026-07-31 09:52:08
87026073111085600601	87026073111085010201	NAPROXEN 250 MG TAB	DRG0102	\N	oral 2 tab stat then 1 tab q 8 hr prn	ครั้งแรก 2 เม็ด ต่อไปครั้งละ 1 เม็ด ทุก 8 ชม. เวลาปวด	20	\N	2026-07-31 11:08:56
87026073111085600601	87026073111085010301	DOMPERIDONE 10 MG TAB	DRG0103	\N	oral 1 tab three times daily ac	ครั้งละ 1 เม็ด วันละ 3 ครั้ง ก่อนอาหาร	15	\N	2026-07-31 11:08:56
87026072310024100701	87026072310024010201	DESOGESTRAL 150 MCG + EE 20 MCG TAB [MERCILON]	DRG0102	\N	oral 1 tab once daily hs	วันละ 1 เม็ด ก่อนนอน	3	\N	2026-07-23 10:02:41
87026072711124400801	87026072711124010201	DICLOXACILLIN 500 MG CAP	DRG0102	\N	oral 1 cap four times daily ac	ครั้งละ 1 แคปซูล วันละ 4 ครั้ง ก่อนอาหาร	28	\N	2026-07-27 11:12:44
87026072711124400801	87026072711124010301	PARACETAMOL 500 MG TAB	DRG0103	\N	oral 1 tab every 6 hours prn for pain	ครั้งละ 1 เม็ด ทุก 6 ชั่วโมง เวลาปวด	20	\N	2026-07-27 11:12:44
87026072813401900901	87026072813401010201	PARACETAMOL 500 MG TAB	DRG0102	\N	oral 1 tab every 6 hours prn for pain	ครั้งละ 1 เม็ด ทุก 6 ชั่วโมง เวลาปวด	10	\N	2026-07-28 13:40:19
87026080110481501101	87026080110481010201	BUDESONIDE/FORMOTEROL 160/4.5 TURBUHALER	DRG0102	\N	inhale 2 puffs twice daily	สูดพ่น 2 ครั้ง เช้า-เย็น	1	\N	2026-08-01 10:48:15
87026080110481501101	87026080110481010301	SALBUTAMOL MDI 100 MCG	DRG0103	\N	inhale 2 puffs prn dyspnea	พ่น 2 ครั้ง เวลาเหนื่อย	1	\N	2026-08-01 10:48:15
87026072808552901401	87026072808552010201	AMLODIPINE 5 MG TAB	DRG0102	\N	oral 1 tab once daily pc am	ครั้งละ 1 เม็ด วันละ 1 ครั้ง หลังอาหารเช้า	90	\N	2026-07-28 08:55:29
87026072810245101501	87026072810245010201	OMEPRAZOLE 20 MG CAP	DRG0102	\N	oral 1 cap once daily ac am	ครั้งละ 1 แคปซูล วันละ 1 ครั้ง ก่อนอาหารเช้า	28	\N	2026-07-28 10:24:51
87026072909410201601	87026072909410010201	CETIRIZINE 10 MG TAB	DRG0102	\N	oral 1 tab once daily hs	ครั้งละ 1 เม็ด วันละ 1 ครั้ง ก่อนนอน	30	\N	2026-07-29 09:41:02
87026072909410201601	87026072909410010301	MOMETASONE NASAL SPRAY 50 MCG	DRG0103	\N	2 sprays each nostril once daily	พ่นจมูกข้างละ 2 ครั้ง วันละ 1 ครั้ง เช้า	1	\N	2026-07-29 09:41:02
87026072913173601701	87026072913173012301	NORFLOXACIN 400 MG TAB	DRG0123	\N	oral 1 tab twice daily pc	ครั้งละ 1 เม็ด เช้า-เย็น หลังอาหาร	6	\N	2026-07-29 13:17:36
87026073115294701801	87026073115294010201	TOBRAMYCIN EYE DROP 0.3%	DRG0102	\N	1 drop right eye four times daily	หยอดตาขวา ครั้งละ 1 หยด วันละ 4 ครั้ง	1	\N	2026-07-31 15:29:47
\.


--
-- Data for Name: medhack_orderlab; Type: TABLE DATA; Schema: imed; Owner: -
--

COPY imed.medhack_orderlab (transactionnumber, id, panelname, paneltmlt, panelcgd, collectdatetime, reportdatetime, itemid, itemtmlt, itemcgd, itemname, itemvalue, itemuom) FROM stdin;
87026072413210500101	87026072413210010301	CBC	300034	30101	2026-07-24 13:21:05	2026-07-24 13:21:05	87026072413210010201	300034	30101	Hb	12.9	g/dL
87026072413210500101	87026072413210010401	CBC	300034	30101	2026-07-24 13:21:05	2026-07-24 13:21:05	87026072413210010201	300034	30101	Hct	38.8	%
87026072413210500101	87026072413210010501	CBC	300034	30101	2026-07-24 13:21:05	2026-07-24 13:21:05	87026072413210010201	300034	30101	White Cell Count	14200	cells/cu.mm.
87026072413210500101	87026072413210010601	CBC	300034	30101	2026-07-24 13:21:05	2026-07-24 13:21:05	87026072413210010201	300034	30101	Platelets Count	310000	cells/cu.mm.
87026072413210500101	87026072413210010701	CBC	300034	30101	2026-07-24 13:21:05	2026-07-24 13:21:05	87026072413210010201	300034	30101	Neutrophil	81	%
87026072413210500101	87026072413210010801	CBC	300034	30101	2026-07-24 13:21:05	2026-07-24 13:21:05	87026072413210010201	300034	30101	Lymphocyte	12	%
87026072413210500101	87026072413210010901	CBC	300034	30101	2026-07-24 13:21:05	2026-07-24 13:21:05	87026072413210010201	300034	30101	Monocyte	5	%
87026072413210500101	87026072413210011001	CBC	300034	30101	2026-07-24 13:21:05	2026-07-24 13:21:05	87026072413210010201	300034	30101	Eosinophil	2	%
87026072413210500101	87026072413210011101	CBC	300034	30101	2026-07-24 13:21:05	2026-07-24 13:21:05	87026072413210010201	300034	30101	Comment	\N	\N
87026072413210500101	87026072413210011201	CBC	300034	30101	2026-07-24 13:21:05	2026-07-24 13:21:05	87026072413210010201	300034	30101	Attach File	\N	\N
87026072413210500101	87026072413210012201	Influenza A and B virus Ag (rapid test)	351520	36611	2026-07-24 13:21:05	2026-07-24 13:21:05	87026072413210012101	351520	36611	Influenza A Ag	Negative	\N
87026072413210500101	87026072413210012301	Influenza A and B virus Ag (rapid test)	351520	36611	2026-07-24 13:21:05	2026-07-24 13:21:05	87026072413210012101	351520	36611	Influenza B Ag	Negative	\N
87026072413210500101	87026072413210012401	Influenza A and B virus Ag (rapid test)	351520	36611	2026-07-24 13:21:05	2026-07-24 13:21:05	87026072413210012101	351520	36611	Comment	\N	\N
87026072413210500101	87026072413210012501	Influenza A and B virus Ag (rapid test)	351520	36611	2026-07-24 13:21:05	2026-07-24 13:21:05	87026072413210012101	351520	36611	Attach File	\N	\N
87026072413210500101	87026072413210012901	Creatinine	300771	32201	2026-07-24 13:21:05	2026-07-24 13:21:05	87026072413210012801	300771	32201	Creatinine	0.86	mg/dL
87026072413210500101	87026072413210013001	Creatinine	300771	32201	2026-07-24 13:21:05	2026-07-24 13:21:05	87026072413210012801	300771	32201	eGFR for Thai	92	mL/min/1.73m^2
87026072413210500101	87026072413210013101	Creatinine	300771	32201	2026-07-24 13:21:05	2026-07-24 13:21:05	87026072413210012801	300771	32201	Comment	\N	\N
87026072413210500101	87026072413210013201	Creatinine	300771	32201	2026-07-24 13:21:05	2026-07-24 13:21:05	87026072413210012801	300771	32201	Attach File	\N	\N
87026072209142300201	87026072209142010301	CBC	300034	30101	2026-07-22 09:14:23	2026-07-22 09:14:23	87026072209142010201	300034	30101	Hb	13.8	g/dL
87026072209142300201	87026072209142010401	CBC	300034	30101	2026-07-22 09:14:23	2026-07-22 09:14:23	87026072209142010201	300034	30101	Hct	41.2	%
87026072209142300201	87026072209142010501	CBC	300034	30101	2026-07-22 09:14:23	2026-07-22 09:14:23	87026072209142010201	300034	30101	White Cell Count	7800	cells/cu.mm.
87026072209142300201	87026072209142010601	CBC	300034	30101	2026-07-22 09:14:23	2026-07-22 09:14:23	87026072209142010201	300034	30101	Platelets Count	265000	cells/cu.mm.
87026072209142300201	87026072209142010701	CBC	300034	30101	2026-07-22 09:14:23	2026-07-22 09:14:23	87026072209142010201	300034	30101	Neutrophil	58	%
87026072209142300201	87026072209142010801	CBC	300034	30101	2026-07-22 09:14:23	2026-07-22 09:14:23	87026072209142010201	300034	30101	Lymphocyte	33	%
87026072209142300201	87026072209142010901	CBC	300034	30101	2026-07-22 09:14:23	2026-07-22 09:14:23	87026072209142010201	300034	30101	Monocyte	6	%
87026072209142300201	87026072209142011001	CBC	300034	30101	2026-07-22 09:14:23	2026-07-22 09:14:23	87026072209142010201	300034	30101	Eosinophil	3	%
87026072209142300201	87026072209142011101	CBC	300034	30101	2026-07-22 09:14:23	2026-07-22 09:14:23	87026072209142010201	300034	30101	Comment	\N	\N
87026072209142300201	87026072209142011201	CBC	300034	30101	2026-07-22 09:14:23	2026-07-22 09:14:23	87026072209142010201	300034	30101	Attach File	\N	\N
87026072508311700301	87026072508311010301	Glucose (Fasting)	301081	32203	2026-07-25 08:31:17	2026-07-25 08:31:17	87026072508311010201	301081	32203	Glucose (Fasting)	132	mg/dL
87026072508311700301	87026072508311010401	Glucose (Fasting)	301081	32203	2026-07-25 08:31:17	2026-07-25 08:31:17	87026072508311010201	301081	32203	Comment	\N	\N
87026072508311700301	87026072508311010501	Glucose (Fasting)	301081	32203	2026-07-25 08:31:17	2026-07-25 08:31:17	87026072508311010201	301081	32203	Attach File	\N	\N
87026072508311700301	87026072508311010801	Hb A1C	301941	32301	2026-07-25 08:31:17	2026-07-25 08:31:17	87026072508311010701	301941	32301	Hb A1C	7.4	%
87026072508311700301	87026072508311010901	Hb A1C	301941	32301	2026-07-25 08:31:17	2026-07-25 08:31:17	87026072508311010701	301941	32301	Comment	\N	\N
87026072508311700301	87026072508311011001	Hb A1C	301941	32301	2026-07-25 08:31:17	2026-07-25 08:31:17	87026072508311010701	301941	32301	Attach File	\N	\N
87026072508311700301	87026072508311011301	Lipid profile	303801	32501	2026-07-25 08:31:17	2026-07-25 08:31:17	87026072508311011201	303801	32501	Cholesterol	228	mg/dL
87026072508311700301	87026072508311011401	Lipid profile	303801	32501	2026-07-25 08:31:17	2026-07-25 08:31:17	87026072508311011201	303801	32501	Triglyceride	186	mg/dL
87026072508311700301	87026072508311011501	Lipid profile	303801	32501	2026-07-25 08:31:17	2026-07-25 08:31:17	87026072508311011201	303801	32501	HDL	48	mg/dL
87026072508311700301	87026072508311011601	Lipid profile	303801	32501	2026-07-25 08:31:17	2026-07-25 08:31:17	87026072508311011201	303801	32501	LDL (calculated)	143	mg/dL
87026072508311700301	87026072508311011701	Lipid profile	303801	32501	2026-07-25 08:31:17	2026-07-25 08:31:17	87026072508311011201	303801	32501	Comment	\N	\N
87026072508311700301	87026072508311011801	Lipid profile	303801	32501	2026-07-25 08:31:17	2026-07-25 08:31:17	87026072508311011201	303801	32501	Attach File	\N	\N
87026072508311700301	87026072508311012401	Creatinine	300771	32201	2026-07-25 08:31:17	2026-07-25 08:31:17	87026072508311012301	300771	32201	Creatinine	0.86	mg/dL
87026072508311700301	87026072508311012501	Creatinine	300771	32201	2026-07-25 08:31:17	2026-07-25 08:31:17	87026072508311012301	300771	32201	eGFR for Thai	92	mL/min/1.73m^2
87026072508311700301	87026072508311012601	Creatinine	300771	32201	2026-07-25 08:31:17	2026-07-25 08:31:17	87026072508311012301	300771	32201	Comment	\N	\N
87026072508311700301	87026072508311012701	Creatinine	300771	32201	2026-07-25 08:31:17	2026-07-25 08:31:17	87026072508311012301	300771	32201	Attach File	\N	\N
87026072913173601701	87026072913173010301	Urine Analysis	300481	31001	2026-07-29 13:17:36	2026-07-29 13:17:36	87026072913173010201	300481	31001	Color	Yellow	\N
87026072913173601701	87026072913173010401	Urine Analysis	300481	31001	2026-07-29 13:17:36	2026-07-29 13:17:36	87026072913173010201	300481	31001	Appearance	Slightly turbid	\N
87026072913173601701	87026072913173010501	Urine Analysis	300481	31001	2026-07-29 13:17:36	2026-07-29 13:17:36	87026072913173010201	300481	31001	pH	6.0	\N
87026072913173601701	87026072913173010601	Urine Analysis	300481	31001	2026-07-29 13:17:36	2026-07-29 13:17:36	87026072913173010201	300481	31001	Sp.gr.	1.020	\N
87026072913173601701	87026072913173010701	Urine Analysis	300481	31001	2026-07-29 13:17:36	2026-07-29 13:17:36	87026072913173010201	300481	31001	WBC	20-30	cells/HPF
87026072913173601701	87026072913173010801	Urine Analysis	300481	31001	2026-07-29 13:17:36	2026-07-29 13:17:36	87026072913173010201	300481	31001	RBC	3-5	cells/HPF
87026072913173601701	87026072913173010901	Urine Analysis	300481	31001	2026-07-29 13:17:36	2026-07-29 13:17:36	87026072913173010201	300481	31001	Protein	Trace	\N
87026072913173601701	87026072913173011001	Urine Analysis	300481	31001	2026-07-29 13:17:36	2026-07-29 13:17:36	87026072913173010201	300481	31001	Glucose	Negative	\N
87026072913173601701	87026072913173011101	Urine Analysis	300481	31001	2026-07-29 13:17:36	2026-07-29 13:17:36	87026072913173010201	300481	31001	Bacteria	Moderate	\N
87026072913173601701	87026072913173011201	Urine Analysis	300481	31001	2026-07-29 13:17:36	2026-07-29 13:17:36	87026072913173010201	300481	31001	Comment	\N	\N
87026072913173601701	87026072913173011301	Urine Analysis	300481	31001	2026-07-29 13:17:36	2026-07-29 13:17:36	87026072913173010201	300481	31001	Attach File	\N	\N
87026073008122001901	87026073008122010301	CBC	300034	30101	2026-07-30 08:12:20	2026-07-30 08:12:20	87026073008122010201	300034	30101	Hb	13.8	g/dL
87026073008122001901	87026073008122010401	CBC	300034	30101	2026-07-30 08:12:20	2026-07-30 08:12:20	87026073008122010201	300034	30101	Hct	41.2	%
87026073008122001901	87026073008122010501	CBC	300034	30101	2026-07-30 08:12:20	2026-07-30 08:12:20	87026073008122010201	300034	30101	White Cell Count	7800	cells/cu.mm.
87026073008122001901	87026073008122010601	CBC	300034	30101	2026-07-30 08:12:20	2026-07-30 08:12:20	87026073008122010201	300034	30101	Platelets Count	265000	cells/cu.mm.
87026073008122001901	87026073008122010701	CBC	300034	30101	2026-07-30 08:12:20	2026-07-30 08:12:20	87026073008122010201	300034	30101	Neutrophil	58	%
87026073008122001901	87026073008122010801	CBC	300034	30101	2026-07-30 08:12:20	2026-07-30 08:12:20	87026073008122010201	300034	30101	Lymphocyte	33	%
87026073008122001901	87026073008122010901	CBC	300034	30101	2026-07-30 08:12:20	2026-07-30 08:12:20	87026073008122010201	300034	30101	Monocyte	6	%
87026073008122001901	87026073008122011001	CBC	300034	30101	2026-07-30 08:12:20	2026-07-30 08:12:20	87026073008122010201	300034	30101	Eosinophil	3	%
87026073008122001901	87026073008122011101	CBC	300034	30101	2026-07-30 08:12:20	2026-07-30 08:12:20	87026073008122010201	300034	30101	Comment	\N	\N
87026073008122001901	87026073008122011201	CBC	300034	30101	2026-07-30 08:12:20	2026-07-30 08:12:20	87026073008122010201	300034	30101	Attach File	\N	\N
87026073008122001901	87026073008122012201	Glucose (Fasting)	301081	32203	2026-07-30 08:12:20	2026-07-30 08:12:20	87026073008122012101	301081	32203	Glucose (Fasting)	88	mg/dL
87026073008122001901	87026073008122012301	Glucose (Fasting)	301081	32203	2026-07-30 08:12:20	2026-07-30 08:12:20	87026073008122012101	301081	32203	Comment	\N	\N
87026073008122001901	87026073008122012401	Glucose (Fasting)	301081	32203	2026-07-30 08:12:20	2026-07-30 08:12:20	87026073008122012101	301081	32203	Attach File	\N	\N
87026073008122001901	87026073008122012701	Lipid profile	303801	32501	2026-07-30 08:12:20	2026-07-30 08:12:20	87026073008122012601	303801	32501	Cholesterol	182	mg/dL
87026073008122001901	87026073008122012801	Lipid profile	303801	32501	2026-07-30 08:12:20	2026-07-30 08:12:20	87026073008122012601	303801	32501	Triglyceride	110	mg/dL
87026073008122001901	87026073008122012901	Lipid profile	303801	32501	2026-07-30 08:12:20	2026-07-30 08:12:20	87026073008122012601	303801	32501	HDL	55	mg/dL
87026073008122001901	87026073008122013001	Lipid profile	303801	32501	2026-07-30 08:12:20	2026-07-30 08:12:20	87026073008122012601	303801	32501	LDL (calculated)	104	mg/dL
87026073008122001901	87026073008122013101	Lipid profile	303801	32501	2026-07-30 08:12:20	2026-07-30 08:12:20	87026073008122012601	303801	32501	Comment	\N	\N
87026073008122001901	87026073008122013201	Lipid profile	303801	32501	2026-07-30 08:12:20	2026-07-30 08:12:20	87026073008122012601	303801	32501	Attach File	\N	\N
87026073008122001901	87026073008122013801	Creatinine	300771	32201	2026-07-30 08:12:20	2026-07-30 08:12:20	87026073008122013701	300771	32201	Creatinine	0.86	mg/dL
87026073008122001901	87026073008122013901	Creatinine	300771	32201	2026-07-30 08:12:20	2026-07-30 08:12:20	87026073008122013701	300771	32201	eGFR for Thai	92	mL/min/1.73m^2
87026073008122001901	87026073008122014001	Creatinine	300771	32201	2026-07-30 08:12:20	2026-07-30 08:12:20	87026073008122013701	300771	32201	Comment	\N	\N
87026073008122001901	87026073008122014101	Creatinine	300771	32201	2026-07-30 08:12:20	2026-07-30 08:12:20	87026073008122013701	300771	32201	Attach File	\N	\N
87026073008122001901	87026073008122014501	Urine Analysis	300481	31001	2026-07-30 08:12:20	2026-07-30 08:12:20	87026073008122014401	300481	31001	Color	Yellow	\N
87026073008122001901	87026073008122014601	Urine Analysis	300481	31001	2026-07-30 08:12:20	2026-07-30 08:12:20	87026073008122014401	300481	31001	Appearance	Clear	\N
87026073008122001901	87026073008122014701	Urine Analysis	300481	31001	2026-07-30 08:12:20	2026-07-30 08:12:20	87026073008122014401	300481	31001	pH	6.0	\N
87026073008122001901	87026073008122014801	Urine Analysis	300481	31001	2026-07-30 08:12:20	2026-07-30 08:12:20	87026073008122014401	300481	31001	Sp.gr.	1.015	\N
87026073008122001901	87026073008122014901	Urine Analysis	300481	31001	2026-07-30 08:12:20	2026-07-30 08:12:20	87026073008122014401	300481	31001	WBC	0-1	cells/HPF
87026073008122001901	87026073008122015001	Urine Analysis	300481	31001	2026-07-30 08:12:20	2026-07-30 08:12:20	87026073008122014401	300481	31001	RBC	0-1	cells/HPF
87026073008122001901	87026073008122015101	Urine Analysis	300481	31001	2026-07-30 08:12:20	2026-07-30 08:12:20	87026073008122014401	300481	31001	Protein	Negative	\N
87026073008122001901	87026073008122015201	Urine Analysis	300481	31001	2026-07-30 08:12:20	2026-07-30 08:12:20	87026073008122014401	300481	31001	Glucose	Negative	\N
87026073008122001901	87026073008122015301	Urine Analysis	300481	31001	2026-07-30 08:12:20	2026-07-30 08:12:20	87026073008122014401	300481	31001	Comment	\N	\N
87026073008122001901	87026073008122015401	Urine Analysis	300481	31001	2026-07-30 08:12:20	2026-07-30 08:12:20	87026073008122014401	300481	31001	Attach File	\N	\N
87026073014031102001	87026073014031010301	CBC	300034	30101	2026-07-30 14:03:11	2026-07-30 14:03:11	87026073014031010201	300034	30101	Hb	13.8	g/dL
87026073014031102001	87026073014031010401	CBC	300034	30101	2026-07-30 14:03:11	2026-07-30 14:03:11	87026073014031010201	300034	30101	Hct	41.2	%
87026073014031102001	87026073014031010501	CBC	300034	30101	2026-07-30 14:03:11	2026-07-30 14:03:11	87026073014031010201	300034	30101	White Cell Count	7800	cells/cu.mm.
87026073014031102001	87026073014031010601	CBC	300034	30101	2026-07-30 14:03:11	2026-07-30 14:03:11	87026073014031010201	300034	30101	Platelets Count	265000	cells/cu.mm.
87026073014031102001	87026073014031010701	CBC	300034	30101	2026-07-30 14:03:11	2026-07-30 14:03:11	87026073014031010201	300034	30101	Neutrophil	58	%
87026073014031102001	87026073014031010801	CBC	300034	30101	2026-07-30 14:03:11	2026-07-30 14:03:11	87026073014031010201	300034	30101	Lymphocyte	33	%
87026073014031102001	87026073014031010901	CBC	300034	30101	2026-07-30 14:03:11	2026-07-30 14:03:11	87026073014031010201	300034	30101	Monocyte	6	%
87026073014031102001	87026073014031011001	CBC	300034	30101	2026-07-30 14:03:11	2026-07-30 14:03:11	87026073014031010201	300034	30101	Eosinophil	3	%
87026073014031102001	87026073014031011101	CBC	300034	30101	2026-07-30 14:03:11	2026-07-30 14:03:11	87026073014031010201	300034	30101	Comment	\N	\N
87026073014031102001	87026073014031011201	CBC	300034	30101	2026-07-30 14:03:11	2026-07-30 14:03:11	87026073014031010201	300034	30101	Attach File	\N	\N
87026073014031102001	87026073014031012201	Dengue virus Ag NS1	352230	36701	2026-07-30 14:03:11	2026-07-30 14:03:11	87026073014031012101	352230	36701	Dengue NS1 Ag	Negative	\N
87026073014031102001	87026073014031012301	Dengue virus Ag NS1	352230	36701	2026-07-30 14:03:11	2026-07-30 14:03:11	87026073014031012101	352230	36701	Comment	\N	\N
87026073014031102001	87026073014031012401	Dengue virus Ag NS1	352230	36701	2026-07-30 14:03:11	2026-07-30 14:03:11	87026073014031012101	352230	36701	Attach File	\N	\N
87026073015264002101	87026073015264010301	Thyroid Function Test	304401	32801	2026-07-30 15:26:40	2026-07-30 15:26:40	87026073015264010201	304401	32801	TSH	6.8	uIU/mL
87026073015264002101	87026073015264010401	Thyroid Function Test	304401	32801	2026-07-30 15:26:40	2026-07-30 15:26:40	87026073015264010201	304401	32801	Free T4	0.9	ng/dL
87026073015264002101	87026073015264010501	Thyroid Function Test	304401	32801	2026-07-30 15:26:40	2026-07-30 15:26:40	87026073015264010201	304401	32801	Comment	\N	\N
87026073015264002101	87026073015264010601	Thyroid Function Test	304401	32801	2026-07-30 15:26:40	2026-07-30 15:26:40	87026073015264010201	304401	32801	Attach File	\N	\N
\.


--
-- Data for Name: medhack_patient; Type: TABLE DATA; Schema: imed; Owner: -
--

COPY imed.medhack_patient (transactionnumber, admissionnumber, birthdate, ageyear, admissiondatetime, dischargedatetime, dischargetype, dischargestatus, ispregnant, sex, healthcoverage, coding_status) FROM stdin;
87026072508311700301	\N	1963-09-14 00:00:00	62,10,11	\N	\N	\N	\N	\N	male	OFC_E1	\N
87026072414445200401	\N	1971-01-30 00:00:00	55,6,2	\N	\N	\N	\N	\N	female	WEL_71	\N
87026073109520800501	\N	1994-11-11 00:00:00	31,8,20	\N	\N	\N	\N	\N	male	\N	\N
87026073111085600601	\N	1989-04-04 00:00:00	37,3,27	\N	\N	\N	\N	\N	female	OFC_O1	\N
87026072716380901001	\N	2003-12-01 00:00:00	22,7,26	\N	\N	\N	\N	\N	male	\N	\N
87026080110481501101	\N	1978-12-30 00:00:00	47,7,2	\N	\N	\N	\N	\N	female	OFC_O4	\N
87026072915054701201	\N	1980-05-21 00:00:00	46,2,12	\N	\N	\N	\N	\N	male	\N	\N
87026073010193301301	\N	1964-02-14 00:00:00	62,5,16	\N	\N	\N	\N	\N	female	WEL_74_I	\N
87026072808552901401	\N	1956-05-19 00:00:00	70,2,9	\N	\N	\N	\N	\N	female	WEL_77	\N
87026072810245101501	\N	1990-10-03 00:00:00	35,9,29	\N	\N	\N	\N	\N	male	\N	\N
87026072909410201601	\N	2008-04-22 00:00:00	18,3,7	\N	\N	\N	\N	\N	female	\N	\N
87026072913173601701	\N	1985-08-11 00:00:00	40,11,18	\N	\N	\N	\N	\N	female	LGO_L1	\N
87026073115294701801	\N	1996-01-05 00:00:00	30,6,26	\N	\N	\N	\N	\N	male	\N	\N
87026073008122001901	\N	1982-03-08 00:00:00	44,4,22	\N	\N	\N	\N	\N	male	OFC_B3	\N
87026073014031102001	\N	2010-09-16 00:00:00	15,10,14	\N	\N	\N	\N	\N	female	\N	\N
87026073015264002101	\N	1969-06-25 00:00:00	57,1,5	\N	\N	\N	\N	\N	female	WEL_73	\N
87026072813401900901	\N	1975-12-08 00:00:00	50,7,25	\N	\N	\N	\N	\N	female	\N	\N
87026072209142300201	\N	1979-03-12 00:00:00	47,4,10	\N	\N	\N	\N	\N	male	UCS_89	\N
87026072413210500101	\N	1958-11-25 00:00:00	67,8,0	\N	\N	\N	\N	\N	male	OFC_O3	\N
87026072310024100701	\N	1993-06-02 00:00:00	33,1,21	\N	\N	\N	\N	\N	female	Cashonly	\N
87026072711124400801	\N	1988-07-07 00:00:00	38,0,25	\N	\N	\N	\N	\N	male	\N	\N
\.


--
-- Data for Name: medhack_procedure_icd9; Type: TABLE DATA; Schema: imed; Owner: -
--

COPY imed.medhack_procedure_icd9 (transactionnumber, encountertype, id, name, icd, startdatetime, enddatetime, operationtype, is_cancelled, updated_at) FROM stdin;
87026072209142300201	0	87026072209142012401	Hemorrhoidectomy	49.46	2026-07-22 11:05:00	2026-07-22 11:52:00	OR Procedure	\N	\N
87026072414445200401	0	87026072414445010501	Other heat therapy	93.35	2026-07-24 15:30:00	2026-07-24 16:00:00	NON OR Procedure	\N	\N
87026072310024100701	0	87026072310024010301	Ultrasound Endovaginal	88.79	2026-07-23 10:40:00	2026-07-23 10:55:00	OR Procedure	\N	\N
87026072711124400801	0	87026072711124010401	Incision and drainage of abscess	86.04	2026-07-27 11:45:00	2026-07-27 12:05:00	OR Procedure	\N	\N
87026072915054701201	0	87026072915054010301	CT Brain	87.03	2026-07-29 15:40:00	2026-07-29 15:50:00	NON OR Procedure	\N	\N
87026072813401900901	0	87026072813401010301	Excision of lesion of subcutaneous tissue	86.3	2026-07-28 14:20:00	2026-07-28 14:55:00	OR Procedure	\N	2026-08-07 09:02:43
\.


--
-- Data for Name: medhack_vitalsign; Type: TABLE DATA; Schema: imed; Owner: -
--

COPY imed.medhack_vitalsign (transactionnumber, measuredatetime, temperature, diastolicbloodpressure, systolicbloodpressure, heartrate, oxygensaturation, weight, height) FROM stdin;
87026072413210500101	2026-07-24 13:21:05	38.4	84	142	96	95	68	168
87026072413210500101	2026-07-24 13:21:05	\N	82	138	88	\N	\N	\N
87026072209142300201	2026-07-22 09:14:23	36.8	76	128	78	99	72	170
87026072508311700301	2026-07-25 08:31:17	36.5	82	134	74	99	88	172
87026072414445200401	2026-07-24 14:44:52	36.6	78	124	76	99	70	160
87026073109520800501	2026-07-31 09:52:08	37.5	68	112	92	100	66	170
87026073111085600601	2026-07-31 11:08:56	36.6	75	119	77	100	58	163
87026072310024100701	2026-07-23 10:02:41	36.5	72	118	80	100	62	158
87026072711124400801	2026-07-27 11:12:44	37.2	80	126	82	99	80	175
87026072813401900901	2026-07-28 13:40:19	36.6	76	122	74	100	63	159
87026072716380901001	2026-07-27 16:38:09	36.7	74	122	88	100	68	176
87026080110481501101	2026-08-01 10:48:15	36.8	78	126	92	97	64	159
87026072915054701201	2026-07-29 15:05:47	36.5	80	128	76	100	75	173
87026073010193301301	2026-07-30 10:19:33	36.4	76	126	70	99	56	153
87026072808552901401	2026-07-28 08:55:29	36.4	84	138	72	99	58	152
87026072808552901401	2026-07-28 08:55:29	\N	86	142	76	\N	\N	\N
87026072810245101501	2026-07-28 10:24:51	36.6	76	120	70	100	74	173
87026072909410201601	2026-07-29 09:41:02	36.5	68	110	78	100	50	158
87026072913173601701	2026-07-29 13:17:36	36.9	74	118	80	100	60	162
87026073115294701801	2026-07-31 15:29:47	36.6	77	121	75	100	70	171
87026073008122001901	2026-07-30 08:12:20	36.4	72	118	66	100	70	174
87026073014031102001	2026-07-30 14:03:11	38.9	66	104	102	99	45	155
87026073015264002101	2026-07-30 15:26:40	36.2	70	116	64	100	63	157
\.


--
-- Name: medhack_patient medhack_patient_pkey; Type: CONSTRAINT; Schema: imed; Owner: -
--

ALTER TABLE ONLY imed.medhack_patient
    ADD CONSTRAINT medhack_patient_pkey PRIMARY KEY (transactionnumber);


--
-- PostgreSQL database dump complete
--

\unrestrict LaykUF23kvw4BVpaBUn8KRDW9V80d7R6qtqJYDTmi75QhEYeQaJfcAym0UqG4Wb

